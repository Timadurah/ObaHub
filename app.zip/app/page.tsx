import AcademyPost from "./components/AcademyPost";
import ConsultDivider from "./components/consultDivider";
import DividerHero from "./components/dividerHero";
import Homehero from "./components/Homehero";
import SpiritualMedicine from "./components/spiritualMedicine";
import TrendsBooks from "./components/trendsBooks";

export default function Home() {
  return (
    <main>
      <Homehero />
      <TrendsBooks Title="Trending Books"/>
      <br />
      <DividerHero />
      <br />
      <AcademyPost />
      <br />
      <ConsultDivider />
      <br />
      <SpiritualMedicine />
    </main>
  );
}

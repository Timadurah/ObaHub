import NavBar from '@/app/NavBar'
import Landing from '@/app/Landing'
import Footer from '@/app/Footer'

export default function Page() {
  return (
    <main>
      <NavBar />
      <Landing />
      <Footer />
    </main>
  )
}

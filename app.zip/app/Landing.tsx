'use client'
import AfterBanner from '@/app/components/afterBanner'
import Obaelatvsection from '@/app/components/Obaelatvsection'
import Carousel from '@/app/components/styles/Carousel'
import LatestBlog from '@/app/components/latestBlog'
import TvTub from '@/app/components/TvTub'
import Upcoming from '@/app/components/Upcoming'
import FooterBanner from '@/app/components/FooterBanner'
export default function Landing() {
  return (
    <main>
      {/* Event */}
      <Carousel />

      <AfterBanner />
      <Obaelatvsection />
      <LatestBlog />
      <FooterBanner />
      <TvTub />
      <Upcoming />
    </main>
  )
}

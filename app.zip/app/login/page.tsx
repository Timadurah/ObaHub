'use client'
import React, { useState } from 'react'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Cookies from 'js-cookie'
import Image from 'next/image'
import Baba from '@/images/babalawo_initiate.jpg'

const Login = () => {
  // const router = useRouter();
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleLogin = async (e: any) => {
    e.preventDefault()

    const payload = {
      email,
      password,
    }

    try {
      const response = await fetch('https://orentify.com/oba/login.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      })

      const data = await response.json()

      if (data.success) {
        // set id
        Cookies.set('user_id', data.user_id, { expires: 7 })
        location.href = './me/setting' // Redirect to the dashboard or homepage after login
      } else {
        setError(data.error)
      }
    } catch (err) {
      setError('An error occurred. Please try again later.')
    }
  }

  return (
    <>
      <NavBar />
      <section>
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-lg-6 py-5 text-black">
              <div className="ms-xl-4 col-12 col-lg-10 px-5 py-2">
                <h3 className='color-naw'>Welcome</h3>
                <p className="text-muted">
                  We are happy to have you back on our website. Please input
                  your information carefully.
                </p>
              </div>
              <div className="ms-xl-4 d-flex justify-content-between align-items-center col-12 col-lg-10 px-5">
                <a
                  href="/login"
                  className="btn btn-outline-secondary  bg-naw col-5 text-white"
                >
                  Login
                </a>
                <a href="/register" className="btn btn-outline-secondary col-5">
                  Register
                </a>
              </div>
              <br />
              <br className="d-md-block d-none" />
              <div className="d-flex align-items-center h-custom-2 ms-xl-4 mt-lg-3 pt-lg-3 pt-xl-0 mt-xl-n5 my-5 mt-3 px-5 py-5 pt-3">
                <form
                  className="col-12 col-lg-11 rounded-3 position-relative my-5 bg-white p-5 shadow"
                  onSubmit={handleLogin}
                >
                  <div className="d-flex justify-content-between flex-column">
                    <div className="form-outline mx-lg-0 col-12 mx-2 mb-4">
                      <label className="form-label">Email</label>
                      <input
                        className="form-control bg-white"
                        type="email"
                        name="email"
                        id="email"
                        required
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e: any) => setEmail(e.target.value)}
                      />
                    </div>
                    <div className="form-outline mx-lg-0 col-12 mx-2 mb-4">
                      <label className="form-label">Password</label>
                      <input
                        className="form-control bg-white"
                        type="password"
                        name="password"
                        id="password"
                        required
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e: any) => setPassword(e.target.value)}
                      />
                    </div>
                  </div>

                  {error && <p className="text-danger">{error}</p>}

                  <div className="col-12 mb-3 pt-1">
                    <button
                      data-mdb-button-init
                      data-mdb-ripple-init
                      className="btn btn-dark bg-naw btn-lg btn-block col-12"
                      type="submit"
                    >
                      Login
                    </button>
                  </div>

                  <p className="small pb-lg-2 mb-3">
                    <a className="text-muted" href="#!">
                      Terms and Conditions
                    </a>
                  </p>
                  <p>
                    Don&#39;t have an account?
                    <a href="/register" className="link-info mx-4">
                      Register here
                    </a>
                  </p>
                </form>
              </div>
            </div>
            <div className="col-sm-6 d-none d-lg-flex h-full px-0">
              <Image
                src={Baba}
                alt="OBA ELA IFA IMAGE"
                className="w-100"
                style={{
                  objectFit: 'cover',
                  objectPosition: 'left',
                  height: '100dvh',
                }}
              />
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default Login

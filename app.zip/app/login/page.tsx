import React from "react";

const Login = () => {
  return (
    <section>
      <div className="container-fluid">
        <div className="row">
          <div className="col-12 col-lg-6 text-black py-5">
            <div className="px-5 ms-xl-4 py-2 col-12 col-lg-10">
              <h3>Welcome</h3>

              <p className="text-muted">
                We are happy to have you back in our website, Please input your
                information carefully.
              </p>
            </div>
            <div className="px-5 ms-xl-4 d-flex justify-content-between align-items-center col-12 col-lg-10">
              <a
                href="./sign.html"
                className="btn btn-outline-secondary bg-dark text-white col-5"
              >
                Login
              </a>
              <a
                href="./register.html"
                className="btn btn-outline-secondary col-5"
              >
                Register
              </a>
            </div>
            <br />
            <br className="d-md-block d-none" />
            <div className="d-flex align-items-center h-custom-2 my-5 py-5 px-5 ms-xl-4 mt-3 mt-lg-3 pt-3 pt-lg-3 pt-xl-0 mt-xl-n5">
              <form
                className="col-12 col-lg-11 my-5 bg-white p-5 rounded-3 shadow position-relative"
                method="post"
              >
                <div className="d-flex justify-content-between flex-column">
                  <div className="form-outline mx-2 mx-lg-0 col-12 mb-4">
                    <label className="form-label">Email</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="fullName"
                      id="fulname"
                      required
                      placeholder="Enter your Full name"
                    />
                  </div>
                  <div className="form-outline mx-2 mx-lg-0 col-12 mb-4">
                    <label className="form-label">Password</label>
                    <input
                      className="bg-white form-control"
                      type="password"
                      name="password"
                      id="password"
                      required
                      placeholder="Enter your email"
                    />
                  </div>
                </div>

                <div className="pt-1 mb-3 col-12">
                  <button
                    data-mdb-button-init
                    data-mdb-ripple-init
                    className="btn btn-dark btn-lg btn-block col-12"
                    type="button"
                  >
                    Login
                  </button>
                </div>

                <p className="small mb-3 pb-lg-2">
                  <a className="text-muted" href="#!">
                    Terms and Conditions
                  </a>
                </p>
                <p>
                  Don't have an account?
                  <a href="./register.html" className="link-info mx-4">
                    Register here
                  </a>
                </p>
              </form>
            </div>
          </div>
          <div className="col-sm-6 px-0 d-none d-sm-block">
            <img
              src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img3.webp"
              alt="Login image"
              className="w-100"
              style={{
                objectFit: "cover",
                objectPosition: "left",
                height: "100dvh",
              }}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;

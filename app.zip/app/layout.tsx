import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Welcome to Oba Ela Ifa Documentation website',
  description:
    'Explore the spiritual journey and sacred practices of Oba Ela Ifa. Discover rich traditions, insightful divinations, and the wisdom of Ifa.',
  keywords: [
    'Oba Ela Ifa',
    'Spiritual Journey',
    'Ifa Divination',
    'African Wisdom',
    'Sacred Practices',
  ],
  openGraph: {
    title: 'Welcome to Oba Ela Ifa',
    description:
      'Explore the spiritual journey and sacred practices of Oba Ela If. Discover rich traditions, insightful divinations, and the wisdom of Ifa.',
    url: 'https://www.obaelaifa.com/', // Change to the actual URL
    siteName: 'Oba Ela Ifa',
    images: [
      {
        url: 'https://www.obaelaifa.com/opele.png', // Change to the actual image URL
        width: 1200,
        height: 630,
        alt: 'Oba Ela Ifa Home',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Welcome to Oba Ela Ifa',
    description:
      'Explore the spiritual journey and sacred practices of Oba Ela Ifa. Discover rich traditions, insightful divinations, and the wisdom of Ifa.',
    images: [
      'https://www.obaelaifa.com/opele.png', // Change to the actual image URL
    ],
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={'h-full'}>
      <body className={`${inter.className}`}>{children}</body>
    </html>
  )
}

import React from "react";
import AcademyPost from "../components/AcademyPost";

const ProductSection = () => {
  return (
    <div className="w-100">
      <AcademyPost />
    </div>
    
  );
};

export default ProductSection;

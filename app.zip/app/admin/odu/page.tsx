'use client'

import { useState } from 'react'
import axios from 'axios'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'

const DivinationForm = () => {
  const [topic, setTopic] = useState('')
  const [content, setContent] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true) // Show loading state
    try {
      const response = await axios.post('https://orentify.com/oba/admin/divination.php', { 
        topic: topic, 
        content: content 
      })
      setMessage(response.data.message)
    } catch (error) {
      setMessage('Error inserting Ifa Divination Data.')
    } finally {
      setLoading(false) // Hide loading state
    }
  }

  return (
    <>
      <NavBar />
      <div className="align-center  w-100 mt-16 flex justify-center">
      <a href="./admin/shop" className="border pt-5 p-4 mx-3 col-4 btn-primary">
        Upload to shop
      </a>
      <a href="./admin/odu" className="border pt-5 p-4 mx-3 col-4  btn-primary">
        Upload to Divination
      </a>
    </div>
      <div className="container mt-5">
        <h2 className="text-center">Insert Ifa Divination Data</h2>
        <form onSubmit={handleSubmit} className="bg-light rounded-3 p-5 shadow">
          <div className="mb-3">
            <label htmlFor="topic" className="form-label">
              Topic
            </label>
            <input
              type="text"
              className="form-control"
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="content" className="form-label">
              Content
            </label>
            <textarea
              className="form-control"
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={5}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100" disabled={loading}>
            {loading ? 'Inserting...' : 'Insert Data'}
          </button>
          {message && <div className="alert alert-info mt-3">{message}</div>}
        </form>
      </div>
      <Footer />
    </>
  )
}

export default DivinationForm

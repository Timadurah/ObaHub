'use client'
import { useState } from 'react'
import axios from 'axios'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'

const ProductUploadForm = () => {
  const [formData, setFormData] = useState({
    product_name: '',
    product_description: '',
    author: '',
    amount_available: 0,
    price: 0,
    category: '',
  })
  const [productImages, setProductImages] = useState<FileList | null>(null)
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false) // Added state for loading

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProductImages(e.target.files)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true) // Start loading

    const data = new FormData()
    
    // Convert numbers to strings before appending
    Object.keys(formData).forEach((key) => {
      data.append(key, String(formData[key as keyof typeof formData]))
    })
    
    if (productImages) {
      for (let i = 0; i < productImages.length; i++) {
        data.append('product_images[]', productImages[i])
      }
    }

    try {
      const response = await axios.post(
        'https://orentify.com/oba/upload-product.php',
        data,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
        }
      )
      setMessage(response.data.message)
    } catch (error) {
      setMessage('Error uploading product details.')
    } finally {
      setLoading(false) // End loading
    }
  }

  return (
    <>
      <NavBar />
      <div className="align-center w-100 mt-16 flex justify-center">
        <a href="./admin/shop" className="border pt-5 p-4 mx-3 col-4 btn-primary">
          Upload to shop
        </a>
        <a href="./admin/odu" className="border pt-5 p-4 mx-3 col-4 btn-primary">
          Upload to Divination
        </a>
      </div>
      <div className="container mt-5 my-10">
        <h2 className="text-center">Upload Product Details</h2>
        <form
          onSubmit={handleSubmit}
          className="bg-light rounded-3 p-5 shadow"
          encType="multipart/form-data"
        >
          <div className="mb-3">
            <label htmlFor="product_name" className="form-label">
              Product Name
            </label>
            <input
              type="text"
              className="form-control"
              id="product_name"
              name="product_name"
              value={formData.product_name}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="product_description" className="form-label">
              Product Description
            </label>
            <textarea
              className="form-control"
              id="product_description"
              name="product_description"
              value={formData.product_description}
              onChange={handleChange}
              rows={4}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="author" className="form-label">
              Author
            </label>
            <input
              type="text"
              className="form-control"
              id="author"
              name="author"
              value={formData.author}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="amount_available" className="form-label">
              Amount Available
            </label>
            <input
              type="number"
              className="form-control"
              id="amount_available"
              name="amount_available"
              value={formData.amount_available}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="price" className="form-label">
              Price
            </label>
            <input
              type="number"
              step="0.01"
              className="form-control"
              id="price"
              name="price"
              value={formData.price}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="category" className="form-label">
              Category
            </label>
            <input
              type="text"
              className="form-control"
              id="category"
              name="category"
              value={formData.category}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="product_images" className="form-label">
              Product Images
            </label>
            <input
              type="file"
              className="form-control"
              id="product_images"
              name="product_images[]"
              multiple
              onChange={handleFileChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100" disabled={loading}>
            {loading ? 'Uploading...' : 'Upload Product'}
          </button>
          {message && <div className="alert alert-info mt-3">{message}</div>}
        </form>
      </div>
      <Footer />
    </>
  )
}

export default ProductUploadForm

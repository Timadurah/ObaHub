import React from 'react'

const page = () => {
  return (
    <div className="align-center  w-100 mt-16 flex justify-center">
      <a href="./admin/shop" className="border pt-5 p-4 mx-3 col-4 btn-primary">
        Upload to shop
      </a>
      <a href="./admin/odu" className="border pt-5 p-4 mx-3 col-4  btn-primary">
        Upload to Divination
      </a>
    </div>
  )
}

export default page

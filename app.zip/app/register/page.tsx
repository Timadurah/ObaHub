import React from "react";

const Register = () => {
  return (
    <section className="mb-5">
      <div className="container-fluid">
        <div className="row">
          <div className="col-12 col-lg-6 text-black py-5">
            <div className="px-5 ms-xl-4 py-2 col-12 col-lg-10">
              <h3>Welcome</h3>

              <p className="text-muted">
                We are happy to have you in our website, Please Enjoy the power
                of nature and explore the secrete behind it.
              </p>
            </div>
            <div className="px-5 ms-xl-4 d-flex justify-content-between align-items-center col-12 col-lg-10">
              <a href="./sign.html" className="btn btn-outline-secondary col-5">
                Login
              </a>
              <a
                href="./register.html"
                className="btn btn-outline-secondary col-5 bg-dark text-white"
              >
                Register
              </a>
            </div>
            <br />
            <br className="d-md-block d-none" />
            <div className="d-flex align-items-center my-5 py-5 h-custom-2 px-0 px-lg-5 ms-xl-4 mt-3 mt-lg-5 pt-3 pt-lg-5 pt-xl-0 mt-xl-n5">
              <form
                className="col-12 col-lg-11 my-5 bg-white p-5 rounded-3 shadow position-relative"
                method="post"
              >
                <div className="d-flex justify-content-between">
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">Full name</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="fullName"
                      id="fulname"
                      required
                      placeholder="Enter your Full name"
                    />
                  </div>
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">email</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="category"
                      id="category"
                      required
                      placeholder="Enter your email"
                    />
                  </div>
                </div>

                <div className="d-flex justify-content-between">
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">Address</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="category"
                      id="category"
                      required
                      placeholder="Enter your  Address"
                    />
                  </div>
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">Social [ Optional ]</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="socialmedial"
                      id="socialmedial"
                      required
                      placeholder="Enter your Social medail handle address"
                    />
                  </div>
                </div>

                <div className="d-flex justify-content-between">
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">Nationality</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="Nationality"
                      id="Nationality"
                      required
                      placeholder="Enter your Nationality"
                    />
                  </div>
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">State of origin</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="category"
                      id="category"
                      required
                      placeholder="Enter your  state of origin"
                    />
                  </div>
                </div>

                <div className="d-flex justify-content-between">
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">City</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="City"
                      id="City"
                      required
                      placeholder="Enter your  City"
                    />
                  </div>
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">Marital status</label>
                    <select
                      className="bg-white form-control"
                      name="category"
                      id="category"
                      required
                    >
                      <option value="Single">Single</option>
                      <option value="Single">Married</option>
                    </select>
                  </div>
                </div>
                <div className="d-flex justify-content-between">
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">Date of birth</label>
                    <input
                      className="bg-white form-control"
                      type="date"
                      name="dateofb"
                      id="dateofb"
                      required
                      placeholder="Enter your  Date of birth"
                    />
                  </div>
                  <div
                    className="form-outline mx-2 mx-lg-2 col-5 col-lg-5 mb-4"
                    style={{ flexGrow: "1" }}
                  >
                    <label className="form-label">Phone</label>
                    <input
                      className="bg-white form-control"
                      type="text"
                      name="Phone"
                      id="Phone"
                      required
                      placeholder="Enter your  Phone"
                    />
                  </div>
                </div>

                <div className="pt-1 mb-3 col-12">
                  <button
                    data-mdb-button-init
                    data-mdb-ripple-init
                    className="btn btn-dark btn-lg btn-block col-12"
                    type="button"
                  >
                    Register
                  </button>
                </div>

                <p className="small mb-3 pb-lg-2">
                  <a className="text-muted" href="#!">
                    Forgot password?
                  </a>
                </p>
                <p>
                  You already have account?
                  <a href="./sign.html" className="link-info mx-3">
                    Login here
                  </a>
                </p>
              </form>
            </div>
          </div>
          <div className="col-sm-6 px-0 d-none d-sm-block">
            <img
              src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img3.webp"
              alt="Login image"
              className="w-100"
              style={{ objectFit: "cover", objectPosition: "left" }}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Register;

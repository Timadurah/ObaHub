'use client';

import { useEffect, useState } from 'react';
import NavBar from '@/app/NavBar';
import Footer from '@/app/Footer';
import Overview from '@/app/shop/[id]/overview';
import Cookies from 'js-cookie';

interface Product {
  product_name: string;
  price: number;
  amount_available: number;
  product_description: string;
  images: { src: string; alt: string }[];
}

interface ProductData {
  product_name: string;
  price: number;
  amount_available: number;
  product_description: string;
  image_path: string[];
  error?: string; // Optional for error handling
}

interface PageProps {
  params: {
    id: string; // Assuming the ID is a string
  };
}

interface OverviewProps {
  product: Product;
  productID: number;
  userID?: number; // Allow userID to be optional
}

export default function Page({ params }: PageProps) {
  const [productData, setProductData] = useState<Product | null>(null);
  const id = params.id; // Access dynamic ID from query parameters
  const userIdFromCookie = Cookies.get('user_id');

  useEffect(() => {
    if (id) {
      // Fetch product data from the API
      fetch('https://orentify.com/oba/shop/overview.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id }),
      })
        .then((response) => response.json())
        .then((data: ProductData) => {
          if (data.error) {
            console.error(data.error);
          } else {
            // Convert image_path array from PHP API response into a usable format
            const formattedProduct: Product = {
              product_name: data.product_name,
              price: data.price,
              amount_available: data.amount_available,
              product_description: data.product_description,
              images: data.image_path.map((path: string) => ({
                src: path,
                alt: data.product_name,
              })),
            };
            setProductData(formattedProduct);
          }
        })
        .catch((error) => console.error('Error fetching product data:', error));
    }
  }, [id]);

  if (!productData) {
    return (
      <div
        style={{
          width: '100vw',
          height: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div className="text-black rounded-md p-4 fw-bold display-4">OBA ELA IFA</div>
      </div>
    );
  }

  return (
    <main>
      <NavBar />
      <Overview 
        product={productData} 
        productID={parseInt(id)} // Convert ID to a number
        userID={userIdFromCookie ? parseInt(userIdFromCookie) : 1000000000} // Optional userID
      />
      <Footer />
    </main>
  );
}

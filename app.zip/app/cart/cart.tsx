import Cookies from 'js-cookie';

// Define types for cart items and API responses
interface CartItem {
  id: string;
  product_name: string;
  quantity: number;
  price: number;
  // Add other item fields as needed
}

interface ApiResponse<T> {
  status: string;
  message?: string;
  data?: T;
}

// Fetch all items in the cart
export const getCartItems = async (): Promise<CartItem[]> => {
  try {
    const userId = Cookies.get('user_id');
    if (!userId) {
      console.error('No user_id found in cookies');
      return [];
    }

    const response = await fetch(`https://orentify.com/oba/shop/getcart.php?user_id=${userId}`);
    const data: ApiResponse<CartItem[]> = await response.json();

    // Check if the response is in the expected format
    if (data && data.status === 'success') {
      return data.data ?? []; // Return the array of cart items or an empty array
    } else {
      console.error('Failed to fetch cart items:', data.message);
      return []; // Return an empty array on error
    }
  } catch (error) {
    console.error('Error fetching cart items:', error);
    return []; // Return an empty array on error
  }
};

// Add a new item to the cart
interface AddToCartItem {
  id: string;
  product_name: string;
  quantity: number;
  price: number;
  // Add other item fields as needed
}

export const addToCart = async (item: AddToCartItem): Promise<ApiResponse<null>> => {
  const userId = Cookies.get('user_id');

  if (!userId) {
    console.error('No user_id found in cookies');
    return { status: 'error', message: 'User not logged in' };
  }

  const response = await fetch('https://orentify.com/oba/shop/addcart.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      ...item,
      user_id: userId,
    }),
  });

  const data: ApiResponse<null> = await response.json();
  return data;
};

// Update the quantity of an item in the cart
export const updateCartItem = async (id: string, quantity: number): Promise<ApiResponse<null>> => {
  const userId = Cookies.get('user_id');

  if (!userId) {
    console.error('No user_id found in cookies');
    return { status: 'error', message: 'User not logged in' };
  }

  const response = await fetch(`https://orentify.com/oba/shop/updatecart.php/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      quantity,
      user_id: userId,
    }),
  });

  const data: ApiResponse<null> = await response.json();
  return data;
};

// Remove an item from the cart
export const removeCartItem = async (id: string): Promise<ApiResponse<null>> => {
  const userId = Cookies.get('user_id');

  if (!userId) {
    console.error('No user_id found in cookies');
    return { status: 'error', message: 'User not logged in' };
  }

  const response = await fetch(`https://orentify.com/oba/shop/deletecart.php?user_id=${userId}&product_id=${id}`);
  const data: ApiResponse<null> = await response.json();
  return data;
};

// Clear all items in the cart
export const clearCart = async (): Promise<ApiResponse<null>> => {
  const userId = Cookies.get('user_id');

  if (!userId) {
    console.error('No user_id found in cookies');
    return { status: 'error', message: 'User not logged in' };
  }

  const response = await fetch(`https://orentify.com/oba/shop/clearcart.php?user_id=${userId}`);
  const data: ApiResponse<null> = await response.json();
  return data;
};

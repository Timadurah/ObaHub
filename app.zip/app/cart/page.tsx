'use client'

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Cookies from 'js-cookie';
import NavBar from '@/app/NavBar';
import Footer from '@/app/Footer';
import { clearCart, removeCartItem, updateCartItem } from './cart';
import Image from 'next/image'
// Define types for cart items
interface CartItem {
  id: string;
  title: string;
  quantity: number;
  product_price: string;
  image_path: string;
  // Add other item fields as needed
}

// Define type for API response
interface ApiResponse<T> {
  status: string;
  message?: string;
  data?: T;
}

// Fetch all items in the cart
const getCartItems = async (): Promise<CartItem[]> => {
  try {
    const userId = Cookies.get('user_id');
    if (!userId) {
      console.error('User ID not found in cookies');
      return [];
    }

    const response = await axios.get<ApiResponse<CartItem[]>>('https://orentify.com/oba/shop/getcart.php', {
      params: { user_id: userId },
    });

    if (response.data && response.data.status === 'success') {
      return response.data.data ?? [];
    } else {
      console.error('Failed to fetch cart items:', response.data.message);
      return [];
    }
  } catch (error) {
    console.error('Error fetching cart items:', error);
    return [];
  }
};

const Cart: React.FC = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchCartItems = async () => {
    const items = await getCartItems();
    console.log('Fetched cart items:', items); // For debugging
    setCartItems(items);
    setLoading(false);
  };

  useEffect(() => {
    fetchCartItems();
  }, []);

  const handleRemoveItem = async (id: string) => {
    try {
      await removeCartItem(id);
      // Optimistic update
      setCartItems((prevItems) => prevItems.filter((item) => item.id !== id));
      // Refetch cart items to ensure UI is in sync with the server
      fetchCartItems();
    } catch (error) {
      console.error('Error removing item:', error);
    }
  };

  const handleClearCart = async () => {
    try {
      await clearCart();
      // Optimistic update
      setCartItems([]);
      // Refetch cart items to ensure UI is in sync with the server
      fetchCartItems();
    } catch (error) {
      console.error('Error clearing cart:', error);
    }
  };

  const handleUpdateQuantity = async (id: string, quantity: number) => {
    if (quantity < 1) return;
    try {
      await updateCartItem(id, quantity);
      // Optimistic update
      setCartItems((prevItems) =>
        prevItems.map((item) => (item.id === id ? { ...item, quantity } : item))
      );
      // Refetch cart items to ensure UI is in sync with the server
      fetchCartItems();
    } catch (error) {
      console.error('Error updating item quantity:', error);
    }
  };

  const calculateTotalPrice = (): number => {
    return cartItems.reduce((total, item: any) => {
      const price = parseFloat(item.product_price) || 0;
      const quantity = parseInt(item.quantity) || 0;
      return total + price * quantity;
    }, 0);
  };

  const cartTotal = calculateTotalPrice();

  if (loading)
    return (
      <div
        style={{
          width: '100vw',
          height: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div className="text-black rounded-md p-4 fw-bold display-4">OBA ELA IFA</div>
      </div>
    );

  return (
    <>
      <NavBar />
      <section>
        <div className="container rounded bg-white p-5 shadow">
          <div className="d-flex justify-content-between align-items-center border-bottom flex-wrap pb-3">
            <div className="py-1">
              <a className="btn-sm btn btn-outline-secondary" href="/shop">
                Back to shopping
              </a>
            </div>
            <div className="d-none d-sm-block fs-sm py-1">
              You have {cartItems.length}{' '}
              {cartItems.length === 1 ? 'item' : 'items'} in your cart
            </div>
            <div className="py-1">
              <button
                className="btn btn-outline-danger btn-sm"
                onClick={handleClearCart}
              >
                Clear cart
              </button>
            </div>
          </div>

          {cartItems.length === 0 ? (
            <p className="mt-4">Your cart is empty.</p>
          ) : (
            <>
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="d-flex align-items-center border-bottom py-4"
                >
                  <Image
                    className="rounded-3 me-4"
                    src={
                      'https://orentify.com/oba/' +
                      item.image_path.split(',')[0]
                    }
                    alt={item.title}
                    style={{
                      width: '100px',
                      height: '100px',
                      objectFit: 'cover',
                    }}
                  />
                  <div className="flex-grow-1">
                    <h5>{item.title}</h5>
                    <p className="mb-1">
                      Price: ₦{parseFloat(item.product_price).toFixed(2)}
                    </p>
                    <div className="d-flex align-items-center">
                      <button
                        className="btn btn-outline-secondary btn-sm"
                        onClick={() =>
                          handleUpdateQuantity(item.id, item.quantity - 1)
                        }
                        disabled={item.quantity <= 1}
                      >
                        -
                      </button>
                      <span className="mx-2">{item.quantity}</span>
                      <button
                        className="btn btn-outline-secondary btn-sm"
                        onClick={() =>
                          handleUpdateQuantity(item.id, item.quantity + 1)
                        }
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <div>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleRemoveItem(item.id)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}

              <div className="d-flex justify-content-end mt-4">
                <h4>Total: ₦{cartTotal.toFixed(2)}</h4>
              </div>

              <div className="d-flex justify-content-end mt-2">
                <button className="btn btn-primary">Proceed to Checkout</button>
              </div>
            </>
          )}
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Cart;

import React from "react";
import Bread from "../components/bread";

const Cart = () => {
  return (
    <section>
      <Bread Title="Cart" Name="" />
      <div
        className="container 
        afterBread p-5 rounded shadow
         bg-white"
      >
        <div className="row">
          {/* <!-- Content--> */}
          <section className="col-lg-8 pt-2 pt-lg-4 pb-4 mb-3">
            <div className="pt-2 px-4 pe-lg-0 ps-xl-5">
              {/* <!-- Header--> */}
              <div className="d-flex flex-wrap justify-content-between align-items-center border-bottom pb-3">
                <div className="py-1">
                  <a
                    className="btn-sm btn btn-outline-secondary"
                    href="marketplace-category.html"
                  >
                    Back to shopping
                  </a>
                </div>
                <div className="d-none d-sm-block py-1 fs-sm">
                  You have 3 products in your cart
                </div>
                <div className="py-1">
                  <a
                    className="btn btn-outline-danger btn-sm"
                    href="marketplace-category.html"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash2 mx-2" viewBox="0 0 16 16">
  <path d="M14 3a.7.7 0 0 1-.037.225l-1.684 10.104A2 2 0 0 1 10.305 15H5.694a2 2 0 0 1-1.973-1.671L2.037 3.225A.7.7 0 0 1 2 3c0-1.105 2.686-2 6-2s6 .895 6 2M3.215 4.207l1.493 8.957a1 1 0 0 0 .986.836h4.612a1 1 0 0 0 .986-.836l1.493-8.957C11.69 4.689 9.954 5 8 5s-3.69-.311-4.785-.793"/>
</svg>Clear cart
                  </a>
                </div>
              </div>
              {/* <!-- Product--> */}
              <div className="d-block d-sm-flex align-items-center py-4 border-bottom">
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img
                    className="rounded-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="text-center text-sm-start">
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      UI Isometric Devices Pack (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    $23.<small>00</small>
                  </div>
                  <a
                    className="d-inline-block text-black fs-ms border-start ms-2 ps-2"
                    href="#"
                  >
                    by uidesigner
                  </a>
                  <div className="form-inline pt-2">
                    <input
                      className="form-control border p-2 rounded my-1 me-2"
                      placeholder="1"
                      value="1"
                      type="number"
                    />
                  </div>
                </div>
              </div>
              {/* <!-- Product--> */}
              <div className="d-block d-sm-flex align-items-center py-4 border-bottom">
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img
                    className="rounded-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="text-center text-sm-start">
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Project Devices Showcase (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    $18.<small>00</small>
                  </div>
                  <a
                    className="d-inline-block text-black fs-ms border-start ms-2 ps-2"
                    href="#"
                  >
                    by pixels
                  </a>
                  <div className="form-inline pt-2">
                    <input
                      className="form-control border p-2 rounded my-1 me-2"
                      placeholder="1"
                      value="1"
                      type="number"
                    />
                  </div>
                </div>
              </div>
              {/* <!-- Product--> */}
              <div className="d-block d-sm-flex align-items-center pt-4 pb-2">
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img
                    className="rounded-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="text-center text-sm-start">
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Gravity Devices UI Mockup (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    $15.<small>00</small>
                  </div>
                  <a
                    className="d-inline-block text-black fs-ms border-start ms-2 ps-2"
                    href="#"
                  >
                    by pixels
                  </a>
                  <div className="form-inline pt-2">
                    <input
                      className="form-control border p-2 rounded my-1 me-2"
                      placeholder="1"
                      value="1"
                      type="number"
                    />
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* <!-- Sidebar--> */}
          <aside className="col-lg-4 ps-xl-5">
            <hr className="d-lg-none" />
            <div className="p-4 h-100 ms-auto border-start">
              <div className="px-lg-2">
                <div className="text-center mb-4 py-3 border-bottom">
                  <h2 className="h6 mb-3 pb-1">Cart total</h2>
                  <h3 className="fw-normal">
                    #56,000.<small>00</small>
                  </h3>
                </div>
                <div className="text-center mb-4 pb-3 border-bottom">
                  <h2 className="h6 mb-3 pb-1">Promo code</h2>
                  <form className="needs-validation pb-2" method="post">
                    <div className="mb-3">
                      <input
                        className="form-control"
                        type="text"
                        placeholder="Promo code"
                      />
                      <div className="invalid-feedback">
                        Please provide promo code.
                      </div>
                    </div>
                    <button
                      className="btn btn-dark d-block w-100"
                      type="submit"
                    >
                      Apply promo code
                    </button>
                  </form>
                </div>
                <a
                  className="btn btn-primary btn-shadow d-block w-100 mt-4"
                  href="marketplace-checkout.html"
                >
                  <i className="ci-locked fs-lg me-2"></i>Secure Checkout
                </a>
                <div className="text-center pt-2 pb-3">
                  <small className="text-form text-muted">
                    100% money back guarantee
                  </small>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
};

export default Cart;

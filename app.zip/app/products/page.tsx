import React from "react";
import TrendsBooks from "../components/trendsBooks";

const ProductSection = () => {
  return (
    <div className="w-100">
      <TrendsBooks Title="Product Category" />
    </div>
  );
};
export default ProductSection;

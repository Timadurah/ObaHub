import { BabalawoInitiateImage } from '@/app/divination/BabalawoInitiateImage'

const features = [
  {
    name: 'Spiritual Elevation',
    description:
      'Itefa marks the spiritual elevation and deeper commitment of an individual to the Ifa spiritual system.',
  },
  {
    name: 'Connection to Orunmila',
    description:
      'The ceremony establishes a profound connection with Orunmila, the Orisha of wisdom, knowledge, and divination.',
  },
  {
    name: 'Community Role',
    description:
      'Initiates are recognized as spiritual leaders and are expected to serve their community with wisdom and insight.',
  },
  {
    name: 'Rituals and Ceremonies',
    description:
      'The itefa ceremony involves a series of elaborate rituals, including offerings, prayers, and symbolic actions performed under the guidance of an experienced Babalawo.',
  },
  {
    name: 'Sacred Space',
    description:
      'The ceremony is conducted in a sacred space, typically at the Babalawo’s home or temple, and is attended by family, friends, and other community members.',
  },
  {
    name: 'Divination',
    description:
      'Divination plays a central role in the initiation process, guiding the initiate on their spiritual path and providing insight into their destiny.',
  },
]

export default function Initiation() {
  return (
    <div className="bg-white">
      <section aria-labelledby="features-heading" className="relative">
        <BabalawoInitiateImage />

        <div className="mx-auto max-w-2xl px-4 pb-24 pt-16 sm:px-6 sm:pb-32 lg:grid lg:max-w-7xl lg:grid-cols-2 lg:gap-x-8 lg:px-8 lg:pt-32">
          <div className="lg:col-start-2">
            <h2 id="features-heading" className="font-medium text-gray-500">
              Ifa Initiation
            </h2>
            <p className="mt-4 text-4xl font-bold tracking-tight text-gray-900">
              Spiritual Elevation
            </p>
            <p className="mt-4 text-gray-500">
              Itefa is a transformative and deeply spiritual ceremony that marks
              the initiation of an individual into the priesthood of Ifa,
              symbolizing their commitment to serving their community with
              wisdom and spiritual insight.
            </p>

            <dl className="mt-10 grid grid-cols-1 gap-x-8 gap-y-10 text-sm sm:grid-cols-2">
              {features.map((feature) => (
                <div key={feature.name}>
                  <dt className="font-medium text-gray-900">{feature.name}</dt>
                  <dd className="mt-2 text-gray-500">{feature.description}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>
    </div>
  )
}

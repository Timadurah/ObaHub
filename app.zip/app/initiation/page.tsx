import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Initiation from '@/app/initiation/Initiation'

export default function Page() {
  return (
    <main>
      <NavBar />
      <Initiation />
      <Footer />
    </main>
  )
}

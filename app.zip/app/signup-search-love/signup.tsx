'use client'
import { useState } from 'react'
import axios from 'axios'
import Image from 'next/image'
import Twohumanlove from '@/images/matchnew.png'

interface ErrorResponse {
  detail: Array<{
    loc: string[]
    msg: string
    type: string
  }>
  body?: any
}

export default function Signupsearchlove() {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    occupation: '',
    age: '',
    degree: '',
  })
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const validateForm = () => {
    const { first_name, last_name, email, phone, occupation, age, degree } =
      formData
    let errors: string[] = []

    // Validate first_name
    if (first_name.trim().length === 0) {
      errors.push('First name is required.')
    }

    // Validate last_name
    if (last_name.trim().length === 0) {
      errors.push('Last name is required.')
    }

    // Validate email
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailPattern.test(email)) {
      errors.push('Email is not valid.')
    }

    // // Validate phone number
    // const phonePattern = /^\+?[1-9]\d{1,14}$/
    // if (!phonePattern.test(phone)) {
    //   errors.push('Phone number is not valid.')
    // }

    // Validate occupation
    if (occupation.trim().length === 0) {
      errors.push('Occupation is required.')
    }

    // Validate age
    const agePattern = /^\d+$/
    if (!agePattern.test(age) || Number(age) < 18) {
      errors.push('Age must be a valid number and 18 or older.')
    }

    // Validate degree
    if (degree === '') {
      errors.push('Degree must be selected.')
    }

    return errors
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)

    // Perform validation
    const validationErrors = validateForm()
    if (validationErrors.length > 0) {
      setError(validationErrors.join(' '))
      return
    }

    try {
      const response = await axios.post(
        'https://orentify.com/oba/matchmaking.php',
        formData
      )
      setSuccess(
        'You just Joing OBA ELA IFA Match making, Thank you! we will get back to you soon.'
      )
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
        occupation: '',
        age: '',
        degree: '',
      })
    } catch (err) {
      if (axios.isAxiosError(err)) {
        setError('Failed to Register. Please check your input and try again.')
        console.error(err.response?.data)
      } else {
        setError('An unexpected error occurred.')
        console.error(err)
      }
    }
  }

  return (
    <>      <div className="relative isolate bg-white">

            <div className="absolute inset-y-0 left-0 -z-10 w-full overflow-hidden  isolate bg-gray-100 ring-1 ring-gray-900/10 lg:w-1/2">
            <svg
                className="absolute inset-0 h-full w-full stroke-gray-200 [mask-image:radial-gradient(100%_100%_at_top_right,white,transparent)]"
                aria-hidden="true"
              >
                <defs>
                  <pattern
                    id="83fd4e5a-9d52-42fc-97b6-718e5d7ee527"
                    width={200}
                    height={200}
                    x="100%"
                    y={-1}
                    patternUnits="userSpaceOnUse"
                  >
                    <path d="M130 200V.5M.5 .5H200" fill="none" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" strokeWidth={0} fill="white" />
                <svg x="100%" y={-1} className="overflow-visible fill-gray-50">
                  <path d="M-470.5 0h201v201h-201Z" strokeWidth={0} />
                </svg>
                <rect
                  width="100%"
                  height="100%"
                  strokeWidth={0}
                  fill="url(#83fd4e5a-9d52-42fc-97b6-718e5d7ee527)"
                />
              </svg>{' '}  
              </div>
              <div className="mx-auto grid max-w-7xl grid-cols-1 lg:grid-cols-2">
          <div className="relative px-6 pt-24 sm:pt-32 lg:static ">
            
            <div className="divWithBefore mx-auto max-w-xl d-none d-lg-flex  lg:mx-0 lg:max-w-lg">
           
              {/* <Image
                src={Twohumanlove}
                alt="oba-ile-ifa-matchmaking"
                style={{ position: 'relative' }}
              />{' '} */}
            </div>
          </div>
          <form
            action="#"
            method="POST"
            className="pt-30 px-6 lg:px-8 lg:py-1"
            onSubmit={handleSubmit}
          >
            <div className="mx-auto max-w-xl lg:mr-0 lg:max-w-lg">
              <p className="my-5">
                Ready to find your perfect match? Our matchmaking service
                connects you with compatible partners who share your values and
                goals.
              </p>
              <h2 className="text-3xl tracking-tight text-gray-900">
                Register for matchmaking
              </h2>
              <br />
              {error && (
                <p style={{ color: 'red', marginBottom: '10px' }}>{error}</p>
              )}
              {success && (
                <p style={{ color: 'green', marginBottom: '10px' }}>
                  {success}
                </p>
              )}

              <div className="grid grid-cols-1 gap-x-8 gap-y-6 sm:grid-cols-2">
                <div>
                  <label className="block text-sm font-semibold leading-6 text-gray-900">
                    First name
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="text"
                      name="first_name"
                      value={formData.first_name}
                      onChange={handleChange}
                      required
                      placeholder="Enter First name"
                      className="block w-full rounded-md border px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold leading-6 text-gray-900">
                    Last name
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="text"
                      name="last_name"
                      value={formData.last_name}
                      onChange={handleChange}
                      required
                      placeholder="Enter Last name"
                      className="block w-full rounded-md border px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold leading-6 text-gray-900">
                    Phone
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="text"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      placeholder="Enter Phone Number"
                      className="block w-full rounded-md border px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold leading-6 text-gray-900">        
Name of Oluwo (initiator)
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      placeholder="Enter Name of Your Oluwo (initiator)"
                      className="block w-full rounded-md border px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold leading-6 text-gray-900">
                  Location of your initiation
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="text"
                      id="occupation"
                      name="occupation"
                      value={formData.occupation}
                      onChange={handleChange}
                      required
                      placeholder="Enter Location of your initiation"
                      className="block w-full rounded-md border px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>
                {/*  */}
                <div>
                  <label
                    htmlFor="last-name"
                    className="block text-sm font-semibold leading-6 text-gray-900"
                  >
                    Age
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="text"
                      id="age"
                      name="age"
                      value={formData.age}
                      onChange={handleChange}
                      required
                      placeholder="Enter Age"
                      autoComplete="family-name"
                      className="block w-full rounded-md border px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>

                {/*  */}

                <div className="sm:col-span-2">
                  <label
                    htmlFor="email"
                    className="block text-sm font-semibold leading-6 text-gray-900"
                  >
                    Select Your Marital Status :
                  </label>
                  <div className="mt-2.5">
                    <select
                      id="email"
                      name="degree"
                      value={formData.degree}
                      onChange={handleChange}
                      required
                      autoComplete="email"
                      className="block w-full rounded-md border px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    >
                      <option value="none" disabled hidden>
                       Marital Status
                      </option>
                      
                      <option value="single">Single</option>
                      <option value="married">Married</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="mt-8 flex justify-end">
                <button
                  type="submit"
                  className="rounded-md border bg-naw px-3.5 py-2.5 text-center text-sm font-semibold text-white hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                >
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <hr />
    </>
  )
}

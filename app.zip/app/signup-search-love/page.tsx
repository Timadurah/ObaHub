import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Signupsearchlove from '@/app/signup-search-love/signup'

export default function Page() {
  return (
    <main>
      <NavBar />
      <Signupsearchlove />
      <Footer />
    </main>
  )
}

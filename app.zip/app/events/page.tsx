import { Schedule } from '@/app/events/Schedule'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'

export default function Page() {
  return (
    <main>
      <NavBar />
      <Schedule />
      <Footer />
    </main>
  )
}

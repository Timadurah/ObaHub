'use client'

import { useEffect, useState } from 'react'
import { Tab, TabGroup, TabList, TabPanel, TabPanels } from '@headlessui/react'
import clsx from 'clsx'

import { BackgroundImage } from '@/app/events/BackgroundImage'
import { Container } from '@/app/events/Container'

interface Day {
  date: React.ReactNode
  dateTime: string
  summary: string
  timeSlots: Array<{
    name: string
    description: string | null
    start: string
    end: string
  }>
}

const schedule: Array<Day> = [
  {
    date: 'June 2024',
    dateTime: '2024-06-01',
    summary: 'We will be celebrating Odun Ifa Agbaye, the World Ifa Festival.',
    timeSlots: [
      {
        name: 'Odun Ifa Agbaye',
        description:
          'The world Ifa festival, guests speakers include the Oni of Ife, Araba Agbaye, etc.',
        start: 'May 16, 2024',
        end: 'June 1, 2024',
      },
      {
        name: 'Ile Ijosin',
        description: 'Sunday weekly worship at Ile Ijosin with Oba Ela Agbaye',
        start: '10:00AM',
        end: '1:00PM',
      },
    ],
  },
  {
    date: 'July 2024',
    dateTime: '2024-07-01',
    summary: 'Watch out for updates...',
    timeSlots: [
      {
        name: 'Ile Ijosin',
        description: 'Sunday weekly worship at Ile Ijosin with Oba Ela Agbaye',
        start: '10:00AM',
        end: '1:00PM',
      },
    ],
  },
  {
    date: 'August 2024',
    dateTime: '2024-08-01',
    summary: 'Watch out for updates...',
    timeSlots: [
      {
        name: 'Ile Ijosin',
        description: 'Sunday weekly worship at Ile Ijosin with Oba Ela Agbaye',
        start: '10:00AM',
        end: '1:00PM',
      },
    ],
  },
]

function CalendarView() {
  let [tabOrientation, setTabOrientation] = useState('horizontal')

  useEffect(() => {
    let smMediaQuery = window.matchMedia('(min-width: 640px)')

    function onMediaQueryChange({ matches }: { matches: boolean }) {
      setTabOrientation(matches ? 'vertical' : 'horizontal')
    }

    onMediaQueryChange(smMediaQuery)
    smMediaQuery.addEventListener('change', onMediaQueryChange)

    return () => {
      smMediaQuery.removeEventListener('change', onMediaQueryChange)
    }
  }, [])

  return (
    <TabGroup
      className="relative mx-auto max-w-5xl grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3"
      vertical={tabOrientation === 'vertical'}
    >
      <TabList className="flex overflow-x-auto sm:flex-col">
        {({ selectedIndex }) => (
          <>
            {schedule.map((day, dayIndex) => (
              <Tab
                key={day.dateTime}
                className={clsx(
                  'relative p-4 cursor-pointer border rounded-lg text-center',
                  dayIndex !== selectedIndex && 'opacity-70'
                )}
              >
                <div className="text-xl font-semibold text-blue-900">
                  {day.date}
                </div>
                <p className="mt-2 text-gray-600">{day.summary}</p>
              </Tab>
            ))}
          </>
        )}
      </TabList>
      <TabPanels className="col-span-2">
        {schedule.map((day) => (
          <TabPanel
            key={day.dateTime}
            className="p-6 bg-white shadow-md rounded-lg"
          >
            <h3 className="text-2xl font-semibold text-blue-900 mb-4">
              <time dateTime={day.dateTime}>{day.date}</time>
            </h3>
            <ol className="space-y-4">
              {day.timeSlots.map((timeSlot, timeSlotIndex) => (
                <li
                  key={timeSlot.start}
                  className="border-b pb-2"
                >
                  {timeSlotIndex > 0 && (
                    <div className="mb-2 border-t border-gray-200" />
                  )}
                  <h4 className="text-lg font-semibold text-blue-900">
                    {timeSlot.name}
                  </h4>
                  {timeSlot.description && (
                    <p className="mt-1 text-gray-700">
                      {timeSlot.description}
                    </p>
                  )}
                  <p className="mt-1 text-sm text-gray-500">
                    <time dateTime={`${day.dateTime}T${timeSlot.start}-08:00`}>
                      {timeSlot.start}
                    </time>{' '}
                    -{' '}
                    <time dateTime={`${day.dateTime}T${timeSlot.end}-08:00`}>
                      {timeSlot.end}
                    </time>{' '}
                    WAT
                  </p>
                </li>
              ))}
            </ol>
          </TabPanel>
        ))}
      </TabPanels>
    </TabGroup>
  )
}

export function Schedule() {
  return (
    <section
      id="schedule"
      aria-label="Schedule"
      className="bg-white py-20 sm:py-32"
    >
      <div className="relative mt-14 sm:mt-24">
        <BackgroundImage position="right" className="-bottom-32 -top-40" />
        <Container className="relative">
          <CalendarView />
        </Container>
      </div>
    </section>
  )
}

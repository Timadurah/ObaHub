import React from 'react'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
interface PageProps {
  params: {
    id: string // Assuming the ID is a string
  }
}

const page = ({ params }: PageProps) => {
  const id = params.id // Access dynamic ID from query parameters
  return (
    <>
      <NavBar />
      <section className="evenstbg p-20">
        <div className="col-12 col-lg-5 mb-3 bg-white p-4 shadow">
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            Blog Topic
          </p>
          <p className="pb-2 text-left">
            Dont Forget to share if you love the Stories
          </p>
        </div>
      </section>

      <article className="col-lg-8 col-12 p-5 mx-auto">
        <h1 className="text-[#504f4f] ">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab,
          cupiditate.
        </h1>
        <div className="col-12 col-lg-7 mb-3 p-4 bg-white shadow">
        <p
          style={{ borderLeft: '3px solid gray' }}
          className="text-muted px-1 text-left"
        >
          Don't Forget To Check Out Our Social Channel
        </p>
        <p className="pb-2 text-left">
<a href=""> Youtube </a> || 
<a href=""> Facebook </a> || 
<a href=""> Twiter </a> || 
<a href=""> Instagram </a> </p>
      </div>
        <p className="p-2 text-[#333]">
          Lorem ipsum dolor sit amet consectetur, adipisicing elit.
          <br/>          <br/>
           Quia magni
          dignissimos nisi expedita ducimus necessitatibus repellat pariatur
          tempora voluptatibus, eius dolor nulla est quod minima ipsum facere
          facilis, aspernatur quas! Lorem ipsum dolor sit amet consectetur,
          adipisicing elit.
          <br/>          <br/>
           Quia magni dignissimos nisi expedita ducimus
          necessitatibus repellat pariatur tempora voluptatibus, eius dolor
          nulla est quod minima ipsum facere facilis, aspernatur quas! Lorem
          ipsum dolor sit amet consectetur, adipisicing elit.
          <br/>          <br/>
           Quia magni
          dignissimos nisi expedita ducimus necessitatibus repellat pariatur
          tempora voluptatibus, eius dolor nulla est quod minima ipsum facere
          facilis, aspernatur quas! Lorem ipsum dolor sit amet consectetur,
          adipisicing elit.
          <br/>          <br/>
           Quia magni dignissimos nisi expedita ducimus
          necessitatibus repellat pariatur tempora voluptatibus, eius dolor
          nulla est quod minima ipsum facere facilis, aspernatur quas! Lorem
          ipsum dolor sit amet consectetur, adipisicing elit.
          <br/>          <br/>
           Quia magni
          dignissimos nisi expedita ducimus necessitatibus repellat pariatur
          tempora voluptatibus, eius dolor nulla est quod minima ipsum facere
          facilis, aspernatur quas! Lorem ipsum dolor sit amet consectetur,
          adipisicing elit.
          <br/>          <br/>
           Quia magni dignissimos nisi expedita ducimus
          necessitatibus repellat pariatur tempora voluptatibus, eius dolor
          nulla est quod minima ipsum facere facilis, aspernatur quas! Lorem
          ipsum dolor sit amet consectetur, adipisicing elit.
          <br/>          <br/>
           Quia magni
          dignissimos nisi expedita ducimus necessitatibus repellat pariatur
          tempora voluptatibus, eius dolor nulla est quod minima ipsum facere
          facilis, aspernatur quas! Lorem ipsum dolor sit amet consectetur,
          adipisicing elit.
          <br/>          <br/>
           Quia magni dignissimos nisi expedita ducimus
          necessitatibus repellat pariatur tempora voluptatibus, eius dolor
          nulla est quod minima ipsum facere facilis, aspernatur quas! Lorem
          ipsum dolor sit amet consectetur, adipisicing elit.
          <br/>          <br/>
           Quia magni
          dignissimos nisi expedita ducimus necessitatibus repellat pariatur
          tempora voluptatibus, eius dolor nulla est quod minima ipsum facere
          facilis, aspernatur quas! Lorem ipsum dolor sit amet consectetur,
          adipisicing elit.
          <br/>          <br/>
           Quia magni dignissimos nisi expedita ducimus
          necessitatibus repellat pariatur tempora voluptatibus, eius dolor
          nulla est quod minima ipsum facere facilis, aspernatur quas!
        </p>
      </article>

      <Footer />
    </>
  )
}

export default page

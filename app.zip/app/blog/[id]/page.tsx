'use client'

import { useState, useEffect } from 'react'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'

// Define types for expected data structures
interface DivinationResult {
  id: string
  topic: string
  content: any
}

interface UserData {
  id: string
  name: string
  email: string
  // Add other user fields as needed
}

interface DivinationProps {
  params: {
    id: string // Dynamic ID parameter
  }
}

export default function Page({ params }: DivinationProps) {
  const id = params.id // Access dynamic ID from query parameters
  const [result, setResult] = useState<DivinationResult | null>(null)
  
  // Fetch data based on dynamic ID path
 
  // Fetch data based on dynamic ID path
  useEffect(() => {
    const fetchData = async () => {
      try {
        

        // Construct URL based on dynamic ID and user_id
        const url = `https://orentify.com/oba/blog_byid.php?id=${id}`;

        const response = await fetch(url);

        // Check if response is OK (status code 200-299)
        if (!response.ok) {
          if (response.status === 404) {
            console.error('Data not found (404).');
          } else {
            console.error('Error fetching data:', response.statusText);
          }
          setResult(null);
          return;
        }

        // Parse the JSON response
        const data = await response.json();
        console.log('API Response:', data); // Debugging: Print the API response

        if (data && data.topic !== 'Not Found') {
          setResult(data); // Assuming API returns a single result
        } else {
          setResult(null); // No matching result found
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        setResult(null);
      }
    };

    fetchData();
  }, [id]);
 // Run effect when id changes
  return (
    <>
      <NavBar />
      <section className="evenstbg p-20">
        <div className="col-12 col-lg-5 mb-3 bg-white p-4 shadow">
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            Blog and News
          </p>
          <p className="pb-2 text-left">
            Don't Forget to share if you love the Content
          </p>
        </div>
      </section>
      {result && (
        <article className="col-lg-8 col-12 mx-auto p-5">
          <h1 className="text-[#504f4f] ">
            {result ? result.topic : 'News / Blogs'}
          </h1>
          <div className="col-12 col-lg-7 mb-3 bg-white p-4 shadow">
            <p
              style={{ borderLeft: '3px solid gray' }}
              className="text-muted px-1 text-left"
            >
              Don't Forget To Check Out Our Social Channel
            </p>
            <p className="pb-2 text-left">
              <a href="https://www.youtube.com/@obaelaifa"> Youtube </a> ||
              <a href="https://www.facebook.com/Obaelaifa"> Facebook </a> ||
              <a href="https://x.com/ela_ltd"> Twiter </a> ||
              <a href="https://www.instagram.com/obaelaifa/?hl=en-gb"> Instagram </a>{' '}
            </p>
          </div>
          <p 
            className="p-2 text-[#333]"
            dangerouslySetInnerHTML={{ __html: result.content }}
          ></p>
        </article>
      )}
      <Footer />
    </>
  )
}

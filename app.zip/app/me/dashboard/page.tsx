'use client';
import React, { useEffect, useState } from 'react';
import Cookies from 'js-cookie';
import NavBar from '@/app/NavBar';
import Footer from '@/app/Footer';
import Bread from '@/app/components/bread';
import MeHeader from '@/app/me/meHeader';

interface ApiResponse {
  success: boolean;
  user?: any;
  error?: any;
}

interface User {
  full_name?: string;
  [key: string]: any; // Use a more specific interface for your user object
}

const Dashboard: React.FC = () => {
  const [adminCount, setAdminCount] = useState<number>(10); // Replace with real data
  const [premiumCount, setPremiumCount] = useState<number>(20); // Replace with real data
  const [freemiumCount, setFreemiumCount] = useState<number>(50); // Replace with real data
  const [userData, setUserData] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const visitors: string[] = ['Visitor 1', 'Visitor 2', 'Visitor 3'];
  const applicants: string[] = ['Applicant 1', 'Applicant 2', 'Applicant 3'];
  const matchmaking: string[] = ['Registration 1', 'Registration 2', 'Registration 3'];
  const consultationBooks: string[] = ['Book 1', 'Book 2', 'Book 3'];

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id');
        if (!userId) {
          location.href = '/login';
          return;
        }
        const userResponse = await fetch('https://orentify.com/oba/user_detail', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user_id: userId }),
        });

        if (!userResponse.ok) {
          location.href = './login';
          return;
        }

        const userData: ApiResponse = await userResponse.json();
        if (userData.success) {
          setUserData(userData.user ?? null);
        } else {
          setError(userData.error ?? 'An unknown error occurred');
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUserData();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="col-11 col-lg-8 mx-auto my-5">
            <div className="container mt-5">
              <h2 className="mb-4">Admin Dashboard</h2>

              {/* Stats Cards */}
              <div className="row text-center">
                <div className="col-md-4 mb-4">
                  <div className="card shadow-sm">
                    <div className="card-body">
                      <h5 className="card-title">Admin Users</h5>
                      <p className="card-text display-4">{adminCount}</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-4 mb-4">
                  <div className="card shadow-sm">
                    <div className="card-body">
                      <h5 className="card-title">Premium Subscriptions</h5>
                      <p className="card-text display-4">{premiumCount}</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-4 mb-4">
                  <div className="card shadow-sm">
                    <div className="card-body">
                      <h5 className="card-title">Freemium Subscriptions</h5>
                      <p className="card-text display-4">{freemiumCount}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Accordion for lists */}
              <div className="accordion">
                {/* Visitors */}
                <div className="accordion-item">
                  <input type="checkbox" id="accordion-1" className="accordion-toggle" />
                  <label htmlFor="accordion-1" className="accordion-label">Visitors List</label>
                  <div className="accordion-content">
                    <ul className="list-group">
                      {visitors.map((visitor, index) => (
                        <li key={index} className="list-group-item">{visitor}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Student Applicants */}
                <div className="accordion-item">
                  <input type="checkbox" id="accordion-2" className="accordion-toggle" />
                  <label htmlFor="accordion-2" className="accordion-label">Student Applicants List</label>
                  <div className="accordion-content">
                    <ul className="list-group">
                      {applicants.map((applicant, index) => (
                        <li key={index} className="list-group-item">{applicant}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Matchmaking Registrations */}
                <div className="accordion-item">
                  <input type="checkbox" id="accordion-3" className="accordion-toggle" />
                  <label htmlFor="accordion-3" className="accordion-label">Matchmaking Registrations List</label>
                  <div className="accordion-content">
                    <ul className="list-group">
                      {matchmaking.map((registration, index) => (
                        <li key={index} className="list-group-item">{registration}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Consultation Books */}
                <div className="accordion-item">
                  <input type="checkbox" id="accordion-4" className="accordion-toggle" />
                  <label htmlFor="accordion-4" className="accordion-label">Consultation Books List</label>
                  <div className="accordion-content">
                    <ul className="list-group">
                      {consultationBooks.map((book, index) => (
                        <li key={index} className="list-group-item">{book}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Dashboard;

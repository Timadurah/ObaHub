import React from "react";
import Bread from "../../components/bread";

const Page = () => {
    return ( <section>
    <Bread Title="Profile" Name="" />
    <div
        className="container 
        afterBread p-0 rounded shadow
         bg-white"
      >

<div className="col-12 border-bottom d-flex ">

<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0 text-primary" style={{borderRight: '1px solid lightgrey'}}>Setting</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Orders</div>
<div className="fontRs col-2 col-l-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Notifications</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Plans</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Logs</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0">Log out</div>

</div>

{/*  */}
<div className="p-2">
        <p class="display-6 fw-bold px-5 my-5 mx-5">Settings</p>
      <br className="d-md-block d-none" />
      <div className="d-flex flex-wrap justify-content-between col-12">

        {/*  */}
        <div style={{flexGrow: '1'}} className="d-flex col-lg-5 col-12 align-items-center h-custom-2 my-5 py-5 px-5 ms-xl-4 mt-3 mt-lg-3 pt-3 pt-lg-3 pt-xl-0 mt-xl-n5">
        <form
          className="col-12 my-5 bg-white p-5 rounded-3 shadow position-relative"
          method="post"
        >
          <div className="d-flex justify-content-between flex-column">
            <p className="text-muted">
                Login information setting
            </p>
            <div className="form-outline mx-2 mx-lg-0 col-12 mb-4">
              <label className="form-label">Change Email</label>
              <input
                className="bg-white form-control"
                type="text"
                name="fullName"
                id="fulname"
                required
                placeholder="Enter your Full name"
              />
            </div>
            <div className="form-outline mx-2 mx-lg-0 col-12 mb-4">
              <label className="form-label">Old Password</label>
              <input
                className="bg-white form-control"
                type="password"
                name="password"
                id="password"
                required
                placeholder="Enter your email"
              />
            </div><div className="form-outline mx-2 mx-lg-0 col-12 mb-4">
              <label className="form-label">New Password</label>
              <input
                className="bg-white form-control"
                type="password"
                name="password"
                id="password"
                required
                placeholder="Enter your email"
              />
            </div>
          </div>

          <div className="pt-1 mb-3 col-12">
            <button
              data-mdb-button-init
              data-mdb-ripple-init
              className="btn btn-dark btn-lg btn-block col-12"
              type="button"
            >
              Update
            </button>
          </div>

          <p className="small mb-3 pb-lg-2">
            <a className="text-muted" href="#!">
              Please Carefully input your login data
            </a>
          </p>
          <p>
            You dont want to change this?
            <a href="./" className="link-info mx-4">
              Go Back Home
            </a>
          </p>
        </form>
      </div>
      
      <div style={{flexGrow: '1',flexDirection: 'column'}} className="d-flex col-lg-5 col-12 align-items-start 
      h-custom-2 my-5 py-5 px-5 ms-xl-4 mt-3 mt-lg-3 pt-3 pt-lg-3 pt-xl-0 mt-xl-n5">
        <h5 className="text-muted">
            Order Detail Settings
        </h5>
        <form
          className="col-12 my-5 bg-white p-5 rounded-3 shadow position-relative"
          method="post"
        >
          <div className="d-flex justify-content-between flex-column">
            <div className="form-outline mx-2 mx-lg-0 col-12 mb-4">
            
              <label className="form-label"> Order delivery Address
              </label>
              <input
                className="bg-white form-control"
                type="text"
                name="fullName"
                id="fulname"
                required
                placeholder="Enter your Full Address"
              />
            </div>
            <div className="form-outline mx-2 mx-lg-0 col-12 mb-4">
              <label className="form-label">Delivery Phone</label>
              <input
                className="bg-white form-control"
                type="password"
                name="password"
                id="password"
                required
                placeholder="Enter your Phone"
              />
            </div>
          </div>

          <div className="pt-1 mb-3 col-12">
            <button
              data-mdb-button-init
              data-mdb-ripple-init
              className="btn btn-outline-primary text-primary btn-lg btn-block col-12"
              type="button"
            >
              Add Order Info
            </button>
          </div>

          
        </form>
      </div>
      </div>
      {/*  */}
    </div>
{/*  */}
        </div>


  </section>);
};

export default Page;

'use client'

import React, { useEffect, useState } from 'react'
import Bread from '@/app/components/bread'
import MeHeader from '@/app/me/meHeader'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Cookies from 'js-cookie'
interface UserData {
  full_name: string
  email: string
  delivery_address: string
  delivery_phone: string
}

interface ApiResponse {
  success: boolean
  user?: UserData
  error?: string
}

const Page = () => {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [email, setEmail] = useState<string>('')
  const [oldPassword, setOldPassword] = useState<string>('')
  const [newPassword, setNewPassword] = useState<string>('')
  const [deliveryAddress, setDeliveryAddress] = useState<string>('')
  const [deliveryPhone, setDeliveryPhone] = useState<string>('')

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id') // Get the user_id from the cookie

        if (!userId) {
          location.href = '/login'
          return
        }

        const response = await fetch(
          'https://orentify.com/oba/user_detail',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId }), 
            // Send user_id in the request body
          }
        )

        if (!response.ok) {
          location.href = './login'
          return
        }

        const data: ApiResponse = await response.json()
        if (data.success) {
          setUserData(data.user ?? null)
        } else {
          setError(data.error ?? 'An unknown error occurred')
        }
      } catch (err: any) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  const handleUpdate = async () => {
    try {
      const userId = Cookies.get('user_id')

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_UPDATE_USER_URL}`,
        {
          // Update this to your actual API endpoint
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            user_id: userId,
            email,
            old_password: oldPassword,
            new_password: newPassword,
            delivery_address: deliveryAddress,
            delivery_phone: deliveryPhone,
          }),
        }
      )

      const data: ApiResponse = await response.json()
      if (data.success) {
        alert('Update successful')
        // Optionally redirect or clear the form here
      } else {
        alert(`Update failed: ${data.error}`)
      }
    } catch (error: any) {
      alert(`An error occurred: ${error.message}`)
    }
  }

  if (loading) {
    return (
      <div
        style={{
          width: '100vw',
          height: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div className="fw-bold display-4 rounded-md p-4 text-black">
          OBA ELA IFA
        </div>
      </div>
    )
  }

  if (error) {
    return <p>Error: {error}</p>
  }

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="p-2">
            <p className="display-6 fw-bold mx-3 my-5 px-5">Settings</p>
            <br className="d-md-block d-none" />
            <div className="d-flex justify-content-between col-12 flex-wrap">
              <div
                style={{ flexGrow: '1' }}
                className="d-flex col-lg-5 col-12 align-items-center h-custom-2 ms-xl-4 mt-lg-3 pt-lg-3 pt-xl-0 mt-xl-n5 my-5 mt-0 px-0 px-lg-5 py-0 pt-0"
              >
                <form
                  className="col-12 rounded-3 position-relative my-0 my-lg-5 border bg-white p-5"
                  onSubmit={(e) => {
                    e.preventDefault()
                    handleUpdate()
                  }}
                >
                  <div className="d-flex justify-content-between flex-column">
                    <p className="text-muted">Login information setting</p>
                    <div className="form-outline mx-lg-0 col-12 mx-2 mb-4">
                      <label className="form-label">Change Email</label>
                      <input
                        className="form-control bg-white"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        placeholder="Enter your new email"
                      />
                    </div>
                    <div className="form-outline mx-lg-0 col-12 mx-2 mb-4">
                      <label className="form-label">Old Password</label>
                      <input
                        className="form-control bg-white"
                        type="password"
                        value={oldPassword}
                        onChange={(e) => setOldPassword(e.target.value)}
                        required
                        placeholder="Enter your old password"
                      />
                    </div>
                    <div className="form-outline mx-lg-0 col-12 mx-2 mb-4">
                      <label className="form-label">New Password</label>
                      <input
                        className="form-control bg-white"
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                        placeholder="Enter your new password"
                      />
                    </div>
                  </div>
                  <div className="col-12 mb-3 pt-1">
                    <button
                      data-mdb-button-init
                      data-mdb-ripple-init
                      className="btn btn-dark btn-lg btn-block col-12"
                      type="submit"
                    >
                      Update
                    </button>
                  </div>
                  <p className="small pb-lg-2 mb-3">
                    <a className="text-muted" href="#!">
                      Please carefully input your login data
                    </a>
                  </p>
                  <p>
                    You don&#39;t want to change this?
                    <a href="../" className="link-info mx-4">
                      Go Back Home
                    </a>
                  </p>
                </form>
              </div>
              <div
                style={{ flexGrow: '1', flexDirection: 'column' }}
                className="d-flex col-lg-5 col-12 align-items-center h-custom-2 ms-xl-4 mt-lg-3 pt-lg-3 pt-xl-0 mt-xl-n5 my-5 mt-0 px-0 px-lg-5 py-0 pt-0"

              >
                <form
                  className="col-12 rounded-3 position-relative my-0 my-lg-5 border bg-white p-5 p-lg-5"
                  onSubmit={(e) => {
                    e.preventDefault()
                    handleUpdate()
                  }}
                >
                  <div className="d-flex justify-content-between flex-column">
                    <div className="form-outline mx-lg-0 col-12 mx-2 mb-4">
                      <label className="form-label">
                        Order Delivery Address
                      </label>
                      <textarea
                        className="form-control text-dark bg-white"
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        required
                        placeholder="Enter your full address"
                      />
                    </div>
                    <div className="form-outline mx-lg-0 col-12 mx-2 mb-4">
                      <label className="form-label">Delivery Phone</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        value={deliveryPhone}
                        onChange={(e) => setDeliveryPhone(e.target.value)}
                        required
                        placeholder="Enter your phone"
                      />
                    </div>
                  </div>
                  <div className="col-12 mb-3 pt-1">
                    <button
                      data-mdb-button-init
                      data-mdb-ripple-init
                      className="btn btn-outline-primary text-primary btn-lg btn-block col-12"
                      type="submit"
                    >
                      Add Order Info
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default Page

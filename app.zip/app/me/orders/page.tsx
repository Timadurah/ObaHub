import React from "react";
import Bread from "../../components/bread";
import MyOrdercard from "./myOrdercard";
import MeHeader from "../meHeader";

const Page = () => {
    return ( <section>
    <Bread Title="Profile" Name="" />
    <div
        className="container 
        afterBread p-0 rounded shadow
         bg-white"
      >

<MeHeader />

{/*  */}
<div className="p-lg-5 p-2">
        <p className="display-6 fw-bold px-5 my-5 mx-5">My orders</p>
      <br className="d-md-block d-none d-flex" />
      <div className="d-flex flex-wrap">
        
             <MyOrdercard />
             <MyOrdercard />
             <MyOrdercard />
             <MyOrdercard />
             <MyOrdercard />
             <MyOrdercard />
             <MyOrdercard />

              </div>
        </div>
</div>

  </section>);
};

export default Page;

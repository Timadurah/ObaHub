import React from "react";
import Bread from "../../components/bread";

const Page = () => {
    return ( <section>
    <Bread Title="Profile" Name="" />
    <div
        className="container 
        afterBread p-0 rounded shadow
         bg-white"
      >

<div className="col-12 border-bottom d-flex ">

<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Setting</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0 text-primary" style={{borderRight: '1px solid lightgrey'}}>Orders</div>
<div className="fontRs col-2 col-l-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Notifications</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Plans</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0" style={{borderRight: '1px solid lightgrey'}}>Logs</div>
<div className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0">Log out</div>

</div>

{/*  */}
<div className="p-lg-5 p-2">
        <p class="display-6 fw-bold px-5 my-5 mx-5">My orders</p>
      <br className="d-md-block d-none d-flex" />
      <div className="d-flex flex-wrap">
        
              {/* <!-- Product--> */}
              <div className="d-flex d-sm-flex m-3 shadow align-items-start col-10 col-lg-4" style={{borderRadius: '20px'}}>
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img style={{borderRadius: '20px 0 0 20px'}}
                    className="col-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="p-3"> 
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Project Devices Showcase (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    #18.<small>00</small>
                  </div>
                  
                 
                </div>
              </div>
              {/* <!-- Product--> */}{/* <!-- Product--> */}
              <div className="d-flex d-sm-flex m-3 shadow align-items-start col-10 col-lg-4" style={{borderRadius: '20px'}}>
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img style={{borderRadius: '20px 0 0 20px'}}
                    className="col-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="p-3"> 
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Project Devices Showcase (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    #18.<small>00</small>
                  </div>
                  
                 
                </div>
              </div>
              {/* <!-- Product--> */}{/* <!-- Product--> */}
              <div className="d-flex d-sm-flex m-3 shadow align-items-start col-10 col-lg-4" style={{borderRadius: '20px'}}>
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img style={{borderRadius: '20px 0 0 20px'}}
                    className="col-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="p-3"> 
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Project Devices Showcase (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    #18.<small>00</small>
                  </div>
                  
                 
                </div>
              </div>
              {/* <!-- Product--> */}{/* <!-- Product--> */}
              <div className="d-flex d-sm-flex m-3 shadow align-items-start col-10 col-lg-4" style={{borderRadius: '20px'}}>
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img style={{borderRadius: '20px 0 0 20px'}}
                    className="col-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="p-3"> 
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Project Devices Showcase (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    #18.<small>00</small>
                  </div>
                  
                 
                </div>
              </div>
              {/* <!-- Product--> */}{/* <!-- Product--> */}
              <div className="d-flex d-sm-flex m-3 shadow align-items-start col-10 col-lg-4" style={{borderRadius: '20px'}}>
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img style={{borderRadius: '20px 0 0 20px'}}
                    className="col-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="p-3"> 
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Project Devices Showcase (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    #18.<small>00</small>
                  </div>
                  
                 
                </div>
              </div>
              {/* <!-- Product--> */}{/* <!-- Product--> */}
              <div className="d-flex d-sm-flex m-3 shadow align-items-start col-10 col-lg-4" style={{borderRadius: '20px'}}>
                <a
                  className="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto"
                  href="marketplace-single.html"
                  style={{ width: "12.5rem" }}
                >
                  <img style={{borderRadius: '20px 0 0 20px'}}
                    className="col-3 w-100"
                    src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                    alt="Product"
                  />
                  <span
                    className="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2"
                    data-bs-toggle="tooltip"
                    aria-label="Remove from Favorites"
                    data-bs-original-title="Remove from Favorites"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-trash3"
                      viewBox="0 0 16 16"
                    >
                      <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                    </svg>
                  </span>
                </a>
                <div className="p-3"> 
                  <h3 className="h6 product-title mb-2">
                    <a href="marketplace-single.html" className="text-black">
                      Project Devices Showcase (PSD)
                    </a>
                  </h3>
                  <div className="d-inline-block text-accent">
                    #18.<small>00</small>
                  </div>
                  
                 
                </div>
              </div>
              {/* <!-- Product--> */}

              </div>
        </div>
</div>

  </section>);
};

export default Page;

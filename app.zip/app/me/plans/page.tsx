'use client'
import React, { useEffect, useState } from 'react'
import Bread from '@/app/components/bread'
import SubscriptionCard from '@/app/components/subscriptionCard'
import MeHeader from '@/app/me/meHeader'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Cookies from 'js-cookie'

interface User {
  full_name: string
  // Add other properties based on the actual user data structure
}

interface Subscription {
  sub_plan_mode: 'free' | 'premium'
  // Add other properties based on the actual subscription data structure
}

interface ApiResponse<T> {
  success: boolean
  data?: T
  user?: any
  error?: string
  message?: string
}

const Page: React.FC = () => {
  const [userData, setUserData] = useState<User | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const userId = Cookies.get('user_id')

  useEffect(() => {
    const fetchUserData = async () => {
      if (!userId) {
        location.href = '../login'
        return
      }

      try {
        const response = await fetch('https://orentify.com/oba/user_detail', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ user_id: userId }),
        })

        if (!response.ok) {
          location.href = './login'
          return
        }

        const data: ApiResponse<User> = await response.json()
        if (data.success) {
          setUserData(data.user ?? null)
        } else {
          setError(data.error ?? 'Unknown error')
        }
      } catch (err) {
        setError((err as Error).message)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [userId])

  useEffect(() => {
    const fetchSubscriptionData = async () => {
      if (!userId) {
        return
      }

      try {
        const response = await fetch(
          'https://orentify.com/oba/subscriptionmode',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId }),
          }
        )

        const data: ApiResponse<Subscription> = await response.json()

        if (data.success) {
          setSubscription(data.data ?? null)
        } else {
          console.error('Failed to fetch subscription:', data.message)
        }
      } catch (error) {
        console.error('Error fetching subscription:', (error as Error).message)
      }
    }

    fetchSubscriptionData()
  }, [userId])

  if (loading) {
    return (
      <div
        style={{
          width: '100vw',
          height: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div className="fw-bold color-naw display-4 rounded-md p-4 ">
          OBA ELA IFA
        </div>
      </div>
    )
  }

  if (error) {
    return <p>Error: {error}</p>
  }

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name ?? 'Home > Plans'} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="p-2">
            <SubscriptionCard
              mode={subscription?.sub_plan_mode ?? 'free'}
              type="registered"
            />
          </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default Page

// import React, { useEffect, useState } from 'react';
// import NavBar from '@/app/NavBar';
// import Footer from '@/app/Footer';

// const UserInfo = () => {
//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchUserData = async () => {
//       try {
//         const response = await fetch('https://orentify.com/oba/user_detail', {
//           method: 'GET',
//           headers: {
//             'Content-Type': 'application/json',
//           },
//         });

//         if (!response.ok) {
//           throw new Error('Failed to fetch user data');
//         }

//         const data = await response.json();

//         if (data.success) {
//           setUserData(data.user);
//         } else {
//           setError(data.error);
//         }
//       } catch (err) {
//         setError(err.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchUserData();
//   }, []);

//   if (loading) {
//     return <p>Loading...</p>;
//   }

//   if (error) {
//     return <p>Error: {error}</p>;
//   }

//   return (
//     <>
//       <NavBar />
//       <section>
//         <div className="container">
//           <div className="row">
//             <div className="col-12">
//               <h3>User Information</h3>
//               {userData && (
//                 <div className="user-info">
//                   <p><strong>Full Name:</strong> {userData.full_name}</p>
//                   <p><strong>Email:</strong> {userData.email}</p>
//                   <p><strong>Address:</strong> {userData.address}</p>
//                   <p><strong>Social:</strong> <a href={userData.social}>{userData.social}</a></p>
//                   <p><strong>Nationality:</strong> {userData.nationality}</p>
//                   <p><strong>State of Origin:</strong> {userData.state_of_origin}</p>
//                   <p><strong>City:</strong> {userData.city}</p>
//                   <p><strong>Marital Status:</strong> {userData.marital_status}</p>
//                   <p><strong>Date of Birth:</strong> {userData.date_of_birth}</p>
//                   <p><strong>Phone:</strong> {userData.phone}</p>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </section>
//       <Footer />
//     </>
//   );
// };

// export default UserInfo;

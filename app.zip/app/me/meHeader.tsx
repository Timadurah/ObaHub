"use client"
import React from "react";
import Cookies from 'js-cookie'
const MeHeader = () => {
  const userId: any = Cookies.get('user_id') // Get the user_id from the cookie
  let isAdmin: boolean = false
  if(userId == 404){
    isAdmin = true
  }
  const handleLogout = () => {
      // Clear cookies
      Cookies.remove('user_id');
  
      // Redirect to login page
      location.href = '/login';
    };
  
  return (
    
      <div className="col-12 border-bottom d-flex ">
        <div
          className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0"
          style={{ borderRight: "1px solid lightgrey" }}
        >
      <a href="./setting" className="text-black">    Setting</a>
        </div>

        {isAdmin ? (
                   <div
                   className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0"
                   style={{ borderRight: "1px solid lightgrey" }}
                 >
                  <a href="./publish" className="text-black">  Publish </a>
                 </div>
                  ) : (
                    <></>
                  )}

        <div
          className="fontRs col-3 p-4 d-flex align-items-center justify-content-center btn rounded-0"
          style={{ borderRight: "1px solid lightgrey" }}
        >
        <a href="./plans" className="text-black">   Plans</a>
        </div>
        <div
          className="fontRs col-2 p-4 d-flex align-items-center justify-content-center btn rounded-0"
          style={{ borderRight: "1px solid lightgrey" }}
        >
         <a href="./logs" className="text-black">  Logs </a>
        </div>
        <div className="fontRs col-3 p-4 d-flex align-items-center justify-content-center btn rounded-0"  onClick={handleLogout}>
         Log out
        </div>
      </div>
    
  );
};

export default MeHeader;

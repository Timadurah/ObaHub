import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Divination from '@/app/divination/Divination'

export default function Page() {
  return (
    <main>     
      <NavBar />
      <Divination />
      <Footer />
    </main>
  )
}

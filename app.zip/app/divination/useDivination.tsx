import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

// Define types for divination result (adjust based on actual data)
interface DivinationResult {
  content: string;
  topic: string;
  id: string;
  // Add other fields if necessary
}

const useDivination = (initialQuery: string = '') => {
  const [searchTerm, setSearchTerm] = useState<string>(initialQuery);
  const [results, setResults] = useState<DivinationResult[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  // Fetch data from the API (same endpoint for both initial load and search)
  const fetchData = useCallback(async (query: string = '') => {
    setLoading(true);
    setError('');

    try {
      const url = query
        ? `https://orentify.com/oba/divinitions.php?query=${encodeURIComponent(query)}`
        : `https://orentify.com/oba/divinitions.php`;

      const response = await axios.get(url);

      if (Array.isArray(response.data) && response.data.length > 0) {
        setResults(response.data);
      } else {
        setResults([]);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('An error occurred while fetching data.');
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch initial data on mount
  useEffect(() => {
    fetchData(''); // Load data on page load with no query
  }, [fetchData]);

  // Function to handle search queries
  const handleSearch = (query: string) => {
    fetchData(query); // Use the same function to search
  };

  return {
    searchTerm,
    setSearchTerm,
    results,
    loading,
    error,
    handleSearch,
  };
};

export default useDivination;

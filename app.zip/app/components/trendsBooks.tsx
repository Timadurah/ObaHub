import React from "react";

const TrendsBooks = (props: { Title: string | number | bigint | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | Promise<React.AwaitedReactNode> | null | undefined; }) => {
  return (
    <>
      <div className="d-flex mb-3 my-5 container border-bottom py-3">
        <h2 className="display-6 mb-0">{props.Title}</h2>
      </div>

      <section className="container my-5 d-flex flex-wrap">
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
        <div
          className="card col-4 col-lg-3  m-lg-4 m-2 shadow"
          style={{ flexGrow: "1" }}
        >
          <img
            src="https://fastly.picsum.photos/id/7/4728/3168.jpg?hmac=c5B5tfYFM9blHHMhuu4UKmhnbZoJqrzNOP9xjkV4w3o"
            className="card-img-top"
            alt="..."
          />
          <div className="card-body">
            <h5 className="card-title text-black fw-bold">
              Bili from the high Land
            </h5>
            <p className="card-text text-muted">Reserve Price</p>
            <b className="fw-bold text-black">23,00 Naira</b>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item btn btn-primary text-orange d-flex align-items-center justify-content-center">
              {" "}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-bag-plus-fill mx-3 text-orange"
                viewBox="0 0 16 16"
              >
                <path
                  fill-rule="evenodd"
                  d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z"
                />
              </svg>{" "}
              Add To Cart
            </li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default TrendsBooks;

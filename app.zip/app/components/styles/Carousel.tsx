// components/Carousel.js
import React, { useState } from 'react';
import Image from 'next/image';
import TvimageOne from '@/images/5775921785903105074.jpg';
import TvimageTwo from '@/images/5775921785903105075.jpg';
import TvimageThree from '@/images/5775921785903105076.jpg';
import styles from './Carousel.module.css';

const Carousel = () => {
  const images = [TvimageOne, TvimageTwo, TvimageThree];

  // Define unique content for each carousel item
  const slideContent = [
    {
        title: 'Join Our Community',
      description: 'Become a part of our vibrant community. Engage in meaningful discussions, events, and activities.',
      linkText: 'Join Us Now',
      linkUrl: '/community'
    },
    {
      title: 'Our Services',
      description: 'Discover the variety of services we offer to enrich your spiritual journey and deepen your connection with the world.',
      linkText: 'Learn More About Our Services',
      linkUrl: '/services'
    },
    {
        title: 'Upcoming Events',
        description: 'Check out our upcoming events, mark your calendar, and come join us in exploring wisdom, understanding of nature, and love.',
        linkText: 'Check Our Upcoming Events',
        linkUrl: '/events'
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const goToPrevious = () => {
    const newIndex = currentIndex === 0 ? images.length - 1 : currentIndex - 1;
    setCurrentIndex(newIndex);
  };

  const goToNext = () => {
    const newIndex = currentIndex === images.length - 1 ? 0 : currentIndex + 1;
    setCurrentIndex(newIndex);
  };

  return (
    <div className={styles.carousel_x}>
      <div
        className={styles.carouselInner}
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {images.map((image, index) => (
          <div className={styles.carouselItem} key={index}>
            <Image
              src={image}
              alt={`Slide ${index}`}
              className={styles.image}
            />
            <div className={styles.content}>
              <div className="col-8 col-lg-8 mb-3 p-4 bg-white shadow">
                <p
                  style={{ borderLeft: '3px solid gray' }}
                  className="text-muted px-1 text-left"
                >
                  {slideContent[index].title}
                </p>
                <p className="pb-2 text-left">
                  {slideContent[index].description}
                </p>
                <a
                  href={slideContent[index].linkUrl}
                  className="bg-naw p-3 text-white"
                >
                  {slideContent[index].linkText}
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Left and Right Controls */}
      <button className={styles.leftButton} onClick={goToPrevious}>
        &#10094;
      </button>
      <button className={styles.rightButton} onClick={goToNext}>
        &#10095;
      </button>
    </div>
  );
};

export default Carousel;

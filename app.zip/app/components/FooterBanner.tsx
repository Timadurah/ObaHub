import React from 'react';
export default function FooterBanner() {
  return (
   
      <section id="features" className="py-28 bg-naw">
        <div className="container mx-auto flex flex-col space-y-12 px-4 md:flex-row md:space-y-0">
          <div className="flex flex-col space-y-10 md:w-1/2">
            <h2 className="text-dark max-w-md justify-center text-center text-white text-3xl font-semibold md:text-left">
              What Makes Obaelaifa Unique?
            </h2>
            <p className="max-w-sm text-center text-white md:text-left">
              Obaelaifa offers everything you need for your spiritual journey,
              from matchmaking services to spiritual books and traditional
              medicine. Our platform is crafted to enhance your spiritual
              experience.
            </p>
          </div>
          <div className="flex flex-col space-y-8 md:w-1/2">
            <div className="flex flex-col space-y-3 md:flex-row md:space-x-6 md:space-y-0">
              <div className="bg-primarylight rounded-full md:bg-transparent">
                <div className="flex items-center space-x-3">
                  <div className="bg-primary rounded-full shadow px-4 py-2 text-white md:py-1">
                    01
                  </div>
                  <h3 className="text-base font-semibold md:mb-4 md:hidden">
                    Spiritual Matchmaking
                  </h3>
                </div>
              </div>
              <div>
                <h3 className="hidden text-xl font-semibold md:block">
                  Spiritual Matchmaking
                </h3>
                <p className="mt-3 text-[gray]">
                  Find your soulmate through our unique spiritual matchmaking
                  services tailored to connect individuals on a deeper level.
                </p>
              </div>
            </div>
            <div className="flex flex-col space-y-3 md:flex-row md:space-x-6 md:space-y-0">
              <div className="bg-primarylight rounded-full md:bg-transparent">
                <div className="flex items-center space-x-3">
                  <div className="bg-primary rounded-full shadow px-4 py-2 text-white md:py-1">
                    02
                  </div>
                  <h3 className="text-base font-semibold md:mb-4 md:hidden">
                    Sacred Texts and Spiritual Books
                  </h3>
                </div>
              </div>
              <div>
                <h3 className="hidden text-xl font-semibold md:block">
                  Sacred Texts and Spiritual Books
                </h3>
                <p className="mt-3 text-[gray]">
                  Access a wide range of spiritual books, including sacred texts
                  and teachings from Odu Ifa, to deepen your spiritual
                  knowledge.
                </p>
              </div>
            </div>
            <div className="flex flex-col space-y-3 md:flex-row md:space-x-6 md:space-y-0">
              <div className="bg-primarylight rounded-full md:bg-transparent">
                <div className="flex items-center space-x-3">
                  <div className="bg-primary rounded-full shadow px-4 py-2 text-white md:py-1">
                    03
                  </div>
                  <h3 className="text-base font-semibold md:mb-4 md:hidden">
                    Traditional Healing and Medicine
                  </h3>
                </div>
              </div>
              <div>
                <h3 className="hidden text-xl font-semibold md:block">
                  Traditional Healing and Medicine
                </h3>
                <p className="mt-3 text-[gray]">
                  Explore our collection of spiritual and traditional medicines
                  to aid in your healing process, combining ancient wisdom with
                  modern needs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
     
  )
}

import React from 'react'

interface GalleryImageProps {
  src: string
  alt: string
}

const GalleryImage: React.FC<GalleryImageProps> = ({ src, alt }) => {
  return (
    <div className="mb-4">
      <img
        src={src}
        alt={alt}
        className="h-auto w-full rounded-lg object-cover"
      />
    </div>
  )
}

const GallerySection: React.FC = () => {
  const images = [
    { src: 'https://via.placeholder.com/200x400', alt: 'Image 1' },
    { src: 'https://via.placeholder.com/400x600', alt: 'Image 2' },
    { src: 'https://via.placeholder.com/300x400', alt: 'Image 3' },
    { src: 'https://via.placeholder.com/100x100', alt: 'Image 4' },
    { src: 'https://via.placeholder.com/400x500', alt: 'Image 5' },
    { src: 'https://via.placeholder.com/600x900', alt: 'Image 6' },
    { src: 'https://via.placeholder.com/300x300', alt: 'Image 7' },
    { src: 'https://via.placeholder.com/200x400', alt: 'Image 009' },
    { src: 'https://via.placeholder.com/300x400', alt: 'Image 3' },
    { src: 'https://via.placeholder.com/300x400', alt: 'Image 3' },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="mb-8 text-center text-3xl font-bold">OBA ELA IFA GALLERY</h2>
      <div
        className="masonry sm:masonry-sm md:masonry-md lg:masonry-lg gap-4"
        style={{ columnCount: 3, columnGap: '1rem' }}
      >
        {images.map((image, index) => (
          <GalleryImage key={index} src={image.src} alt={image.alt} />
        ))}
      </div>
    </div>
  )
}

export default GallerySection

import React from "react";
import Image from 'next/image'

const AcademyPost = (props: { Title: string | number | bigint | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | Promise<React.AwaitedReactNode> | null | undefined; }) => {
  return (
    <>
      <div className="d-flex mb-3 my-5 container border-bottom py-3">
        <h2 className="display-6 mb-0">{props.Title}</h2>
      </div>

      <section className="container my-5 d-flex flex-wrap">
        {/*  */}
        <div className="card m-3 col-5" style={{ maxWidth: "540px", flexGrow: '1' }}>
          <div className="row g-0">
            <div className="col-md-4">
              <Image
                src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                className="img-fluid rounded-start h-100"
                alt="..."
              />
            </div>
            <div className="col-md-8">
              <div className="card-body">
                <h5 className="card-title text-black">Course Title</h5>
                <p className="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
                <p className="card-text d-flex flex-wrap justify-content-end">
                  <div className="btn btn-outline-primary mx-3 col-8 col-lg-5 ">Enroll</div>
                </p>
              </div>
            </div>
          </div>
        </div>
        {/*  */} {/*  */}
        <div className="card m-3 col-5" style={{ maxWidth: "540px", flexGrow: '1' }}>
          <div className="row g-0">
            <div className="col-md-4">
              <Image
                src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                className="img-fluid rounded-start h-100"
                alt="..."
              />
            </div>
            <div className="col-md-8">
              <div className="card-body">
                <h5 className="card-title text-black">Course Title</h5>
                <p className="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
                <p className="card-text d-flex flex-wrap justify-content-end">
                  <div className="btn btn-outline-primary mx-3 col-8 col-lg-5 ">Enroll</div>
                </p>
              </div>
            </div>
          </div>
        </div>
        {/*  */} {/*  */}
        <div className="card m-3 col-5" style={{ maxWidth: "540px", flexGrow: '1' }}>
          <div className="row g-0">
            <div className="col-md-4">
              <Image
                src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                className="img-fluid rounded-start h-100"
                alt="..."
              />
            </div>
            <div className="col-md-8">
              <div className="card-body">
                <h5 className="card-title text-black">Course Title</h5>
                <p className="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
                <p className="card-text d-flex flex-wrap justify-content-end">
                  <div className="btn btn-outline-primary mx-3 col-8 col-lg-5 ">Enroll</div>
                </p>
              </div>
            </div>
          </div>
        </div>
        {/*  */} {/*  */}
        <div className="card m-3 col-5" style={{ maxWidth: "540px", flexGrow: '1' }}>
          <div className="row g-0">
            <div className="col-md-4">
              <Image
                src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                className="img-fluid rounded-start h-100"
                alt="..."
              />
            </div>
            <div className="col-md-8">
              <div className="card-body">
                <h5 className="card-title text-black">Course Title</h5>
                <p className="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
                <p className="card-text d-flex flex-wrap justify-content-end">
                  <div className="btn btn-outline-primary mx-3 col-8 col-lg-5 ">Enroll</div>
                </p>
              </div>
            </div>
          </div>
        </div>
        {/*  */} {/*  */}
        <div className="card m-3 col-5" style={{ maxWidth: "540px", flexGrow: '1' }}>
          <div className="row g-0">
            <div className="col-md-4">
              <Image
                src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                className="img-fluid rounded-start h-100"
                alt="..."
              />
            </div>
            <div className="col-md-8">
              <div className="card-body">
                <h5 className="card-title text-black">Course Title</h5>
                <p className="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
                <p className="card-text d-flex flex-wrap justify-content-end">
                  <div className="btn btn-outline-primary mx-3 col-8 col-lg-5 ">Enroll</div>
                </p>
              </div>
            </div>
          </div>
        </div>
        {/*  */} {/*  */}
        <div className="card m-3 col-5" style={{ maxWidth: "540px", flexGrow: '1' }}>
          <div className="row g-0">
            <div className="col-md-4">
              <Image
                src="https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA"
                className="img-fluid rounded-start h-100"
                alt="..."
              />
            </div>
            <div className="col-md-8">
              <div className="card-body">
                <h5 className="card-title text-black">Course Title</h5>
                <p className="card-text">
                  This is a wider card with supporting text below as a natural
                  lead-in to additional content. This content is a little bit
                  longer.
                </p>
                <p className="card-text d-flex flex-wrap justify-content-end">
                  <div className="btn btn-outline-primary mx-3 col-8 col-lg-5 ">Enroll</div>
                </p>
              </div>
            </div>
          </div>
        </div>
        {/*  */}
      </section>
    </>
  );
};

export default AcademyPost;

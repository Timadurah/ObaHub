import React from 'react'

import Image from 'next/image'
import Line from '@/images/line.png'
import TvimageOne from '@/images/5775921785903105071.jpg'
import TvimageTwo from '@/images/5775921785903105072.jpg'
import TvimageThree from '@/images/5775921785903105073.jpg'

const LatestBlog = () => {
  return (
    <>
      <h1 className="fw-bold mx-auto my-3 text-center text-black">
        Latest News & Stories
      </h1>
      <p className="mx-auto text-center text-[#464646]">
        Keep up with the latest OBAELAIFA news & stories!
      </p>
      <Image
        src={Line}
        alt="Obaelaifa tv image"
        className="mx-auto my-3 h-[100px]"
      />
      <br />

      <div className="d-flex container flex-wrap justify-between bg-white p-20">
        <div className="col-lg-3 col-12 mb-3 bg-white">
          <Image
            src={TvimageOne}
            alt="Obaelaifa tv image"
            className="h-[250px] w-[100%]"
          />
          <h6 className="fw-bold py-3">WOMEN BUILD</h6>
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            New New and Storie
          </p>
          <p className="pb-2 text-left">
            Steve happily stands beside his 22-year-old F150 Ford truck. Back in
            2002, Cape Coral resident Steve obtained his residential
            contractor’s license, a milestone marked by the purchase of a
          </p>
          <button className="bg-naw p-3 text-white">Read More</button>
        </div>
        <div className="col-lg-3 col-12 mb-3">
          <div className="col-12 mb-3 bg-white">
            <h6 className="fw-bold py-3">WOMEN BUILD</h6>
            <p
              style={{ borderLeft: '3px solid gray' }}
              className="text-muted px-1 text-left"
            >
              New New and Storie
            </p>
            <p className="pb-2 text-left">
              Steve happily stands beside his 22-year-old F150 Ford truck. Back
              in 2002, Cape Coral resident Steve obtained his residential
              contractor’s license, a milestone marked by the purchase of a
            </p>
            <button className="bg-naw p-3 text-white">Read More</button>
          </div>
          <div className="col-12 mb-3 bg-white">
            <h6 className="fw-bold py-3">WOMEN BUILD</h6>
            <p
              style={{ borderLeft: '3px solid gray' }}
              className="text-muted px-1 text-left"
            >
              New New and Storie
            </p>
            <p className="pb-2 text-left">
              Steve happily stands beside his 22-year-old F150 Ford truck. Back
              in 2002, Cape Coral resident Steve obtained his residential
              contractor’s license, a milestone marked by the purchase of a
            </p>
            <button className="bg-naw p-3 text-white">Read More</button>
          </div>
        </div>
        <div className="col-lg-3 col-12 mb-3">
          <div className="col-12 my-auto mb-3 bg-white text-center">
            <Image
              src={TvimageTwo}
              alt="Obaelaifa tv image"
              className="w-[100%]"
            />
          </div>{' '}
          <div className="col-12 my-auto mb-3 bg-white text-center">
            <Image
              src={TvimageThree}
              alt="Obaelaifa tv image"
              className="w-[100%]"
            />
          </div>
        </div>
      </div>
    </>
  )
}

export default LatestBlog

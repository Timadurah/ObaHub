import React from 'react'

const Bread = (props: {Title :string, Name: string}) => {
  return (
    
    <div className=" w-100 bg-darki p-5" style={{height: '35vh'}}>      
<div className="container d-flex justify-content-start py-2 align-items-center">
    <h3 className="display-6 text-white f-light  d-flex justify-content-start py-2 align-items-center">
      {props.Title} <small style={{fontSize: '1.3rem'}} className="mx-2"> {props.Name} </small>
    </h3>
</div>
    </div>   
  )
}
export default Bread

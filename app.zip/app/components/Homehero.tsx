import React from "react";
import styles from "./Homehero.module.css";
const Homehero = () => {
  return (
    <section className="mt-8">
      <div className="container-fluid">
        {/* <!-- row --> */}
        <div className="d-md-flex my-5 d-block justify-content-center flex-wrap">
          {/* first */}
          <div
            className="col-lg-6 col-12 py-5 rounded-3 m-md-5 m-2 d-flex
             flex-column align-item-start align-item-lg-center justify-content-start justify-content-lg-center
             px-lg-5 BannerOne"
            style={{ maxHeight: "80vh" }}
          >
            <div className="col-12 col-lg-7 p-4">
              <p className="text-darki">
                Exclusive Offer
                <span className="bg-primary p-1 rounded text-white mx-1">
                  20%
                </span>
              </p>
              <h1 className="display-5 text-darki">
                Explore the secretes behind the Gods
              </h1>
              <p className="text-darki">
                Read and enjoy your Exploration anay where you go.
              </p>
              <p className="text-darki">
                Start from
                <em className="display-7 text-primary mx-2">50,000 Naira</em>
              </p>

              <div className="btn btn-primary"> Add To Cart</div>
            </div>
          </div>
          {/* second  */}
          <div
            className="col-lg-4 col-12 my-5 m-md-5 m-2"
            style={{ maxHeight: "78vh" }}
          >
            <div className=" bg-light col-12 p-3 rounded-3 mb-3 h-50 px-lg-3 BannerOne">
              <div className="transparentL rounded h-100 p-2 d-flex flex-column align-items-start justify-content-center ">
                <h1 className="display-6 text-white">Ese Kerin Olufa</h1>
                <p className="text-white">
                  Read and enjoy your Exploration anay where you go.
                </p>
                <div className="btn btn-primary"> Buy Now</div>
              </div>
            </div>

            <div className=" bg-light col-12 p-3 rounded-3 h-50 align-items-center px-lg-3 BannerOne">
              <div className="transparentL rounded h-100 p-2">
                <h1 className="display-6 text-white">How to Mix Ogun Awure</h1>
                <p className="text-white">
                  Read and enjoy your Exploration anay where you go. Read and
                  enjoy your Exploration anay where you go. Read and
                </p>

                <div className="btn btn-primary"> Read More</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Homehero;

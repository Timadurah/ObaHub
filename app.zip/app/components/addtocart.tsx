import Cookies from 'js-cookie';

export const addToCart = async (productID: any, quantity = 1) => {
  // Prepare the data to be sent in the request
  const user_id = Cookies.get("user_id") || ''; // Ensure user_id is a string or empty string
  const cartData = new URLSearchParams({
    user_id: user_id,
    product_id: String(productID), // Convert productID to string
    quantity: String(quantity) // Convert quantity to string
  });

  try {
    // Send the POST request to the server
    const response = await fetch('https://orentify.com/oba/shop/addcart.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: cartData.toString(),
    });

    // Check if the response is OK (status code 200-299)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    // Parse the JSON response
    const result = await response.json();
    
    // Check for errors in the result
    if (result.error) {
      throw new Error(result.error);
    }

    // Optionally return the result or handle it as needed
    return result;
  } catch (error) {
    // Handle errors
    console.error('Error adding to cart:', error);
    throw error; // Re-throw the error if needed
  }
};

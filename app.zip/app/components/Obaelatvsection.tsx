import React from 'react'
import Image from 'next/image'
import TvimageOne from '@/images/5775921785903105071.jpg'
import TvimageTwo from '@/images/5775921785903105072.jpg'
import TvimageThree from '@/images/5775921785903105073.jpg'

const Obaelatvsection = () => {
  return (
    <div className='bg-light d-flex flex-wrap container justify-between p-20 '>
    <div className="bg-white text-center col-lg-3 col-12 mb-3">
    <Image
                        src={TvimageOne}
                        alt="Obaelaifa tv image"
                        className="w-[100%] h-[250px]"
                      />
                      <h3 className='fw-bold text-center py-2'>WOMEN BUILD</h3>
                      <p className='pb-2'>The mission of Women Build is to engage women in the effort to provide safe and decent homes for families in need of affordable housing.</p>
                      <button className='p-3 text-white bg-naw'>Women Build</button>
    </div>
      
<div className="bg-white text-center col-lg-3 col-12 mb-3">
<Image
                    src={TvimageTwo}
                    alt="Obaelaifa tv image"
                    className="w-[100%] h-[250px]"
                  />
                  <h3 className='fw-bold text-center py-2'>WOMEN BUILD</h3>
                  <p className='pb-2'>The mission of Women Build is to engage women in the effort to provide safe and decent homes for families in need of affordable housing.</p>
                  <button className='p-3 text-white bg-naw'>Women Build</button>
</div>
      
<div className="bg-white text-center col-lg-3 col-12 mb-3">
<Image
                    src={TvimageThree}
                    alt="Obaelaifa tv image"
                    className="w-[100%] h-[250px]"
                  />
                  <h3 className='fw-bold text-center py-2'>WOMEN BUILD</h3>
                  <p className='pb-2'>The mission of Women Build is to engage women in the effort to provide safe and decent homes for families in need of affordable housing.</p>
                  <button className='p-3 text-white bg-naw'>Women Build</button>
</div>
          
    </div>
  )
}

export default Obaelatvsection

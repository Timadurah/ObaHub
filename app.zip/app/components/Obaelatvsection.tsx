import React from 'react'
import Image from 'next/image'
import TvimageOne from '@/images/5775921785903105071.jpg'
import TvimageTwo from '@/images/5775921785903105072.jpg'
import TvimageThree from '@/images/5775921785903105073.jpg'

const Obaelatvsection = () => {
  return (
    <div className="bg-light pt-5 d-flex container flex-wrap justify-between">
      <div className="col-lg-3 col-12 mb-3 bg-white text-center">
        <iframe
          className="h-[250px] w-[100%]"
          src="https://www.youtube.com/embed/dF7Orz-Ap_0?si=Jh1h1z1CSqO9jIaB"
          title="YouTube video player"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        ></iframe>

        <h3 className="fw-bold py-2 text-center">SCIENCE AMD WISDOM</h3>
        <p className="pb-2">
          IYATO LAARIN IRUNMOLE , ORISA ATI AWON ONILE/ALALE.
        </p>
        <a
          href="https://youtu.be/dF7Orz-Ap_0?si=hqdGNd0_RYC0BY7g"
          className="bg-naw p-3 text-white"
        >
          CHECK OUT
        </a>
      </div>

      <div className="col-lg-3 col-12 mb-3 bg-white text-center">
        <iframe
          width="560"
          height="315"
          src="https://www.youtube.com/embed/j41piYNK_JU?si=W3y5YEaCgHNghrPY"
          title="YouTube video player"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          className="h-[250px] w-[100%]"
        ></iframe>

        <h3 className="fw-bold py-2 text-center">WONDERING?</h3>
        <p className="pb-2">SE O SEESE KI A TE IFA NI IGBA MEJI?</p>
        <a href="https://youtu.be/j41piYNK_JU?si=bZgByhNF8h_MGs9P" className="bg-naw p-3 text-white">
          CHECK OUT
        </a>
      </div>

      <div className="col-lg-3 col-12 mb-3 bg-white text-center">
        <iframe
          className="h-[250px] w-[100%]"
          src="https://www.youtube.com/embed/MbPUTzLgk_I?si=ZrbaiUG9Jz2wMRYB"
          title="YouTube video player"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        ></iframe>
      
        <h3 className="fw-bold py-2 text-center">SCIENCE AMD WISDOM</h3>
        <p className="pb-2">IS OLOKUN A MAN OR A WOMAN?</p>
        <a href="https://youtu.be/MbPUTzLgk_I?si=5dXtgzWPr59dCl3F" className="bg-naw p-3 text-white">
          CHECK OUT
        </a>
      </div>
    </div>
  )
}

export default Obaelatvsection

import React, { useState, useEffect } from 'react';
import Cookies from 'js-cookie';
import styles from '@/app/components/LoadingPlaceholders.module.css';
import { addToCart } from '@/app/components/addtocart'; // Adjust the import path as needed
import Image from 'next/image'

// Define types for product and props
interface Product {
  id: number;
  product_name: string;
  author: string;
  category: string;
  price: number;
  amount_available: number;
  image_path: string;
  rating: number;
}

interface ShopCardProps {
  topic: string;
}

const ShopCard: React.FC<ShopCardProps> = ({ topic }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [products, setProducts] = useState<Product[]>([]);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  // Handle add to cart
  const handleAddToCart = async (productID: number) => {
    try {
      const result = await addToCart(productID);
      console.log('Added to cart:', result);
    } catch (error) {
      console.error('Add to cart error:', error);
    }
  };

  // Fetch all products from the API
  const fetchAllProducts = async () => {
    setLoading(true);
    try {
      const response = await fetch('https://orentify.com/oba/shop/getbooks.php');
      const result: Product[] = await response.json();
      setAllProducts(result);
      setProducts(result);
    } catch (error) {
      console.error('Error fetching all products:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch search results from API based on search query
  const fetchProducts = async (query: string) => {
    setLoading(true);
    try {
      const response = await fetch(`https://orentify.com/oba/shop/booksearch.php?query=${encodeURIComponent(query)}`);
      const result: Product[] = await response.json();
      setProducts(result);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  // Fetch all products on component mount
  useEffect(() => {
    fetchAllProducts();
  }, []);

  // Fetch products based on search query
  useEffect(() => {
    if (searchQuery) {
      fetchProducts(searchQuery);
    } else {
      setProducts(allProducts);
    }
  }, [searchQuery, allProducts]);

  return (
    <>
      <br />
      <div className="col-12 mx-auto bg-light py-5 text-center">
        <p className="mb-5 mt-2 text-3xl font-bold tracking-tight text-black sm:text-4xl">
          {topic}
        </p>
      </div>
      <div className="mb-md-4 container mb-2 pb-5">
        <div className="bg-light rounded-3 mt-n5 mb-4 border p-3">
          <div className="d-flex align-items-center ps-2">
            <div className="input-group">
              <i className="fa-search position-absolute top-50 translate-middle-y fs-md start-0 ms-3"></i>
              <input
                className="form-control border-0 shadow-none"
                type="text"
                placeholder="Search For Spiritual things..."
                value={searchQuery}
                onChange={handleSearchChange}
              />
            </div>
          </div>
        </div>
        {loading && (
          <div className={styles.loadingContainer}>
            <div className={styles.loadingRow}>
              <div className={styles.loadingPlaceholder}></div>
              <div className={styles.loadingPlaceholder}></div>
              <div className={styles.loadingPlaceholder}></div>
            </div>
            <div className={styles.loadingRow}>
              <div className={styles.loadingPlaceholder}></div>
              <div className={styles.loadingPlaceholder}></div>
              <div className={styles.loadingPlaceholder}></div>
            </div>
            <div className={styles.loadingRow}>
              <div className={styles.loadingPlaceholder}></div>
              <div className={styles.loadingPlaceholder}></div>
              <div className={styles.loadingPlaceholder}></div>
            </div>
          </div>
        )}
        <div className="row mx-n2 pt-3">
          {products.length > 0
            ? products.map((product) => {
                const imagePaths = product.image_path.split(',');
                const firstImagePath = imagePaths.length > 0 ? imagePaths[0] : '';

                return (
                  <div
                    className="col-lg-3 col-md-4 col-sm-6 mb-grid-gutter px-2"
                    key={product.id}
                  >
                    <div className="card product-card-alt">
                      <div className="product-thumb">
                        <a
                          className="product-thumb-overlay"
                          href={`/shop/${product.id}`}
                        ></a>
                        {firstImagePath && (
                          <Image
                            src={`https://orentify.com/oba/${firstImagePath}`}
                            alt={product.product_name}
                            style={{ height: '220px' }}
                          />
                        )}
                      </div>
                      <div className="card-body">
                        <div className="d-flex justify-content-between align-items-start flex-wrap pb-2">
                          <div className="text-muted fs-xs me-1">
                            by{' '}
                            <a
                              className="product-meta fw-medium"
                              href={`/shop/${product.id}`}
                            >
                              {product.author}.
                            </a>
                            in{' '}
                            <a
                              className="product-meta fw-medium"
                              href={`/shop/${product.id}`}
                            >
                              {product.category}
                            </a>
                          </div>
                          <div className="star-rating">
                            {[...Array(5)].map((_, starIndex) => (
                              <i
                                key={starIndex}
                                className={`star-rating-icon ${starIndex < product.rating ? 'active' : ''}`}
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  fill="currentColor"
                                  className="text-primary bi bi-star-fill"
                                  viewBox="0 0 16 16"
                                >
                                  <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />
                                </svg>
                              </i>
                            ))}
                          </div>
                        </div>
                        <h3 className="product-title fs-sm mb-2">
                          <a href={`/shop/${product.id}`}>
                            {product.product_name}
                          </a>
                        </h3>
                        <div className="d-flex justify-content-between align-items-center flex-wrap">
                          <div className="fs-sm me-2">
                            <i className="fa-download text-muted me-1"></i>
                            {product.amount_available}
                            <span className="fs-xs ms-1">available</span>
                          </div>
                          <div className="bg-faded-accent text-accent rounded-1 px-2 py-1">
                            &#8358;<small> {product.price}</small>
                          </div>
                        </div>
                        <div className="flex justify-between">
                          <a
                            href={`/shop/${product.id}`}
                            className="btn btn-outline-primary col-5 align-center fw-bold my-2 flex justify-center"
                          >
                            Buy
                          </a>
                          <div
                            onClick={() => handleAddToCart(product.id)}
                            className="btn btn-primary align-center fw-bold my-2 flex justify-center text-center"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="25"
                              height="25"
                              fill="currentColor"
                              className="bi bi-cart-plus-fill"
                              viewBox="0 0 16 16"
                            >
                              <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 3.5 12h9a.5.5 0 0 0 .49-.607l1.498-7.985L14.39 2H15.5a.5.5 0 0 0 0-1H.5zM4.45 6.86a.5.5 0 0 0 .496-.41L6.43 1H10.57l1.486 5.45a.5.5 0 0 0 .496.41h3.096a.5.5 0 0 1 .485.605L14.86 10h-1.17A2.5 2.5 0 0 1 11.5 12H4.5A2.5 2.5 0 0 1 2.21 10H1.04L.5 7.465a.5.5 0 0 1 .485-.605h3.096zM11 11a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 1 0v-1A.5.5 0 0 0 11 11zM8.5 10a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 1 0v-1a.5.5 0 0 0-.5-.5z" />
                            </svg>
                            <span className="text-white ms-1">Add to cart</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            : !loading && (
                <div className="text-center text-muted py-5">
                  No products found.
                </div>
              )}
        </div>
      </div>
    </>
  );
};

export default ShopCard;

import React from 'react'

import Image from 'next/image'
import Line from '@/images/line.png'

const TvTub = () => {
  return (
    <>
      <br />
      <br />
      <br />
      <h1 className="fw-bold mx-auto my-3 text-center text-black">
        Watch Us On OBAELAIFA TV
      </h1>
      <p className="mx-auto text-center text-[#464646]">
        Keep up with the latest OBAELAIFA news & stories!
      </p>
      <Image
        src={Line}
        alt="Obaelaifa tv image"
        className="mx-auto my-3 h-[100px]"
      />
      <br />

      <div className="d-flex container flex-wrap justify-between bg-white p-20">
        <div className="col-lg-3 col-12 mb-3 bg-white">
          <iframe
            src="https://www.youtube.com/embed/ktccff291YA?si=Zt2-GBdpVCLm66Fd"
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            className="h-[250px] w-[100%]"
          ></iframe>
          
          <h6 className="fw-bold py-3">On Youtube Now</h6>
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            healing Time
          </p>
          <p className="pb-2 text-left">
            TRADO MEDICAL TREATMENT FOR 5 PERSONS WITH HEART/ LIVER/KIDNEY
            DISEASES, DIABETES AND BREAST CANCER
          </p>
          <a
            href="https://www.youtube.com/c/ObaElaIfa"
            className="bg-naw p-3 text-white"
          >
            Watch Us Now!
          </a>
        </div>
        <div className="col-lg-3 col-12 mb-3">
          <div className="col-12 mb-3 bg-white">
            <p
              style={{ borderLeft: '3px solid gray' }}
              className="text-muted px-1 text-left"
            >
              Family Education
            </p>
            <p className="pb-2 text-left">
            Fight between Muslims and isese because of a converted isese woman.

            </p>
            <a href='https://www.youtube.com/watch?v=CPkdPdxC1MA&t=45s' className="bg-naw p-3 text-white">Watch Now</a>
          </div>
          <div className="col-12 mb-3 bg-white">
            <h6 className="fw-bold py-3">News On Youtube Now</h6>
            
            <p className="pb-2 text-left">
            AGBOTIFAYO GIFTED HIS WIFE A VENZA CAR!WATCH AND SEE WHAT OBA ELA DID TOO.
            </p>
            <a href='https://www.youtube.com/watch?v=R5gncah2xq8' className="bg-naw p-3 text-white">Check Out</a>
          </div>

          <div className="col-12 mb-3 bg-white">
          <p
              style={{ borderLeft: '3px solid gray' }}
              className="text-muted px-1 text-left"
            >
              Family Education
            </p>            
            <p className="pb-2 text-left">
            AGBOTIFAYO GIFTED HIS WIFE A VENZA CAR!WATCH AND SEE WHAT OBA ELA DID TOO.
            </p>
            <a href='https://www.youtube.com/watch?v=R5gncah2xq8' className="bg-naw p-3 text-white">Check Out</a>
          </div>
        </div>
        <div className="col-lg-3 col-12 mb-3 bg-white">
          <iframe
            src="https://www.youtube.com/embed/sWEryKPQv5g?si=ewhNgEc94ovmT18r"
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            className="h-[250px] w-[100%]"
          ></iframe>
          
          <h6 className="fw-bold py-3">On Youtube Now</h6>
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            Ifa Through Out The World
          </p>
          <p className="pb-2 text-left">
          OYINBO (WHITE MAN)EXPLAINED WHAT OTURA OGBE SAYS ABOUT ISESE THIS YEAR . OYINBO HAVE TAKEN OVER.
          </p>
          <a
            href="https://www.youtube.com/c/ObaElaIfa"
            className="bg-naw p-3 text-white"
          >
            Watch Us Now!
          </a>
        </div>
      </div>
    </>
  )
}

export default TvTub

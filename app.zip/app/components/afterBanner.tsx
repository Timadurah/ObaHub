import React from 'react'

const AfterBanner = () => {
  return (
    <div className='d-flex flex-wrap'>
        <div className="col-lg-3 col-12  bg-[#24d824] p-4" > 
            <h2 className='fw-bold text-white'>Hero text One</h2>
            <p className='text-white'>Explore the path to homeownership through Habitat.</p>
            <br />
            <div className="btn text-white border-white btn-outline-primary">Learn More</div>
        </div>
        <div className="col-lg-3 col-12  bg-[#a8c524] p-4" > 
            <h2 className='fw-bold text-white'>Hero text One</h2>
            <p className='text-white'>Explore the path to homeownership through Habitat.</p>
            <br />
            <div className="btn text-white border-white btn-outline-primary">Learn More</div>
        </div>
        <div className="col-lg-3 col-12 bg-[#c55228]  p-4" > 
            <h2 className='fw-bold text-white'>Hero text One</h2>
            <p className='text-white'>Explore the path to homeownership through Habitat.</p>
            <br />
            <div className="btn text-white border-white btn-outline-primary">Learn More</div>
        </div>
        <div className="col-lg-3 col-12 bg-[#585656] p-4" > 
            <h2 className='fw-bold text-white'>Hero text One</h2>
            <p className='text-white'>Explore the path to homeownership through Habitat.</p>
            <br />
            <div className="btn text-white border-white btn-outline-primary">Learn More</div>
        </div>
      
    </div>
  )
}

export default AfterBanner

import React from 'react'

const AfterBanner = () => {
  return (
    <div className='d-flex flex-wrap'>
        <div className="col-lg-3 col-12 bg-[#24d824] p-4">
            <h2 className='fw-bold text-white'>Spiritual Medicine</h2>
            <p className='text-white'>Discover remedies and healing practices tailored to your spiritual needs.</p>
            <br />
            <a href="/shop" className="btn text-white border-white btn-outline-primary">Learn More</a>
        </div>
        <div className="col-lg-3 col-12 bg-[#a8c524] p-4">
            <h2 className='fw-bold text-white'>Matchmaking</h2>
            <p className='text-white'>Find your destined partner through our unique spiritual matchmaking service.</p>
            <br />
            <a href="/signup-search-love" className="btn text-white border-white btn-outline-primary">Learn More</a>
        </div>
        <div className="col-lg-3 col-12 bg-[#c55228] p-4">
            <h2 className='fw-bold text-white'>Ifa Divination</h2>
            <p className='text-white'>Learn the sacred art of Ifa divination and explore deeper spiritual wisdom.</p>
            <br />
            <a href="/divination" className="btn text-white border-white btn-outline-primary">Learn More</a>
        </div>
        <div className="col-lg-3 col-12 bg-[#585656] p-4">
            <h2 className='fw-bold text-white'>Consultation</h2>
            <p className='text-white'>Receive guidance and clarity through one-on-one spiritual consultations.</p>
            <br />
            <a href="/consultation" className="btn text-white border-white btn-outline-primary">Learn More</a>
        </div>
    </div>
  )
}

export default AfterBanner

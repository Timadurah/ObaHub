import React from "react";
import AcademyPost from "../components/AcademyPost";

const Single = () => {
  return (
    <section className="container">
      <div className="bg-white border-bottom py-4">
        <div className="container d-lg-flex justify-content-between py-2 py-lg-3">
          <div className="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb flex-lg-nowrap justify-content-center justify-content-lg-start">
                <li className="breadcrumb-item">
                  <a className="text-nowrap" href="index.html">
                    <i className=" fa fa-home"></i>Home
                  </a>
                </li>
                <li className="breadcrumb-item text-nowrap">
                  <a href="#">Academy</a>
                </li>
                <li
                  className="breadcrumb-item text-nowrap active"
                  aria-current="page"
                >
                  Learn
                </li>
              </ol>
            </nav>
          </div>
          <div className="order-lg-1 pe-lg-4 text-center text-lg-start">
            <h1 className="h3 mb-0">Academy Page</h1>
          </div>
        </div>
      </div>
      <div className="row pt-5 mt-md-2">
          <section className="col-lg-8">
            
            {/* <!-- Gallery--> */}
            <div className="gallery row pb-2">
              <div className="col-lg-8 col-11">
                <a className="gallery-item rounded-3 mb-grid-gutter" href="https://picsum.photos/id/1/400"
                data-lg-id="2dd22e6a-054e-4e67-b235-257d1c8ef494">
              <img src="https://picsum.photos/id/1/490" alt="Gallery image" className="rounded m-3 col-12" /></a></div>
              <div className="col-sm-4">
                <a className="gallery-item rounded-3 mb-grid-gutter" href="https://picsum.photos/id/1/400" 
                data-lg-id="5d1ba361-8ae8-46b7-b803-79dbb6a72b18">
              <img src="https://picsum.photos/id/1/200/230" alt="Gallery image" className="rounded m-3"/></a>
              <a className="gallery-item rounded-3 mb-grid-gutter" href="https://picsum.photos/id/1/400"
                data-lg-id="d19332ce-08a1-4777-b2dc-78e0cb1cc9d5">
              <img src="https://picsum.photos/id/1/200/230" alt="Gallery image" className="rounded m-3" />
              
              </a></div>
            </div>
           {/*  */}
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut enim ad minima veniam, quis nostrum exercitationem occaecat cupidatat non proident.</p>
            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <blockquote className="testimonial my-4 pt-4 pb-2">
              <div className="card border-0 shadow-sm"><span className="testimonial-mark"></span>
                <div className="card-body fs-md">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</div>
              </div>
              <footer className="d-flex align-items-center justify-content-center pt-4">
                                <div className="ps-3">
                  <h6 className="fs-sm mb-n1 py-2">Themmy Oba</h6><span className="fs-ms text-muted">The Author</span>
                </div>
              </footer>
            </blockquote>
            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est.</p>
            {/* <!-- Post tags + sharing--> */}
            <div className="d-flex flex-wrap justify-content-between pt-2 pb-4 mb-1">
              <div className="mt-3 me-3"><a className="btn-outline-primary btn me-2 mb-2" href="#">#merchandise</a><a className="btn-outline-primary btn mb-2" href="#">#printed tshirts</a></div>
              <div className="mt-3"><span className="d-inline-block align-middle text-muted fs-sm me-3 mt-1 mb-2">Share post:</span>
              <a className="btn-ouline-primary btn p-2 shadow  bs-facebook me-2 mb-2" href="#"><i className=" fa fa-facebook"></i></a>
              <a className="btn-ouline-primary btn p-2 shadow  bs-twitter me-2 mb-2" href="#"><i className=" fa fa-twitter"></i></a>
              <a className="btn-ouline-primary btn p-2 shadow  bs-pinterest me-2 mb-2" href="#"><i className=" fa fa-pinterest"></i></a>
              </div>
            </div>
             {/* <!-- Comments--> */}
            <div className="pt-2 mt-5" id="comments">
              <h2 className="h4">Comments<span className="badge bg-dark fs-sm text-white align-middle ms-2">3</span></h2>
              {/* <!-- comment--> */}
              <div className="d-flex align-items-start py-4 border-bottom">
                <img className="rounded shadow" src="https://picsum.photos/id/1/200/300" width="50" height="50" alt="Laura Willson" />
                <div className="ps-3">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <h6 className="fs-md mb-0">Laura Willson</h6><a className="btn btn-outline-primary nav-link-style fs-sm fw-medium" href="#"><i className=" fa fa-reply me-2"></i>Reply</a>
                  </div>
                  <p className="fs-md mb-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat cupidatat non proident, sunt in culpa qui.</p><span className="fs-ms text-muted"><i className=" fa fa-time align-middle me-2"></i>Sep 7, 2019</span>
                  {/* <!-- comment reply--> */}
                  <div className="d-flex align-items-start border-top pt-4 mt-4">
                    <img className="rounded shadow" src="https://picsum.photos/id/1/200/300" width="50" height="50" alt="Michael Davis" />
                    <div className="ps-3">
                      <div className="d-flex justify-content-between align-items-center mb-2">
                        <h6 className="fs-md mb-0">Michael Davis</h6>
                      </div>
                      <p className="fs-md mb-1">Egestas sed sed risus pretium quam vulputate dignissim. A diam sollicitudin tempor id eu nisl. Ut porttitor leo a diam. Bibendum at varius vel pharetra vel turpis nunc.</p><span className="fs-ms text-muted"><i className=" fa fa-time align-middle me-2"></i>Sep 13, 2019</span>
                    </div>
                  </div>
                </div>
              </div>
              {/* <!-- comment--> */}
              <div className="d-flex align-items-start py-4">
                <img className="rounded shadow" src="https://picsum.photos/id/1/200/300" width="50" height="50" alt="Benjamin Miller" />
                <div className="ps-3">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <h6 className="fs-md mb-0">Benjamin Miller</h6><a className="btn btn-outline-primary nav-link-style fs-sm fw-medium" href="#"><i className=" fa fa-reply me-2"></i>Reply</a>
                  </div>
                  <p className="fs-md mb-1">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat cupidatat non proident, sunt in culpa qui.</p><span className="fs-ms text-muted"><i className=" fa fa-time align-middle me-2"></i>Aug 15, 2019</span>
                </div>
              </div>
              {/* <!-- Post comment form--> */}
              <div className="card border-0 shadow mt-2 mb-4">
                <div className="card-body">
                  <div className="d-flex align-items-start">
                    <img className="rounded shadow" src="https://picsum.photos/id/1/200/300" width="50" height="50" alt="Mary Alice" />
                    <form className="w-100 needs-validation ms-3" >
                      <div className="mb-3">
                        <textarea className="form-control" placeholder="Write comment..."  ></textarea>
                        <div className="invalid-feedback">Please write your comment.</div>
                      </div>
                      <button className="btn btn-primary btn-sm" type="submit">Post comment</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <aside className="col-lg-4">
            {/* <!-- Sidebar--> */}
            <div className="offcanvas offcanvas-collapse offcanvas-end border-start ms-lg-auto" id="blog-sidebar" style={{maxWidth: '22rem'}}>
             
              <div className="offcanvas-body py-grid-gutter py-lg-1 px-lg-4" data-simplebar="init" data-simplebar-auto-hide="true" style={{overflow: 'hidden'}}>
                <div className="simplebar-wrapper" style={{margin: '-4px -24px'}}><div className="simplebar-height-auto-observer-wrapper">
                  <div className="simplebar-height-auto-observer"></div>
                </div><div className="simplebar-mask"><div className="simplebar-offset" style={{right: '0px', bottom: '0px'}} >
                  <div className="simplebar-content-wrapper"  role="region" aria-label="scrollable content" style={{height: 'auto', overflow: 'hidden'}}>
                    <div className="simplebar-content" style={{padding: '4px 24px'}}>
                {/* <!-- Categories--> */}
                <div className="widget widget-links mb-grid-gutter pb-grid-gutter border-bottom mx-lg-2">
                  <h5 className="widget-title">Content categories</h5>
                  <ul className="widget-list">
                    <li className="widget-list-item"><a className="widget-list-link d-flex justify-content-between align-items-center text-muted" href="#"><span>Online shopping</span><span className="fs-xs text-muted ms-3">18</span></a></li>
                    <li className="widget-list-item"><a className="widget-list-link d-flex justify-content-between align-items-center text-muted" href="#"><span>Fashion</span><span className="fs-xs text-muted ms-3">25</span></a></li>
                    <li className="widget-list-item"><a className="widget-list-link d-flex justify-content-between align-items-center text-muted" href="#"><span>Personal finance</span><span className="fs-xs text-muted ms-3">13</span></a></li>
                    <li className="widget-list-item"><a className="widget-list-link d-flex justify-content-between align-items-center text-muted" href="#"><span>Travel &amp; vacation</span><span className="fs-xs text-muted ms-3">7</span></a></li>
                    <li className="widget-list-item"><a className="widget-list-link d-flex justify-content-between align-items-center text-muted" href="#"><span>Lifestyle</span><span className="fs-xs text-muted ms-3">34</span></a></li>
                    <li className="widget-list-item"><a className="widget-list-link d-flex justify-content-between align-items-center text-muted" href="#"><span>Technology</span><span className="fs-xs text-muted ms-3">6</span></a></li>
                  </ul>
                </div>
                {/* <!-- Trending posts--> */}
                <div className="widget mb-grid-gutter pb-grid-gutter border-bottom mx-lg-2 py-3">
                  <h5 className="widget-title p-3">Trending posts</h5>
                  <div className="d-flex align-items-center mb-3"><a className="flex-shrink-0" href="blog-single.html">
                    <img className="rounded" src="https://picsum.photos/id/1/64" height="64" width="64" alt="Post image" /></a>
                    <div className="ps-3">
                      <h6 className="blog-entry-title fs-sm mb-0"><a href="blog-single.html" className="text-dark">Retro Cameras are Trending. Why so Popular?</a>
                      </h6><span className="fs-ms text-muted">by <a href="#" className="blog-entry-meta-link text-muted">Andy Williams</a></span>
                    </div>
                  </div>
                  <div className="d-flex align-items-center mb-3"><a className="flex-shrink-0 text-dark" href="blog-single.html">
                    <img className="rounded" src="https://picsum.photos/id/1/64" height="64" width="64" alt="Post image" /></a>
                    <div className="ps-3">
                      <h6 className="blog-entry-title fs-sm mb-0"><a href="blog-single.html" className="text-dark">New Trends in Suburban Fashion</a></h6><span className="fs-ms text-muted">by <a href="#" className="blog-entry-meta-link text-muted">Susan Mayer</a></span>
                    </div>
                  </div>
                  <div className="d-flex align-items-center"><a className="flex-shrink-0 text-dark" href="blog-single.html">
                    <img className="rounded" src="https://picsum.photos/id/1/64" height="64" width="64" alt="Post image" /></a>
                    <div className="ps-3">
                      <h6 className="blog-entry-title fs-sm mb-0"><a href="blog-single.html" className="text-dark">Augmented Reality - Game Changing Technology</a></h6><span className="fs-ms text-muted">by <a href="#" className="blog-entry-meta-link text-muted">John Doe</a></span>
                    </div>
                  </div>
                </div>
                {/* <!-- Popular tags--> */}
                <div className="widget pb-grid-gutter mx-lg-2 py-3">
                  <h5 className="widget-title py-3">Popular tags</h5><a className="btn-outline-primary btn me-2 mb-2" href="#">#fashion</a><a className="btn-outline-primary btn me-2 mb-2" href="#">#gadgets</a>
                  <a className="btn-outline-primary btn me-2 mb-2" href="#">#online shopping</a><a className="btn-outline-primary btn me-2 mb-2" href="#">#top brands</a><a className="btn-outline-primary btn me-2 mb-2" href="#">#travel</a>
                  <a className="btn-outline-primary btn me-2 mb-2" href="#">#cartzilla news</a><a className="btn-outline-primary btn me-2 mb-2" href="#">#personal finance</a><a className="btn-outline-primary btn me-2 mb-2" href="#">#tips &amp; tricks</a>
                </div>
                {/* <!-- Promo banner--> */}
                <div className="bg-size-cover bg-position-center rounded-3 py-5 mx-lg-2" style={{backgroundImage: 'url(https://fastly.picsum.photos/id/28/4928/3264.jpg?hmac=GnYF-RnBUg44PFfU5pcw_Qs0ReOyStdnZ8MtQWJqTfA)'}}>
                  <div className="py-5 px-4 text-center">
                    <h5 className="mb-2 text-white">Your Add Banner Here</h5>
                    <p className="fs-sm text-white">Hurry up to reserve your spot</p><a className="btn btn-primary btn-shadow btn-sm" href="#">Contact us</a>
                  </div>
                </div>
              </div></div></div></div><div className="simplebar-placeholder" style={{width: 'auto', height: '1081px'}}></div></div><div className="simplebar-track simplebar-horizontal" style={{visibility: 'hidden'}}>
                <div className="simplebar-scrollbar" style={{width: '0px', display: 'none'}}></div></div>
              <div className="simplebar-track simplebar-vertical" style={{visibility: 'hidden'}}><div className="simplebar-scrollbar" style={{height: '0px', display: 'none', transform: 'translate3d(0px, 0px, 0px)'}}></div></div></div>
            </div>
          </aside>
        </div>
      <AcademyPost Title="You may also like" />
    </section>
  );
};

export default Single;

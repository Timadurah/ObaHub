import React from 'react';

const Forgotpassowrd = () =>{
    return(<>
    
    </>)
}   

export default Forgotpassowrd;
"use client";
import React from "react";
import Bread from "../components/bread";
import TrendsBooks from "../components/trendsBooks";

const ProductSection = () => {
  const zoom = () => {
    // Implement zoom functionality if needed
    console.log("hey");
  };

  return (
    <div className="w-100">
      <Bread Title="Product" Name=" "/>
      <div
        className="container 
        afterBread p-5 rounded shadow
         bg-white"
      >
        <div className="row">
          {/*product image*/}
          <img
            src="https://fastly.picsum.photos/id/13/2500/1667.jpg?hmac=SoX9UoHhN8HyklRA4A3vcCWJMVtiBXUg0W4ljWTor7s"
            className="rounded shadow col-12 col-lg-6 bg-dark"
            style={{ minHeight: "50ch" }}
          />
          {/*product information*/}
          <div className="col-12 col-lg-6">
            {/**/}

            {/*<!--  -->*/}
            <div className="col-12 py-3 px-2 d-flex justify-content-end">
              <div className="p-2 rounded bg-primary btn mx-2 shadow">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  fill="white"
                  viewBox="0 0 16 16"
                >
                  <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143q.09.083.176.171a3 3 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15" />
                </svg>{" "}
              </div>
            </div>

            {/*<!-- detail [product] -->*/}

            <section className="p-3">
              <h4 className="text-primary">Ipad Pro Genaration 11 inch 2022</h4>

              <div className="d-flex fw-bold align-items-center">
                <h3 className="py-1 fw-bold">54,23 Naira</h3>
                <div
                  className="bg-litey text-white rounded-4 d-flex justify-content-center 
          align-items-center py-1"
                >
                  6% off
                </div>
              </div>
              <div
                className="text-black"
                style={{ textDecoration: "line-through" }}
              >
                IDR 16.999.00
              </div>
              {/*<!--  -->*/}
              <div className="description my-3">
                <h3>Description Product</h3>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                  cum quaerat eos quasi similique eius, accusantium adipisicing
                  elit. At cum quaerat eos quasi similique eius, accusantium.
                </p>
              </div>
              {/**/}
              <label id="quantity" className="py-2">
                {" "}
                Quantity{" "}
              </label>

              <div className="d-flex">
                <input
                  className="border text-black p-2 rounded col-4"
                  placeholder="1"
                  type="number"
                  value="1"
                  required
                />
                <div className="btn btn-primary text-white mx-2 col-8">
                  Add to Cart
                </div>
              </div>
            </section>

            <div className="accordion" id="accordionExample">
              <div className="accordion-item">
                <h2 className="accordion-header" id="headingOne">
                  <button
                    className="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseOne"
                    aria-expanded="true"
                    aria-controls="collapseOne"
                  >
                    More Infromation
                  </button>
                </h2>
                <div
                  id="collapseOne"
                  className="accordion-collapse collapse show"
                  aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample"
                >
                  <div className="accordion-body">
                    <strong>This is the first item's accordion body.</strong> It
                    is shown by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                    of this with custom CSS or overriding our default variables.
                    It's also worth noting that just about any HTML can go
                    within the <code>ObaTyscript</code>, though the transition
                    does limit overflow.
                  </div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header" id="headingTwo">
                  <button
                    className="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseTwo"
                    aria-expanded="false"
                    aria-controls="collapseTwo"
                  >
                    More Infromation
                  </button>
                </h2>
                <div
                  id="collapseTwo"
                  className="accordion-collapse collapse"
                  aria-labelledby="headingTwo"
                  data-bs-parent="#accordionExample"
                >
                  <div className="accordion-body">
                    <strong>This is the second item's accordion body.</strong>{" "}
                    It is hidden by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                    of this with custom CSS or overriding our default variables.
                    It's also worth noting that just about any HTML can go
                    within the <code>ObaTyscript</code>, though the transition
                    does limit overflow.
                  </div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header" id="headingThree">
                  <button
                    className="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseThree"
                    aria-expanded="false"
                    aria-controls="collapseThree"
                  >
                    More Infromation
                  </button>
                </h2>
                <div
                  id="collapseThree"
                  className="accordion-collapse collapse"
                  aria-labelledby="headingThree"
                  data-bs-parent="#accordionExample"
                >
                  <div className="accordion-body">
                    <strong>This is the third item's accordion body.</strong> It
                    is hidden by default, until the collapse plugin adds the
                    appropriate classes that we use to style each element. These
                    classes control the overall appearance, as well as the
                    showing and hiding via CSS transitions. You can modify any
                    of this with custom CSS or overriding our default variables.
                    It's also worth noting that just about any HTML can go
                    within the <code>ObaTyscript</code>, though the transition
                    does limit overflow.
                  </div>
                </div>
              </div>
            </div>

            {/**/}
          </div>
          <TrendsBooks />
        </div>
      </div>
    </div>
  );
};

export default ProductSection;

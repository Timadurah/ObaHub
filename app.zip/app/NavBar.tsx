'use client'

import { useEffect, useState } from 'react'
import Cookies from 'js-cookie'
import {
  Disclosure,
  DisclosureButton,
  DisclosurePanel,
} from '@headlessui/react'
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline'

import Image from 'next/image'
import Obaelaifa from '@/images/OBAELAIFA.png'

interface CartCountResponse {
  status: string
  total_items: number
  message?: string
}

export default function NavBar() {
  const [userId, setUserId] = useState<string | null>(null)
  const [cartCount, setCartCount] = useState<number>(0)

  useEffect(() => {
    const userIdFromCookie = Cookies.get('user_id')
    if (userIdFromCookie) {
      setUserId(userIdFromCookie)

      const intervalId = setInterval(() => {
        fetchCartCount(userIdFromCookie)
      }, 1000)
    }
  }, [userId]) // Added userId to dependency array

  const fetchCartCount = async (userId: string) => {
    try {
      const response = await fetch(
        `https://orentify.com/oba/shop/cartcount.php?user_id=${userId}`,
        { cache: 'no-store', next: { revalidate: 1000 } }
      )
      const data: CartCountResponse = await response.json()

      if (data.status === 'success') {
        setCartCount(data.total_items)
      } else {
        console.error('Failed to fetch cart count:', data.message)
      }
    } catch (error) {
      console.error('Error fetching cart count:', error)
    }
  }

  return (
    <Disclosure as="nav" className="bg-white shadow-md">
      {({ open }) => (
        <>
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 justify-between">
              <div className="flex">
                <div className="-ml-2 mr-2 flex items-center md:hidden">
                  {/* Mobile menu button */}
                  <DisclosureButton className="relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500">
                    <span className="absolute -inset-0.5" />
                    <span className="sr-only">Open main menu</span>
                    {open ? (
                      <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
                    ) : (
                      <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
                    )}
                  </DisclosureButton>
                </div>
                <div className="hidden md:ml-6 md:flex md:space-x-8">
                  {/* Navbar links */}
                  <a
                    href="/"
                    className="text-md color-naw font-large hover:color-naw inline-flex items-center 
                    border-b-2 border-transparent px-1 pt-1 font-[900] hover:border-gray-300"
                  >
                    <Image
                      src={Obaelaifa}
                      alt="image"
                      className="shadow w-20 rounded-full ring-4 ring-white  bg-white" style={{zIndex: '1999'}}
                    />{' '}
                  </a>
                  <a
                    href="/divination"
                    className="inline-flex items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    Divination
                  </a>
                  <a
                    href="/consultation"
                    className="inline-flex items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    Consultation
                  </a>
                  <a
                    href="/initiation"
                    className="inline-flex items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    Ifa Initiation
                  </a>
                  <a
                    href="/learn"
                    className="inline-flex color-naw items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    Learn Ifa
                  </a>
                  <a
                    href="/events"
                    className="inline-flex items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    Events
                  </a>

                  <a
                    href="/signup-search-love"
                    className="inline-flex items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    Match Making
                  </a>
                  <a
                    href="/blog"
                    className="inline-flex items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    News / Blogs
                  </a>
                  <a
                    href="/login"
                    className="inline-flex  color-naw items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  >
                    Log in
                  </a>
                </div>
              </div>
              <div className="flex items-center">
                <div className="flex flex-shrink-0 items-center">
                  {userId ? (
                    // <button
                    //   type="button"
                    //   onClick={() => {
                    //     window.location.href = '/cart'
                    //   }}
                    //   className="bg-outline-primary relative inline-flex items-center gap-x-1.5 rounded-md border px-3 py-2 text-sm font-semibold hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    // >
                    //   <svg
                    //     xmlns="http://www.w3.org/2000/svg"
                    //     width="16"
                    //     height="16"
                    //     fill="currentColor"
                    //     className="bi bi-cart4"
                    //     viewBox="0 0 16 16"
                    //   >
                    //     <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5M3.14 5l.5 2H5V5zM6 5v2h2V5zm3 0v2h2V5zm3 0v2h1.36l.5-2zm1.11 3H12v2h.61zM11 8H9v2h2zM8 8H6v2h2zM5 8H3.89l.5 2H5zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2m-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0m9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0" />
                    //   </svg>
                    //   {cartCount}
                    // </button>
                    <></>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        window.location.href = '/login'
                      }}
                      className="bg-naw relative mx-2 inline-flex items-center gap-x-1.5 rounded-md px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                      Sign In
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      window.location.href = '/me/setting'
                    }}
                    className="bg-naw relative mx-2 inline-flex items-center gap-x-1.5 rounded-md px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                  > User Account
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-person-check"
                      viewBox="0 0 16 16"
                    >
                      <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4" />
                      <path d="M8.256 14a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* <button
            type="button"
            onClick={() => {
              window.location.href = '/cart'
            }}
            className="relative inline-flex items-center gap-x-1.5 rounded-md border bg-naw px-3 py-2 text-sm font-semibold text-white hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            style={{
              position: 'fixed',
              right: '0',
              bottom: '10%',
              zIndex: '1200',
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              className="bi bi-cart4"
              viewBox="0 0 16 16"
            >
              <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5M3.14 5l.5 2H5V5zM6 5v2h2V5zm3 0v2h2V5zm3 0v2h1.36l.5-2zm1.11 3H12v2h.61zM11 8H9v2h2zM8 8H6v2h2zM5 8H3.89l.5 2H5zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2m-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0m9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0" />
            </svg>
            {cartCount}
          </button> */}

          <DisclosurePanel className="md:hidden">
            <div className="space-y-1 pb-3 pt-2">
              <DisclosureButton
                as="a"
                href="/divination"
                className="block border-l-4 border-transparent py-2 pl-3 pr-4 text-base font-medium text-gray-500 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-700 sm:pl-5 sm:pr-6"
              >
                Divination
              </DisclosureButton>
              <DisclosureButton
                as="a"
                href="/consultation"
                className="block border-l-4 border-transparent py-2 pl-3 pr-4 text-base font-medium text-gray-500 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-700 sm:pl-5 sm:pr-6"
              >
                Consultation
              </DisclosureButton>
              <DisclosureButton
                as="a"
                href="/initiation"
                className="block border-l-4 border-transparent py-2 pl-3 pr-4 text-base font-medium text-gray-500 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-700 sm:pl-5 sm:pr-6"
              >
                Ifa Initiation
              </DisclosureButton>
              <DisclosureButton
                as="a"
                href="/learn"
                className="block color-naw border-l-4 border-transparent py-2 pl-3 pr-4 text-base font-medium text-gray-500 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-700 sm:pl-5 sm:pr-6"
              >
                Learn Ifa
              </DisclosureButton>
              <DisclosureButton
                as="a"
                href="/events"
                className="block border-l-4 border-transparent py-2 pl-3 pr-4 text-base font-medium text-gray-500 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-700 sm:pl-5 sm:pr-6"
              >
                Events
              </DisclosureButton>

              <DisclosureButton
                as="a"
                href="/signup-search-love"
                className="block border-l-4 border-transparent py-2 pl-3 pr-4 text-base font-medium text-gray-500 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-700 sm:pl-5 sm:pr-6"
              >
                Match Making
              </DisclosureButton>
              <DisclosureButton
                as="a"
                href="/blog"
                className="block border-l-4 border-transparent py-2 pl-3 pr-4 text-base font-medium text-gray-500 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-700 sm:pl-5 sm:pr-6"
              >
                News / Blog
              </DisclosureButton>
            </div>
          </DisclosurePanel>
        </>
      )}
    </Disclosure>
  )
}

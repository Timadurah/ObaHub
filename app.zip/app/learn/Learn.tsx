'use client'

import {
  CheckCircleIcon,
  InformationCircleIcon,
} from '@heroicons/react/20/solid'
import {
  BuildingOffice2Icon,
  EnvelopeIcon,
  PhoneIcon,
} from '@heroicons/react/24/outline'

import { useState } from 'react'
import axios from 'axios'

interface ErrorResponse {
  detail: Array<{
    loc: string[]
    msg: string
    type: string
  }>
  body?: any
}

export default function Learn() {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
  })
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const validateForm = () => {
    const { first_name, last_name, email, phone } = formData
    let errors: string[] = []

    // Validate first_name
    if (first_name.trim().length === 0) {
      errors.push('First name is required.')
    }

    // Validate last_name
    if (last_name.trim().length === 0) {
      errors.push('Last name is required.')
    }

    // Validate email
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailPattern.test(email)) {
      errors.push('Email is not valid.')
    }

    // Validate phone number
    // const phonePattern = /^\+?[1-9]\d{1,14}$/
    // if (!phonePattern.test(phone)) {
    //   errors.push('Phone number is not valid.')
    // }

    return errors
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)

    // Perform validation
    const validationErrors = validateForm()
    if (validationErrors.length > 0) {
      setError(validationErrors.join(' '))
      return
    }

    try {
      const response = await axios.post(
        'https://orentify.com/oba/learn_registration.php',
        formData
      )
      setSuccess('You have been successfull registered to Ifa Academy Thanks!')
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
      })
    } catch (err) {
      if (axios.isAxiosError(err)) {
        setError('Failed to Register. Please check your input and try again.')
        console.error(err.response?.data)
      } else {
        setError('An unexpected error occurred.')
        console.error(err)
      }
    }
  }

  return (
    <>
      <div className="relative isolate bg-white">
        <div className="mx-auto grid max-w-7xl grid-cols-1 lg:grid-cols-2">
          <div className="relative px-6 pb-20 pt-24 sm:pt-32 lg:static lg:px-8 lg:py-48">
            <div className="mx-auto max-w-xl lg:mx-0 lg:max-w-lg">
              <div className="absolute inset-y-0 left-0 -z-10 w-full overflow-hidden bg-gray-100 ring-1 ring-gray-900/10 lg:w-1/2">
                <svg
                  className="absolute inset-0 h-full w-full stroke-gray-200 [mask-image:radial-gradient(100%_100%_at_top_right,white,transparent)]"
                  aria-hidden="true"
                >
                  <defs>
                    <pattern
                      id="83fd4e5a-9d52-42fc-97b6-718e5d7ee527"
                      width={200}
                      height={200}
                      x="100%"
                      y={-1}
                      patternUnits="userSpaceOnUse"
                    >
                      <path d="M130 200V.5M.5 .5H200" fill="none" />
                    </pattern>
                  </defs>
                  <rect
                    width="100%"
                    height="100%"
                    strokeWidth={0}
                    fill="white"
                  />
                  <svg
                    x="100%"
                    y={-1}
                    className="overflow-visible fill-gray-50"
                  >
                    <path d="M-470.5 0h201v201h-201Z" strokeWidth={0} />
                  </svg>
                  <rect
                    width="100%"
                    height="100%"
                    strokeWidth={0}
                    fill="url(#83fd4e5a-9d52-42fc-97b6-718e5d7ee527)"
                  />
                </svg>
              </div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                Do you love to Learn Ifa?
              </h2>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Please Sign Up for Ifa academy for free today, OR You can also
                reach us by phone, email or visit us at our Ifa temple in Lagos,
                Nigeria.
              </p>
              <dl className="mt-10 space-y-4 text-base leading-7 text-gray-600">
                <div className="flex gap-x-4">
                  <dt className="flex-none">
                    <span className="sr-only">Address</span>
                    <BuildingOffice2Icon
                      className="h-7 w-6 text-gray-400"
                      aria-hidden="true"
                    />
                  </dt>
                  <dd>
                    Oba Avenue
                    <br />
                    Lekki, Lagos Nigeria
                  </dd>
                </div>
                <div className="flex gap-x-4">
                  <dt className="flex-none">
                    <span className="sr-only">Telephone</span>
                    <PhoneIcon
                      className="h-7 w-6 text-gray-400"
                      aria-hidden="true"
                    />
                  </dt>
                  <dd>
                    <a
                      className="hover:text-gray-900"
                      href="tel:+1 (555) 234-5678"
                    >
                      +234 (0) 813 847 5132
                    </a>
                  </dd>
                </div>
                <div className="flex gap-x-4">
                  <dt className="flex-none">
                    <span className="sr-only">Email</span>
                    <EnvelopeIcon
                      className="h-7 w-6 text-gray-400"
                      aria-hidden="true"
                    />
                  </dt>
                  <dd>
                    <a
                      className="hover:text-gray-900"
                      href="mailto:hello@example.com"
                    >
                      info@obaelaifa.com
                    </a>
                  </dd>
                </div>
              </dl>
            </div>
          </div>
          <form
            action="#"
            method="POST"
            className="px-6 pb-24 pt-20 sm:pb-32 lg:px-8 lg:py-48"
            onSubmit={handleSubmit}
          >
            <div className="mx-auto max-w-xl lg:mr-0 lg:max-w-lg">
              <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                Sign up
              </h2>
              <br />
              {error && (
                <p style={{ color: 'red', marginBottom: '10px' }}>{error}</p>
              )}
              {success && (
                <p style={{ color: 'green', marginBottom: '10px' }}>
                  {success}
                </p>
              )}

              <div className="grid grid-cols-1 gap-x-8 gap-y-6 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="first-name"
                    className="block text-sm font-semibold leading-6 text-gray-900"
                  >
                    First name
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="text"
                      autoComplete="given-name"
                      id="first_name"
                      name="first_name"
                      value={formData.first_name}
                      onChange={handleChange}
                      required
                      placeholder='Enter your first name'
                      className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 border ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>
                <div>
                  <label
                    htmlFor="last-name"
                    className="block text-sm font-semibold leading-6 text-gray-900"
                  >
                    Last name
                  </label>
                  <div className="mt-2.5">
                    <input
                    placeholder='Enter your last name'
                      type="text"
                      id="last_name"
                      name="last_name"
                      value={formData.last_name}
                      onChange={handleChange}
                      required
                      autoComplete="family-name"
                      className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 border ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <label
                    htmlFor="email"
                    className="block text-sm font-semibold leading-6 text-gray-900"
                  >
                    Email
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="email"
                      id="email"
                      name="email"
                      placeholder='Enter your Email'
                      value={formData.email}
                      onChange={handleChange}
                      required
                      autoComplete="email"
                      className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 border ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <label
                    htmlFor="phone-number"
                    className="block text-sm font-semibold leading-6 text-gray-900"
                  >
                    Phone number
                  </label>
                  <div className="mt-2.5">
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      placeholder='Enter your phone number'
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      autoComplete="tel"
                      className="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    />
                  </div>
                </div>
               
              </div>
              <div className="mt-8 flex justify-end">
                <button
                  type="submit"
                  className="rounded-md bg-naw px-3.5 py-2.5 text-center text-sm font-semibold text-white border hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                >
                  Sign Up
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div className="bg-white px-6 py-32 lg:px-8">
        <div className="mx-auto max-w-3xl text-base leading-7 text-gray-700">
          <p className="text-base font-semibold leading-7 text-indigo-600">
            Introducing
          </p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Oba Ela Ifa Academy
          </h1>
          <p className="mt-6 text-xl leading-8">
            Dedication, respect for the tradition, and a willingness to engage
            deeply with both the spiritual and physical aspects of Ifa are
            necessary for mastering this ancient wisdom system.
          </p>
          <div className="mt-10 max-w-2xl">
            <p>
              At Oba Ela Ifa Academy, we offer comprehensive training in Ifa
              divination, spiritual healing, and the Yoruba language. Our
              courses are designed to help you develop a deep understanding of
              Ifa philosophy, rituals, divination techniques, and more. Students
              at Ifa Academy are guided by experienced Babalawos and Iyanifas,
              ensuring an authentic and enriching learning experience.
            </p>
            <ul role="list" className="mt-8 max-w-xl space-y-8 text-gray-600">
              <li className="flex gap-x-3">
                <CheckCircleIcon
                  className="mt-1 h-5 w-5 flex-none text-indigo-600"
                  aria-hidden="true"
                />
                <span>
                  <strong className="font-semibold text-gray-900">
                    Divination Training.
                  </strong>{' '}
                  Learn and recite the 256 sacred verses of Ifa, master the use
                  of Ikin and Opele, and develop your divination skills.
                </span>
              </li>
              <li className="flex gap-x-3">
                <CheckCircleIcon
                  className="mt-1 h-5 w-5 flex-none text-indigo-600"
                  aria-hidden="true"
                />
                <span>
                  <strong className="font-semibold text-gray-900">
                    Rituals and Ceremonies.
                  </strong>{' '}
                  Instruction on performing traditional Ifa rituals, ceremonies,
                  including initiation rites and annual festivals.
                </span>
              </li>
              <li className="flex gap-x-3">
                <CheckCircleIcon
                  className="mt-1 h-5 w-5 flex-none text-indigo-600"
                  aria-hidden="true"
                />
                <span>
                  <strong className="font-semibold text-gray-900">
                    Spiritual Guidance.
                  </strong>{' '}
                  Personal mentorship and spiritual guidance from seasoned
                  practitioners to support your growth and development.
                </span>
              </li>
            </ul>
            <p className="mt-8">
              Oba Ela Ifa Academy aims to preserve and promote the rich cultural
              heritage of Ifa, fostering a deep understanding and appreciation
              of this ancient wisdom tradition. Through rigorous education and
              spiritual practice, the academy seeks to empower individuals to
              live in harmony with themselves, their communities, and the
              natural world.
            </p>
            <figure className="mt-10 border-l border-indigo-600 pl-9">
              <blockquote className="font-semibold text-gray-900">
                <p>
                  “Ifa always speaks in parables or proverbs, It is the wise man
                  who understands his message. When we say, understand it, It is
                  the wise man who understands it. If we claim we understand it,
                  when we really do not understand it, then we say, there is
                  something terrible about it ”
                </p>
              </blockquote>
              <figcaption className="mt-6 flex gap-x-4">
                <div className="text-sm leading-6">
                  <strong className="font-semibold text-gray-900">
                    Olumide Lucas
                  </strong>{' '}
                  – The religion of the Yoruba
                </div>
              </figcaption>
            </figure>
          </div>
        </div>
      </div>
    </>
  )
}

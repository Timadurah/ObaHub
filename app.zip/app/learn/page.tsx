import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Learn from '@/app/learn/Learn'

export default function Page() {
  return (
    <main>
      <NavBar />
      <Learn />
      <Footer />
    </main>
  )
}

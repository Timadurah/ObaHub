// types.ts
export interface CartItem {
    id: string; // You can change this to 'number' if required
    title: string;
    quantity: number;
    product_price: string;
    image_path: string;
  }
  
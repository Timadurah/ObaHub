'use client'
import React from 'react'
import Cookies from 'js-cookie'
const MeHeader = () => {
  const userId: any = Cookies.get('user_id') // Get the user_id from the cookie
  let isIS: boolean = false
  if (userId == 404) {
    isIS = true
  }
  const handleLogout = () => {
    // Clear cookies
    Cookies.remove('user_id')

    // Redirect to login page
    location.href = '/login'
  }

  return (
    <div className="col-12 border-bottom d-flex w-100" style={{overflowX: 'auto'}}>
      <div 
        className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
        style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
      >
        <a href="./setting" className="text-black">
          {' '}
          Setting
        </a>
      </div>

      {isIS ? (
        <>
          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./publish" className="text-black">
              {' '}
              Publish{' '}
            </a>
          </div>
          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./lister" className="text-black">
              {' '}
              Add To MarketPlace{' '}
            </a>
          </div>
          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./registrations" className="text-black">
              {' '}
              Registrations{' '}
            </a>
          </div>
          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./privateorders" className="text-black">
              {' '}
              Orders{' '}
            </a>
          </div>
        </>
      ) : (
        <>
          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./plans" className="text-black">
              {' '}
              Plans
            </a>
          </div>

          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./logs" className="text-black">
              {' '}
              History{' '}
            </a>
          </div>
          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./orders" className="text-black">
              {' '}
              My orders{' '}
            </a>
          </div>
          <div 
            className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
            style={{ borderRight: '1px solid lightgrey', flexShrink: '0', flexGrow: '1' }}
          >
            <a href="./wallet" className="text-black">
              {' '}
              Wallet{' '}
            </a>{' '}
          </div>
        </>
      )}
      <div 
        className="fontRs col-auto col-lg-2 d-flex align-items-center justify-content-center btn rounded-0 p-lg-3 p-2"
        onClick={handleLogout}
      >
        Log out
      </div>
    </div>
  )
}

export default MeHeader

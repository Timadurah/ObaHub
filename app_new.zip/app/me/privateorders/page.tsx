
'use client'
import { useState, useEffect } from 'react';
import axios from 'axios';
import Bread from '@/app/components/bread'
import MeHeader from '@/app/me/meHeader'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Cookies from 'js-cookie'

interface UserData {
    full_name: string
    email: string
    delivery_address: string
    delivery_phone: string
  }
  
  interface ApiResponse {
    success: boolean
    user?: UserData
    error?: string
  }

interface Order {
  id: number;
  user_id: number;
  total_amount: number;
  shipping_address: string;
  email: string;
  phone: string;
  status: string;
  created_at: string;
}

export default function Orders() {
    const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)

  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<{ [key: number]: string }>({});
 useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id') // Get the user_id from the cookie

        if (!userId) {
          location.href = '/login'
          return
        }

        const response = await fetch(
          'https://orentify.com/oba/user_detail',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId }), 
            // Send user_id in the request body
          }
        )

        if (!response.ok) {
          location.href = './login'
          return
        }

        const data: ApiResponse = await response.json()
        if (data.success) {
          setUserData(data.user ?? null)
        } else {
          setError(data.error ?? 'An unknown error occurred')
        }
      } catch (err: any) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  // Fetch orders from the backend
  const fetchOrders = async () => {
    try {
      const response = await axios.get('https://orentify.com/oba/orders.php'); // Adjust the endpoint if needed
      setOrders(response.data);
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  // Handle status change
  const handleStatusChange = (orderId: number, status: string) => {
    setSelectedStatus({ ...selectedStatus, [orderId]: status });
  };

  // Submit status update to backend
  const updateStatus = async (orderId: number) => {
    try {
      const status = selectedStatus[orderId];
      await axios.post('https://orentify.com/oba/update_order_status.php', { orderId, status });
      alert('Order status updated successfully!');
      fetchOrders(); // Refresh orders
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Failed to update order status.');
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="p-2">
            <p className="display-6 fw-bold mx-3 my-5 px-5">Orders</p>
            <br className="d-md-block d-none" />
            <div className="d-flex justify-content-between col-12 flex-wrap">

    <div className="container mt-5 w-100 d-flex flex-column" style={{overflowX: 'auto'}}>
      <h2>Orders</h2>
      <table className="table table-bordered w-100" style={{flexShrink: '0', flexGrow: '1'}}>
        <thead>
          <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Total Amount</th>
            <th>Shipping Address</th>
            <th>User Email</th>
            <th>User Phone</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <td><div style={{minWidth: '100px'}}>{order.id}</div></td>
              <td><div style={{minWidth: '100px'}}>{order.user_id}</div></td>
              <td><div style={{minWidth: '200px'}}>{order.total_amount}</div></td>
              <td ><div style={{minWidth: '300px'}}>{order.shipping_address}</div> </td>
              <td>{order.email}</td>
              <td>{order.phone}</td>
              <td>
                <select
                  value={selectedStatus[order.id] || order.status}
                  onChange={(e) => handleStatusChange(order.id, e.target.value)}
                >
                  <option value="Pending">Pending</option>
                  <option value="Shipped">Shipped</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </td>
              <td><div style={{minWidth: '200px'}}>{order.created_at}</div></td>
              <td>
                <button className="btn btn-primary" onClick={() => updateStatus(order.id)}>
                  Update Status
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
    </div>
  </div>
</section>
<Footer />
</>
  );
}

'use client'
import { useState, useEffect } from 'react';
import axios from 'axios';
import Bread from '@/app/components/bread'
import MeHeader from '@/app/me/meHeader'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Cookies from 'js-cookie'

interface Learner {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  created_at: string;
}

interface Matchmaking {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  occupation: string;
  age: number;
  degree: string;
  created_at: string;
}

interface UserData {
  full_name: string
  email: string
  delivery_address: string
  delivery_phone: string
}

interface ApiResponse {
  success: boolean
  user?: UserData
  error?: string
}

export default function Home() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [email, setEmail] = useState<string>('')

  const [learners, setLearners] = useState<Learner[]>([]);
  const [matchmaking, setMatchmaking] = useState<Matchmaking[]>([]);
  const [learnerPage, setLearnerPage] = useState<number>(1);
  const [matchmakingPage, setMatchmakingPage] = useState<number>(1);

  // Fetch user data
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id') // Get the user_id from the cookie
        if (!userId) {
          location.href = '/login'
          return
        }

        const response = await fetch('https://orentify.com/oba/user_detail', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ user_id: userId }), // Send user_id in the request body
        })

        if (!response.ok) {
          location.href = './login'
          return
        }

        const data: ApiResponse = await response.json()
        if (data.success) {
          setUserData(data.user ?? null)
        } else {
          setError(data.error ?? 'An unknown error occurred')
        }
      } catch (err: any) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  // Fetch learners data
  const fetchLearners = async (page: number) => {
    try {
      const response = await axios.get(`https://orentify.com/oba/registrations/learners.php?page=${page}`);
      console.log(response.data); // Log response to inspect structure

      // Check if response data is iterable (i.e., an array)
      if (Array.isArray(response.data)) {
        setLearners((prev) => [...prev, ...response.data]);
      } else if (response.data.learners && Array.isArray(response.data.learners)) {
        // If data is nested inside another object
        setLearners((prev) => [...prev, ...response.data.learners]);
      } else {
        console.error('Learners data is not an array');
      }
    } catch (error) {
      console.error("Error fetching learners:", error);
    }
  };

  // Fetch matchmaking data
  const fetchMatchmaking = async (page: number) => {
    try {
      const response = await axios.get(`https://orentify.com/oba/registrations/matchmaking.php?page=${page}`);
      console.log(response.data); // Log response to inspect structure

      // Check if response data is iterable (i.e., an array)
      if (Array.isArray(response.data)) {
        setMatchmaking((prev) => [...prev, ...response.data]);
      } else if (response.data.matchmaking && Array.isArray(response.data.matchmaking)) {
        // If data is nested inside another object
        setMatchmaking((prev) => [...prev, ...response.data.matchmaking]);
      } else {
        console.error('Matchmaking data is not an array');
      }
    } catch (error) {
      console.error("Error fetching matchmaking:", error);
    }
  };

  // Load more data when user scrolls
  const handleScroll = () => {
    if (window.innerHeight + document.documentElement.scrollTop !== document.documentElement.offsetHeight) return;

    // Load more data
    fetchLearners(learnerPage + 1);
    setLearnerPage((prev) => prev + 1);

    fetchMatchmaking(matchmakingPage + 1);
    setMatchmakingPage((prev) => prev + 1);
  };

  useEffect(() => {
    // Initial data load
    fetchLearners(learnerPage);
    fetchMatchmaking(matchmakingPage);

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [learnerPage, matchmakingPage]);

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="p-2">
            <p className="display-6 fw-bold mx-3 my-5 px-5">User Form Registrations</p>
            <br className="d-md-block d-none" />
            <div className="d-flex justify-content-between col-12 flex-wrap">
          
    <div className="container mt-5 d-flex flex-column" style={{overflowX: 'auto'}}>
      <h2>Learners</h2>
      <table className="table table-bordered" style={{flexShrink: '0', flexGrow: '1'}}>
        <thead>
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Created At</th>
          </tr>
        </thead>
        <tbody>
          {learners.map((learner) => (
            <tr key={learner.id}>
              <td>{learner.id}</td>
              <td>{learner.first_name}</td>
              <td>{learner.last_name}</td>
              <td>{learner.email}</td>
              <td>{learner.phone}</td>
              <td>{learner.created_at}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Matchmaking</h2>
      <table className="table table-bordered" >
        <thead>
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Occupation</th>
            <th>Age</th>
            <th>Degree</th>
            <th>Created At</th>
          </tr>
        </thead>
        <tbody>
          {matchmaking.map((match) => (
            <tr key={match.id}>
              <td><div style={{minWidth: '100px'}}>{match.id}</div></td>
              <td><div style={{minWidth: '200px'}}>{match.first_name}</div></td>
              <td><div style={{minWidth: '200px'}}>{match.last_name}</div></td>
              <td><div style={{minWidth: '200px'}}>{match.email}</div></td>
              <td><div style={{minWidth: '200px'}}>{match.phone}</div></td>
              <td><div style={{minWidth: '200px'}}>{match.occupation}</div></td>
              <td><div style={{minWidth: '100px'}}>{match.age}</div></td>
              <td><div style={{minWidth: '200px'}}>{match.degree}</div></td>
              <td><div style={{minWidth: '200px'}}>{match.created_at}</div></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

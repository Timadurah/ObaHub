'use client'
import React, { useEffect, useState } from 'react'
import Cookies from 'js-cookie'
import Bread from '@/app/components/bread'
import MeHeader from '@/app/me/meHeader'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'

// Define the types for the user data
interface UserData {
  email: string
  phone: string
  full_name: string
  balance: number // Add balance field
}

// Define the types for error handling
interface Error {
  message: string
}

const WalletAndPayment: React.FC = () => {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<Error | null>(null)
  const [amount, setAmount] = useState<number>(1000)

  useEffect(() => {
    // Ensure FlutterwaveCheckout is available only after the script is loaded
    if (typeof window !== 'undefined') {
      const script = document.createElement('script')
      script.src = 'https://checkout.flutterwave.com/v3.js'
      script.async = true
      document.body.appendChild(script)
    }
  }, [])

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id') // Get the user_id from the cookie

        if (!userId) {
          location.href = './login'
          return
        }

        const response = await fetch('https://orentify.com/oba/user_detail', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ user_id: userId }), // Send user_id in the request body
        })

        if (!response.ok) {
          location.href = './login'
          return
        }

        const data = await response.json()
        if (data.success) {
          setUserData(data.user) // Assuming data.user contains balance and other user details
        } else {
          setError({ message: data.error })
        }
      } catch (err) {
        setError({ message: (err as Error).message })
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  let amounty: any = amount
  const makePayment = () => {
    // Ensure FlutterwaveCheckout exists before calling it
    if (typeof window !== 'undefined' && (window as any).FlutterwaveCheckout) {
      const user_idd = Cookies.get('user_id')
      const FlutterwaveCheckout = (window as any).FlutterwaveCheckout
      FlutterwaveCheckout({
        public_key: 'FLWPUBK_TEST-b60f92f4472fef83546cb39bf2b90f27-X',
        tx_ref: 'txref-DI0NzMx13' + user_idd,
        amount: parseInt(amounty), // Use the input amount
        currency: 'NGN',
        payment_options: 'card, banktransfer, ussd',
        meta: {
          source: 'docs-inline-test',
          consumer_id: user_idd,
          consumer_payment_type: 'sub',
        },
        customer: {
          email: userData?.email || '',
          phone_number: userData?.phone || '',
          name: userData?.full_name || '',
        },
        customizations: {
          title: 'OBA ELA IFA PAYMENT SERVICE',
          description: 'OBA ELA IFA definition payment',
          logo: 'https://checkout.flutterwave.com/assets/img/rave-logo.png',
        },
        callback: function (data: any) {
          console.log('Payment callback:', data)
          location.href = '' // Handle the payment response here
        },
        onclose: function () {
          console.log('Payment cancelled!')
        },
      })
    } else {
      console.error('FlutterwaveCheckout is not available')
    }
  }

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmount(Number(e.target.value))
  }

  if (loading) return <div className="text-center text-xl">Loading...</div>
  if (error)
    return <div className="text-center text-red-500">{error.message}</div>

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name ?? 'Home > Plans'} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="container mx-auto p-4">
            <h2 className="mb-4 text-left text-2xl">Wallet</h2>
            {/* Display the user's balance */}
            <div className="mb-4">
              <p className="text-lg font-semibold">
                Your Balance: <span className="text-green-600">₦{userData?.balance}</span>
              </p>
            </div>
            <div className="mb-4">
              <label
                htmlFor="amount"
                className="my-2 block text-sm font-medium text-gray-700"
              >
                Amount to Add:
              </label>
              <input
                type="number"
                id="amount"
                value={amount}
                onChange={handleAmountChange}
                className="col-lg-3 col-12 border-bottom mt-1 block border-none focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="1000"
                min="1000"
              />
            </div>
            <button
              onClick={makePayment}
              className="col-lg-3 col-12 mt-3 block rounded-md bg-indigo-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              Add Money To Wallet
            </button>
          </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default WalletAndPayment

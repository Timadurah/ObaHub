'use client'
import React, { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import 'react-quill/dist/quill.snow.css'
import axios from 'axios'
import Cookies from 'js-cookie'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Bread from '@/app/components/bread'
import MeHeader from '@/app/me/meHeader'

interface UserData {
  full_name: string
  email: string
  delivery_address: string
  delivery_phone: string
}
  
interface ApiResponse {
  success: boolean
  user?: UserData
  post?: PostData
  error?: string
}

interface PostData {
  id: number
  topic: string
  category: string
  content: string
}
interface BlogProps {
    params: {
      id: string // Dynamic ID parameter
    }
  }
const ReactQuill = dynamic(() => import('react-quill'), { ssr: false })

const modules = {
  toolbar: [
    [{ header: [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ list: 'ordered' }, { list: 'bullet' }],
    ['link', 'image', 'video'],
    [{ align: [] }],
    ['clean'],
  ],
}

const formats = [
  'header',
  'bold',
  'italic',
  'underline',
  'strike',
  'list',
  'bullet',
  'link',
  'image',
  'video',
  'align',
]

const TextEditor = ({ params }: BlogProps) => {
  const postId = params.id 
  const [editorContent, setEditorContent] = useState('')
  const [topic, setTopic] = useState('')
  const [category, setCategory] = useState('')
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [responder, setResponder] = useState<string>('')

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id')

        if (!userId) {
          location.href = '/login'
          return
        }

        const userResponse = await fetch('https://orentify.com/oba/user_detail', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ user_id: userId }),
        })

        if (!userResponse.ok) {
          location.href = './login'
          return
        }

        const userData: ApiResponse = await userResponse.json()
        if (userData.success) {
          setUserData(userData.user ?? null)
        } else {
          setError(userData.error ?? 'An unknown error occurred')
        }

        if (postId) {
          // Fetch the post data for editing
          const postResponse = await axios.get(`https://orentify.com/oba/uploader.php?id=${postId}`)
          if (postResponse.data.status === 'success') {
            setTopic(postResponse.data.post?.topic ?? '');
            setCategory(postResponse.data.post?.category ?? '');
            setEditorContent(postResponse.data.post?.content ?? '');
          } else {
            setError(postResponse.data.message ?? 'Failed to load post');
          }
        }
      } catch (err: any) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [postId])

  const handleSubmit = async () => {
    setResponder('PLEASE WAIT WHILE UPLOADING...')
    if (!topic || !category) {
      alert('Please enter a topic and select a category')
      return
    }

    try {
      const response = await axios.post('https://orentify.com/oba/uploader.php', {
        id: postId, // Include post ID if available (for editing)
        topic,
        category,
        content: editorContent,
      })

      setResponder('POST UPDATED SUCCESSFULLY')
    } catch (error) {
      console.error('Error submitting content:', error)
    }
  }

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="col-11 col-lg-8 mx-auto my-5">
            <h1 style={{ fontFamily: 'system-ui' }}>{postId ? 'Edit Content' : 'Create Content'}</h1>
            <p className="text-success py-2">{responder}</p>

            {/* Topic Input */}
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter topic"
              className="form-control my-3 p-4"
            />
            {/* Category Selector */}
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="form-control mb-5"
            >
              <option value="">Content Type ::</option>
              <option value="blogpost">Blog</option>
              <option value="oduifapost">Divination</option>
            </select>

            {/* Rich Text Editor */}
            <ReactQuill
              value={editorContent}
              onChange={setEditorContent}
              modules={modules}
              formats={formats}
              placeholder="Write something amazing..."
              theme="snow"
            />
            <br />

            {/* Submit Button */}
            <button onClick={handleSubmit} className="btn btn-outline-primary">
              {postId ? 'Update Post' : 'Create Post'}
            </button>
          </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default TextEditor

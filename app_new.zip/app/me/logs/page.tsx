'use client'
import React, { useEffect, useState } from 'react'
import Cookies from 'js-cookie'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import MeHeader from '../meHeader'
import Bread from '@/app/components/bread'
interface Notification {
  user_id: string
  reference: string
  label: string
  created_at: string
}

// Define types for the user data and subscription data
interface UserData {
    full_name: string
  }
const Notifications: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [userData, setUserData] = useState<UserData | null>(null)
  useEffect(() => {
    const userId = Cookies.get('user_id')

    if (!userId) {
      // Redirect to login if user_id is not available
      if (typeof window !== 'undefined') {
        location.href = '../login'
      }
      return
    }

    const fetchUserData = async () => {
      try {
        const response = await fetch('https://orentify.com/oba/user_detail', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ user_id: userId }),
        })

        if (!response.ok) {
          if (typeof window !== 'undefined') {
            location.href = '/login'
          }
          return
        }

        const data = await response.json()
        if (data.success) {
          setUserData(data.user)
        } else {
          setError(data.error || 'Failed to fetch user data.')
        }
      } catch (err: any) {
        setError(err.message || 'An error occurred while fetching user data.')
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  useEffect(() => {
    const fetchNotifications = async () => {
      const userId = Cookies.get('user_id') // Get the user_id from cookies

      if (!userId) {
        setError('User ID not found. Please log in.')
        setLoading(false)
        return
      }

      try {
        const response = await fetch(
          'https://orentify.com/oba/logs.php',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId }), // Send the user_id in the request body
          }
        )

        const data = await response.json()

        if (data.success) {
          setNotifications(data.notifications)
        } else {
          setError('Failed to load notifications')
        }
      } catch (err) {
        setError('Error fetching notifications')
      } finally {
        setLoading(false)
      }
    }

    fetchNotifications()
  }, [])

  if (loading) {
    return (
      <div
        style={{
          width: '100vw',
          height: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div className="fw-bold color-naw display-4 rounded-md p-4 ">
          OBA ELA IFA
        </div>
      </div>
    )
  }
  if (error) return <p>{error}</p>

  return (
    <>
      {' '}
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name || ''} />
        <br />
        <div className="afterBread container mb-5 rounded border bg-white p-0">
          <MeHeader />
          <div className="p-2">
        <div className="grid grid-cols-1 gap-4">
          {notifications.map((notification) => (
            <div
              key={notification.created_at}
              className="rounded-lg border bg-gray-100 p-4"
            >
              <p>
                <strong>Reference:</strong> {notification.reference}
              </p>
              <p>
                <strong>Label:</strong> {notification.label}
              </p>
              <p>
                <strong>Date:</strong>{' '}
                {new Date(notification.created_at).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
        </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default Notifications
 
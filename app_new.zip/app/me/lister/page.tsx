'use client'

import React, { useEffect, useState } from 'react'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Bread from '@/app/components/bread'
import MeHeader from '../meHeader'
import Cookies from 'js-cookie'

interface UserData {
  full_name: string
  email: string
  delivery_address: string
  delivery_phone: string
}

interface ApiResponse {
  success: boolean
  user?: UserData
  error?: string
}

const ProductUploadForm = () => {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id') // Get the user_id from the cookie

        if (!userId) {
          location.href = '/login'
          return
        }

        const response = await fetch(
          'https://orentify.com/oba/user_detail',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId }), 
          }
        )

        if (!response.ok) {
          location.href = './login'
          return
        }

        const data: ApiResponse = await response.json()
        if (data.success) {
          setUserData(data.user ?? null)
        } else {
          setError(data.error ?? 'An unknown error occurred')
        }
      } catch (err: any) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  const [formData, setFormData] = useState({
    product_name: '',
    product_description: '',
    author: '',
    amount_available: 0,
    price: 0,
    category: '',
  })

  const [productImages, setProductImages] = useState<FileList | null>(null)
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProductImages(e.target.files)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true) // Start loading

    const data = new FormData()
    
    // Convert numbers to strings before appending
    Object.keys(formData).forEach((key) => {
      data.append(key, String(formData[key as keyof typeof formData]))
    })
    
    if (productImages) {
      for (let i = 0; i < productImages.length; i++) {
        data.append('product_images[]', productImages[i])
      }
    }

    try {
      const response = await fetch(
        'https://orentify.com/oba/upload-product.php',
        {
          method: 'POST',
          body: data, // FormData handles the multipart/form-data encoding automatically
        }
      )

      const result = await response.json()

      if (response.ok) {
        setMessage(result.message || 'Product uploaded successfully.')
      } else {
        setMessage(result.message || 'Error uploading product details.')
      }
    } catch (error) {
      setMessage('Error uploading product details.')
    } finally {
      setLoading(false) // End loading
    }
  }

  return (
    <>
      <NavBar />
      <section>
        <Bread Title="" Name={userData?.full_name} />
        <br />
        <div className="afterBread mb-5 border bg-white p-0">
          <MeHeader />
          <div className="col-11 col-lg-8 mx-auto my-5">
            <h1 style={{ fontFamily: 'system-ui' }}>Create Product</h1>
            <form
              onSubmit={handleSubmit}
              className="bg-light rounded-3 p-5 shadow"
              encType="multipart/form-data"
            >
              <div className="mb-3">
                <label htmlFor="product_name" className="form-label">
                  Product Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="product_name"
                  name="product_name"
                  value={formData.product_name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="product_description" className="form-label">
                  Product Description
                </label>
                <textarea
                  className="form-control"
                  id="product_description"
                  name="product_description"
                  value={formData.product_description}
                  onChange={handleChange}
                  rows={4}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="author" className="form-label">
                  Author
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="author"
                  name="author"
                  value={formData.author}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="amount_available" className="form-label">
                  Amount Available
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="amount_available"
                  name="amount_available"
                  value={formData.amount_available}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="price" className="form-label">
                  Price
                </label>
                <input
                  type="number"
                  step="0.01"
                  className="form-control"
                  id="price"
                  name="price"
                  value={formData.price}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="category" className="form-label">
                  Category
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="product_images" className="form-label">
                  Product Images
                </label>
                <input
                  type="file"
                  className="form-control"
                  id="product_images"
                  name="product_images[]"
                  multiple
                  onChange={handleFileChange}
                  required
                />
              </div>
              <button type="submit" className="btn btn-primary w-100" disabled={loading}>
                {loading ? 'Uploading...' : 'Upload Product'}
              </button>
              {message && <div className="alert alert-info mt-3">{message}</div>}
            </form>
          </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default ProductUploadForm

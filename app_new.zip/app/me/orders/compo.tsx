'use client';
import React, { useEffect, useState } from 'react';
import Cookies from 'js-cookie';

interface Order {
    id: number;
    total_amount: number;
    status: string;
    created_at: string; // Assuming you'll receive this from the API
}

const OrderList: React.FC = () => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    const fetchOrders = async () => {
        try {
            const userId = Cookies.get('user_id');
            const response = await fetch('https://orentify.com/oba/shop/fetch_orders.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ user_id: userId }),
            });

            const data = await response.json();

            if (data.success) {
                setOrders(data.orders);
            } else {
                setError(data.error);
            }
        } catch (error: any) {
            setError('Error fetching orders: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchOrders();
    }, []);

    if (loading) return <div className="text-center text-xl">Loading...</div>;
    if (error) return <div className="text-red-500 text-center">{error}</div>;

    return (
        <div className="container mx-auto p-4">
            <h2 className="text-2xl font-bold mb-4 text-center">Your Orders</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-gray-300 shadow-lg rounded-lg">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="p-4 border-b text-left">Order ID</th>
                            <th className="p-4 border-b text-left">Total Amount</th>
                            <th className="p-4 border-b text-left">Status</th>
                            <th className="p-4 border-b text-left">Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        {orders.map((order) => (
                            <tr key={order.id} className="hover:bg-gray-50 transition-colors duration-200">
                                <td className="p-4 border-b">{order.id}</td>
                                <td className="p-4 border-b">${order.total_amount}</td>
                                <td className="p-4 border-b">{order.status}</td>
                                <td className="p-4 border-b">{new Date(order.created_at).toLocaleString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default OrderList;

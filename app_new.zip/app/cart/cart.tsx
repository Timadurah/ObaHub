import Cookies from 'js-cookie';

// Define types for cart items and API responses
interface CartItem {
  id: string;
  product_name: string;
  quantity: number;
  price: number;
  product_id: any
  // Add other item fields as needed
}

interface ApiResponse<T> {
  status: string;
  message?: string;
  data?: T;
}

// Utility function to get user ID from cookies
const getUserId = (): string | null => {
  const userId = Cookies.get('user_id');
  if (!userId) {
    console.error('No user_id found in cookies');
  }
  return userId ?? '';
};

// Fetch all items in the cart
export const getCartItems = async (): Promise<CartItem[]> => {
  const userId = getUserId();
  if (!userId) return []; // Return early if user_id is not found

  try {
    const response = await fetch(`https://orentify.com/oba/shop/getcart.php?user_id=${userId}`);
    const data: ApiResponse<CartItem[]> = await response.json();

    if (data?.status === 'success') {
      return data.data ?? []; // Return the array of cart items or an empty array
    } else {
      console.error('Failed to fetch cart items:', data.message);
      return []; // Return an empty array on error
    }
  } catch (error) {
    console.error('Error fetching cart items:', error);
    return []; // Return an empty array on error
  }
};

// Add a new item to the cart
interface AddToCartItem {
  id: string;
  product_name: string;
  quantity: number;
  price: number;
  // Add other item fields as needed
}

export const addToCart = async (item: AddToCartItem): Promise<ApiResponse<null>> => {
  const userId = getUserId();
  if (!userId) return { status: 'error', message: 'User not logged in' };

  try {
    const response = await fetch('https://orentify.com/oba/shop/addcart.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ...item, user_id: userId }),
    });

    return await response.json(); // Directly return the response
  } catch (error) {
    console.error('Error adding to cart:', error);
    return { status: 'error', message: 'Error adding item to cart' };
  }
};

// Update the quantity of an item in the cart
export const updateCartItem = async (id: string, quantity: number): Promise<any> => {
  const userId = getUserId();
  if (!userId) return { status: 'error', message: 'User not logged in' };

  try {
    const cartData = {
      user_id: userId,
      product_id: id,
      quantity: quantity.toString(),
    }
    const response = await fetch(`https://orentify.com/oba/shop/update_cart_.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams(cartData),
    });

    const result = await response.json()
      
  } catch (error) {
    console.error('Error updating cart item:', error);
    return { status: 'error', message: 'Error updating item in cart' };
  }
};

// Remove an item from the cart
export const removeCartItem = async (id: string): Promise<ApiResponse<null>> => {
  const userId = getUserId();
  if (!userId) return { status: 'error', message: 'User not logged in' };

  try {
    // Construct the URL with query parameters
    const responseY = await fetch(`https://orentify.com/oba/shop/deletecart.php?user_id=${userId}&product_id=${id}`);
    return await responseY.json();
  } catch (error) {
    console.error('Error removing cart item:', error);
    return { status: 'error', message: 'Error removing item from cart' };
  }
};


// Clear all items in the cart
export const clearCart = async (): Promise<ApiResponse<null>> => {
  const userId = getUserId();
  if (!userId) return { status: 'error', message: 'User not logged in' };

  try {
    const response = await fetch(`https://orentify.com/oba/shop/clearcart.php?user_id=${userId}`);
    return await response.json();
  } catch (error) {
    console.error('Error clearing cart:', error);
    return { status: 'error', message: 'Error clearing the cart' };
  }
};

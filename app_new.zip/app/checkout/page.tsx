"use client";
import React, { useState, useEffect } from "react";
import NavBar from "@/app/NavBar";
import Footer from "@/app/Footer";
import { getCartItems } from "./cart"; // Import the getCartItems function from your cart file
import { CartItem } from "@/app/types"; // Import the centralized type
import OrderPayment from "../components/OrderPayment"; // Assuming this is your component

// Checkout component
const Checkout: React.FC = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [userInfo, setUserInfo] = useState({
    name: "",
    email: "",
    address: "",
    phone: "",
  });

  // Fetch cart items when component mounts
  const fetchCartItems = async () => {
    try {
      const items: any = await getCartItems();
      setCartItems(items);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching cart items", error);
    }
  };

  useEffect(() => {
    fetchCartItems();
  }, []);

  const calculateTotalPrice = (): number => {
    return cartItems.reduce((total, item) => {
      const price = parseFloat(item.product_price) || 0; // Ensure price is a number
      const quantity = item.quantity || 0;
      return total + price * quantity;
    }, 0);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserInfo((prev) => ({ ...prev, [name]: value }));
  };

  const totalAmount = calculateTotalPrice(); // Calculate total amount here

  if (loading)
    return (
      <div
        style={{
          width: "100vw",
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div className="text-black rounded-md p-4 fw-bold display-4">OBA ELA IFA</div>
      </div>
    );

  return (
    <>
      <NavBar />
      <section className="mt-5">
        <div className="container rounded bg-white p-lg-5 p-2 shadow">
          <h2>Checkout</h2>

          {cartItems.length === 0 ? (
            <p className="mt-4">Your cart is empty.</p>
          ) : (
            <>
              <h4>Order Summary</h4>
              {cartItems.map((item) => (
                <div key={item.id} className="d-flex align-items-center border-bottom py-4">
                  <img
                    className="rounded-3 me-4"
                    src={"https://orentify.com/oba/" + item.image_path.split(",")[0]}
                    alt={item.title}
                    width={100}
                    height={100}
                    style={{ objectFit: "cover" }}
                  />
                  <div className="flex-grow-1">
                    <h5>{item.title}</h5>
                    <p className="mb-1">
                      Price: ₦{parseFloat(item.product_price).toFixed(2)} | Quantity: {item.quantity}
                    </p>
                  </div>
                </div>
              ))}

              <div className="d-flex justify-content-end mt-4">
                <h4>Total: ₦{totalAmount.toFixed(2)}</h4>
              </div>

              <h4 className="mt-4">Shipping Information</h4>
              <form onSubmit={(e) => e.preventDefault()}>
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">
                    Full Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    name="name"
                    value={userInfo.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">
                    Email
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    name="email"
                    value={userInfo.email}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="address" className="form-label">
                    Address
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="address"
                    name="address"
                    value={userInfo.address}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="phone" className="form-label">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    className="form-control"
                    id="phone"
                    name="phone"
                    value={userInfo.phone}
                    onChange={handleChange}
                    required
                  />
                </div>
                {/* Pass cartItems, totalAmount, and userInfo to OrderPayment component */}
                <OrderPayment cartItemsy={cartItems} totalAmount={totalAmount} userData={userInfo} />
              </form>
            </>
          )}
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Checkout;

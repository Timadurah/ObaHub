import Cookies from 'js-cookie';

// Define types for cart items and API responses
interface CartItem {
  id: string;
  product_name: string;
  quantity: number;
  product_price: string;
  image_path: string;
  title: string;
  // Add other item fields as needed
}

interface ApiResponse<T> {
  status: string;
  message?: string;
  data?: T;
}

// Utility function to get user ID from cookies
const getUserId = (): string | null => {
  const userId = Cookies.get('user_id');
  if (!userId) {
    console.error('No user_id found in cookies');
  }
  return userId ?? '';
};

// Fetch all items in the cart
export const getCartItems = async (): Promise<CartItem[]> => {
  const userId = getUserId();
  if (!userId) return []; // Return early if user_id is not found

  try {
    const response = await fetch(`https://orentify.com/oba/shop/getcart.php?user_id=${userId}`);
    const data: ApiResponse<CartItem[]> = await response.json();

    if (data?.status === 'success') {
      return data.data ?? []; // Return the array of cart items or an empty array
    } else {
      console.error('Failed to fetch cart items:', data.message);
      return []; // Return an empty array on error
    }
  } catch (error) {
    console.error('Error fetching cart items:', error);
    return []; // Return an empty array on error
  }
};

// Add a new item to the cart
interface AddToCartItem {
  id: string;
  product_name: string;
  quantity: number;
  price: number;
}

export const addToCart = async (item: AddToCartItem): Promise<ApiResponse<null>> => {
  const userId = getUserId();
  if (!userId) return { status: 'error', message: 'User not logged in' };

  try {
    const response = await fetch('https://orentify.com/oba/shop/addcart.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ...item, user_id: userId }),
    });

    return await response.json(); // Directly return the response
  } catch (error) {
    console.error('Error adding to cart:', error);
    return { status: 'error', message: 'Error adding item to cart' };
  }
};

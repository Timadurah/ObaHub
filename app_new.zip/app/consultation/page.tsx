import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Consultation from '@/app/consultation/Consultation'

export default function Page() {
  return (
    <main>
      <NavBar />
      <Consultation />
      <Footer />
    </main>
  )
}

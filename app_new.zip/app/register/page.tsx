'use client'
import { useState } from 'react'
import axios from 'axios'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Cookies from 'js-cookie'

import Image from 'next/image'
import Baba from '@/images/babalawo_initiate.jpg'

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    address: 'optional',
    social: 'optional',
    nationality: 'optional',
    stateOfOrigin: 'optional',
    city: 'optional',
    maritalStatus: 'optional',
    dateOfBirth: 'optional',
    phone: '',
  })

  const [error, setError] = useState('')

  const handleChange = (e: any) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: any) => {
    e.preventDefault()
    setError('')

    try {
      const response = await axios.post(
        'https://orentify.com/oba/register',
        formData
      )
      if (response.data.success) {
        // set id
        Cookies.set('user_id', response.data.user_id, { expires: 7 })
        // Redirect to login page after successful registration
        location.href = './me/setting'
      } else {
        setError(response.data.error)
      }
    } catch (err) {
      location.href = './me/setting'
    }
  }

  return (
    <>
      <NavBar />
      <section>
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-lg-6 py-5 text-black">
              <div className="ms-xl-4 col-12 col-lg-10 px-5 py-2">
                <h3 className='color-naw'>Welcome</h3>
                <p className="text-muted">
                  We are happy to have you on our website, Please Enjoy the
                  power of nature and explore the secret behind it.
                </p>
              </div>
              <div className="ms-xl-4 d-flex justify-content-between align-items-center col-12 col-lg-10 px-5">
                <a href="./login" className="btn btn-outline-secondary col-5">
                  Login
                </a>
                <a
                  href="/register"
                  className="btn btn-outline-secondary col-5 bg-naw text-white"
                >
                  Register
                </a>
              </div>
              <br />
              <br className="d-md-block d-none" />
              <div className="d-flex align-items-center h-custom-2 px-lg-5 ms-xl-4 mt-lg-5 pt-lg-5 pt-xl-0 mt-xl-n5 my-5 mt-3 px-0 py-5 pt-3">
                <form
                  className="col-12 col-lg-11 rounded-3 position-relative my-5 bg-white p-5 shadow"
                  onSubmit={handleSubmit}
                >
                  {error && <p className="text-danger">{error}</p>}
                  <div className="d-flex justify-content-between">
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Full name</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        name="fullName"
                        required
                        placeholder="your Full name"
                        value={formData.fullName}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Email</label>
                      <input
                        className="form-control bg-white"
                        type="email"
                        name="email"
                        required
                        placeholder="your email"
                        value={formData.email}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  <div className="d-flex justify-content-between">
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Password</label>
                      <input
                        className="form-control bg-white"
                        type="password"
                        name="password"
                        required
                        placeholder="your password"
                        value={formData.password}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Confirm Password</label>
                      <input
                        className="form-control bg-white"
                        type="password"
                        name="confirmPassword"
                        required
                        placeholder="Confirm your password"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  <div className="d-flex justify-content-between">
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Address</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        name="address"
                        required
                        placeholder="your Address"
                        value={formData.address}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Social [Optional]</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        name="social"
                        placeholder="your Social media handle"
                        value={formData.social}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  <div className="d-flex justify-content-between">
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Nationality</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        name="nationality"
                        required
                        placeholder="your Nationality"
                        value={formData.nationality}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">State of Origin</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        name="stateOfOrigin"
                        required
                        placeholder="your State of Origin"
                        value={formData.stateOfOrigin}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  <div className="d-flex justify-content-between">
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">City</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        name="city"
                        required
                        placeholder="your City"
                        value={formData.city}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Marital Status</label>
                      <select
                        className="form-control bg-white"
                        name="maritalStatus"
                        required
                        value={formData.maritalStatus}
                        onChange={handleChange}
                      >
                        <option value="none">Marital</option>
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                      </select>
                    </div>
                  </div>
                  <div className="d-flex justify-content-between">
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Date of Birth</label>
                      <input
                        className="form-control bg-white"
                        type="date"
                        name="dateOfBirth"
                        required
                        placeholder="your Date of Birth"
                        value={formData.dateOfBirth}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-outline mx-lg-2 col-5 col-lg-5 mx-2 mb-4">
                      <label className="form-label">Phone</label>
                      <input
                        className="form-control bg-white"
                        type="text"
                        name="phone"
                        required
                        placeholder="your Phone"
                        value={formData.phone}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div className="col-12 mb-3 pt-1">
                    <button
                      data-mdb-button-init
                      data-mdb-ripple-init
                      className="btn btn-dark bg-naw btn-lg btn-block col-12"
                      type="submit"
                    >
                      Register
                    </button>
                  </div>

                  <p className="small pb-lg-2 mb-3">
                    <a className="text-muted" href="#!">
                      Forgot password
                    </a>
                  </p>
                  <p>
                    You already have an account
                    <a href="./login" className="link-info mx-3">
                      Login here
                    </a>
                  </p>
                </form>
              </div>
            </div>
            <div className="col-sm-6 d-none d-lg-block px-0">
              <Image
                src={Baba}
                alt="Register image"
                className="w-100"
                style={{ objectFit: 'cover', objectPosition: 'left' }}
              />
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  )
}

export default Register

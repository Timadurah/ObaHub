import Image from 'next/image'

import babalawoDivinationImage from '@/images/babalawo_divination.jpg'

export function BabalawoDivinationImage() {
  return (
    <div className="aspect-h-2 aspect-w-3 overflow-hidden sm:aspect-w-5 lg:aspect-none lg:absolute lg:h-full lg:w-1/2 lg:pr-4 xl:pr-16">
      <Image
        src={babalawoDivinationImage}
        alt="Babalawo divination image"
        className="h-full w-full object-cover object-center lg:h-full lg:w-full"
      />
    </div>
  )
}

'use client';
import React from 'react';
import useDivination from './useDivination'; // Adjust the import path as necessary
import styles from '@/app/components/LoadingPlaceholders.module.css'
import Cookies from 'js-cookie'

import Image from 'next/image'
import Line from '@/images/line.png'

export default function Divination() {
  
  const userId: any = Cookies.get('user_id')
  let isAdmin: boolean = false
  if(userId == 404){
    isAdmin = true
  }
  const { searchTerm, setSearchTerm, results, loading, error, handleSearch } = useDivination();

  const handleSearchSubmit = (e: any) => {
    e.preventDefault();
    handleSearch(searchTerm);
  };

  return (
    <>
      <section className="evenstbg p-20">
      <div className="col-12 col-lg-5 mb-3 p-4 bg-white shadow">
        <h2
          style={{ borderLeft: '3px solid gray' }}
          className="text-muted px-1 text-left"
        >
          THE ODU IFA ( DIVINATION )
        </h2>
       
        
      </div>
    </section>
      <div className="container mb-2 pb-5">
        {/* Toolbar */}
        <div className="bg-light rounded-3 mt-n5 border p-3">
          <div className="d-flex align-items-center ps-2">
            {/* Search */}
            <form onSubmit={handleSearchSubmit} className="w-100" >
              <div className="input-group">
                <i className="fa-search position-absolute top-50 translate-middle-y fs-md start-0 ms-3"></i>
                <input
                  className="form-control border-0 shadow-none"
                  type="text"
                  placeholder="Search For Ifa divination..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <button type="submit" className="btn bg-naw text-white">
                  Search
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="bg-white">
        <section aria-labelledby="features-heading" className="relative">
          <div className="align-center flex-column mx-auto flex max-w-2xl justify-center pb-10 sm:px-6 sm:pb-10 lg:max-w-6xl lg:px-8 lg:pt-5">
            <div className="align-center flex-column col-12 flex justify-center">
            
              <p className="my-lg-4">
                {loading
                  ? (
                     <div className={styles.loadingContainer}>
                    <div className={styles.loadingRow}>
                      <div className={styles.loadingPlaceholder}></div>
                      <div className={styles.loadingPlaceholder}></div>
                      <div className={styles.loadingPlaceholder}></div>
                    </div>
                    <div className={styles.loadingRow}>
                      <div className={styles.loadingPlaceholder}></div>
                      <div className={styles.loadingPlaceholder}></div>
                      <div className={styles.loadingPlaceholder}></div>
                    </div>
                    <div className={styles.loadingRow}>
                      <div className={styles.loadingPlaceholder}></div>
                      <div className={styles.loadingPlaceholder}></div>
                      <div className={styles.loadingPlaceholder}></div>
                    </div>
                  </div> )
                  : error
                    ? error
                    : results.length === 0
                      ? 'No results found.'
                      : ''}
              </p>
              <div className="align-center mt-5 col-12 flex justify-center flex-wrap">
                {results.map((item, index) => (
                  <div
                    key={index}
                    className="col-11 col-lg-3 m-2 rounded-md border p-3 shadow-md"
                  >
                    <div className="font-medium">
                      {item.topic}
                    </div>
                    <div className="mt-2 text-gray-500" dangerouslySetInnerHTML={{__html:item.content}}></div>
                    <div className="mt-2 text-gray-500">
                      <a href={`/divination/${item.id}`} className='btn bg-naw text-white my-3'>Read More...</a>
                      {isAdmin && (
                <a href={`/edit/${item.id}`} className="m-2 bg-naw p-3 text-white">
                  Edit
                </a>
              )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <a href="#search" className="btn-primary col-8 col-lg-4 mx-auto border p-4 text-center">
              SEARCH TO GET MORE
            </a>
          </div>
        </section>
      </div>
    </>
  );
}

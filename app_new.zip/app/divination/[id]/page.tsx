'use client'

import { useState, useEffect } from 'react'
import axios from 'axios'
import Cookies from 'js-cookie'
import Footer from '@/app/components/footer'
import NavBar from '@/app/NavBar'
import SubscriptionCard from '@/app/components/subscriptionCard'
import styles from '@/app/components/LoadingPlaceholders.module.css'

// Define types for expected data structures
interface DivinationResult {
  id: string
  topic: string
  content: any
}

interface UserData {
  id: string
  name: string
  email: string
  // Add other user fields as needed
}

interface SubscriptionData {
  sub_plan_mode: 'free' | 'premium'
}

interface DivinationProps {
  params: {
    id: string // Dynamic ID parameter
  }
}

export default function Divination({ params }: DivinationProps) {
  const id = params.id // Access dynamic ID from query parameters
  const [result, setResult] = useState<DivinationResult | null>(null)
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string>('')
  const [userData, setUserData] = useState<UserData | null>(null)
  const [subscription, setSubscription] = useState<SubscriptionData | null>(
    null
  )
  const [isRegistered, setIsRegistered] = useState<boolean>(true)
  const userId = Cookies.get('user_id')

  // Fetch user data
  useEffect(() => {
    const fetchUserData = async () => {
      setLoading(true)
      try {
        const userId = Cookies.get('user_id')

        if (!userId) {
          setIsRegistered(false)
          return
        }

        const response = await fetch(
          'https://orentify.com/oba/user_detail.php',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId }),
          }
        )

        if (!response.ok) {
          location.href = '../login'
          return
        }

        const data = await response.json()
        if (data.success) {
          setUserData(data.user)
        } else {
          setError(data.error || 'Failed to load user data.')
        }
      } catch (err: any) {
        setError(
          err?.message ||
            'An unexpected error occurred while fetching user data.'
        )
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  // Fetch subscription data
  useEffect(() => {
    const fetchSubscriptionData = async () => {
      try {
        const userId = Cookies.get('user_id')

        if (!userId) {
          return
        }

        const response = await fetch(
          'https://orentify.com/oba/subscriptionmode.php',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId }),
          }
        )

        const data = await response.json()

        if (data.success) {
          setSubscription(data.subscription)
        } else {
          console.error('Failed to fetch subscription:', data.message)
          setSubscription(null) // Set subscription to null if no subscription found
        }
      } catch (error) {
        console.error('Error fetching subscription:', error)
        setSubscription(null)
      }
    }

    fetchSubscriptionData()
  }, [])

  // Fetch data based on dynamic ID path
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      setError('')

      try {
        const userId = Cookies.get('user_id')

        // Construct URL based on dynamic ID and user_id
        const url = `https://orentify.com/oba/byid.php?id=${id}&user_id=${userId}`

        const response = await axios.get(url)

        console.log('API Response:', response.data) // Debugging: Print the API response

        if (response.data && response.data.topic !== 'Not Found') {
          setResult(response.data) // Assuming API returns a single result
        } else {
          setIsRegistered(false) // User not registered or content not found
          setResult(null)
        }
      } catch (error: any) {
        if (error.response && error.response.status === 404) {
          setIsRegistered(false) // Handle the case when the user_id is not registered
        } else {
          console.error('Error fetching data:', error)
          setError('An error occurred while fetching data.')
        }
        setResult(null)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [id]) // Run effect when id changes

  return (
    <>
      <NavBar />
      
      <section className="evenstbg p-20">
      <div className="col-12 col-lg-5 mb-3 p-4 bg-white shadow">
        <h2
          style={{ borderLeft: '3px solid gray' }}
          className="text-muted px-1 text-left"
        >
           {result ? result.topic : 'ODU IFA'}
        </h2>
       
        
      </div>
    </section>
      
      <div className="col-lg-7 mx-auto col-11 mb-5 bg-white p-0">
        <section aria-labelledby="features-heading" className="relative">
          <div className="align-center flex-column mx-auto flex max-w-2xl justify-center pb-10 pt-2 sm:px-6 sm:pb-10 lg:max-w-6xl lg:px-8 lg:pt-5">
            <div className="align-center flex-column col-12 flex justify-center">
              {/* Loading, error, or no result */}
              <p className="my-4">
                {loading ? (
                  <div className={styles.loadingContainer}>
                    <div className={styles.loadingRow}>
                      <div className={styles.loadingPlaceholder}></div>
                    </div>
                  </div>
                ) : error ? (
                  error
                ) : !result ? (
                  'Loading Odu Ifa content...'
                ) : (
                  ''
                )}
              </p>

              {/* Display result content */}
              {result && (
                <div className="mb-4">
                  <div
                    className="col-11 col-lg-8 styled-paragraph mx-auto text-left text-gray-500"
                    style={{ fontSize: '20px', fontFamily: 'monospace' }} dangerouslySetInnerHTML={{__html:result.content}}
                  >
                  </div>
                </div>
              )}

              
            </div>
            
          </div>
        </section>
        
      </div>
      {subscription?.sub_plan_mode === 'free' && (
                <SubscriptionCard
                  mode={subscription.sub_plan_mode}
                  type={isRegistered ? 'registered' : 'not_register'}
                  user_id={userId ?? ''}

                />
              )}
      <Footer />
    </>
  )
}

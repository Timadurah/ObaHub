import { useState, useEffect, ChangeEvent } from 'react'
import { StarIcon } from '@heroicons/react/20/solid'
import Image from 'next/image'
import axios from 'axios'
import Cookies from 'js-cookie'

interface Product {
  product_name: string
  price: number
  amount_available: number
  product_description: string
  images: { src: string; alt: string }[]
}

interface OverviewProps {
  product: Product
  productID: number
  userID: number // Make userID optional
}

interface CartItem {
  id: string
  title: string
  quantity: number // Ensure this is a number
  product_price: string
  image_path: string
}

interface ApiResponse<T> {
  status: string
  message?: string
  data?: T
}

const reviews = { href: '#', average: 4 }

function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}

export default function Overview({
  product,
  productID,
  userID,
}: OverviewProps) {
  const [quantity, setQuantity] = useState<number>(1)

  useEffect(() => {
    const fetchCartItem = async () => {
      try {
        const userId = Cookies.get('user_id')
        if (!userId) {
          console.error('User ID not found in cookies')
          return
        }

        console.log('UserID from cookies:', userId)

        const response = await axios.get<ApiResponse<CartItem[]>>(
          'https://orentify.com/oba/shop/getcart.php',
          {
            params: { user_id: userId },
          }
        )

        console.log("Cart API Response:", response.data);

        if (response.data && response.data.status === 'success') {
          const cartItems = response.data.data ?? []
          const cartItem = cartItems.find(item => item.id === productID.toString())

          console.log("CartItem found:", cartItem);

          if (cartItem) {
            setQuantity(cartItem.quantity) // Set initial quantity from the cart
            console.log("Quantity set to:", cartItem.quantity)
          }
        } else {
          console.error('Failed to fetch cart items:', response.data.message)
        }
      } catch (error) {
        console.error('Error fetching cart items:', error)
      }
    }

    fetchCartItem()
  }, [productID])

  const handleAddToCart = async () => {
    const cartData = {
      user_id: userID.toString(),
      product_id: productID.toString(),
      quantity: quantity.toString(),
    }

    try {
      console.log('Cart data being sent:', cartData)
      const response = await fetch(
        'https://orentify.com/oba/shop/update_cart_overview.php',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams(cartData),
        }
      )

      const result = await response.json()
      if (result.status === 'success') {
        alert('Item updated successfully!')
      } else {
        alert('Failed to update: ' + result.message)
      }
    } catch (error) {
      console.error('Error adding to cart:', error)
      alert('An error occurred while adding the item to the cart.')
    }
  }

  const handleQuantityChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value)) {
      setQuantity(value)
    } else {
      console.error("Invalid input for quantity:", e.target.value)
    }
  }

  return (
    <div className="bg-white">
      <div className="pt-6">
        {/* Image gallery */}
        <div className="mx-auto mt-6 max-w-2xl sm:px-6 lg:grid lg:max-w-7xl lg:grid-cols-3 lg:gap-x-8 lg:px-8">
          {product.images.slice(0, 4).map((image, index) => (
            <div
              key={index}
              className={`aspect-w-3 aspect-h-${index === 0 || index === 3 ? '4' : '2'} overflow-hidden rounded-lg lg:block`}
            >
              <Image
                src={`https://orentify.com/oba/${image.src}`}
                alt={image.alt}
                className="h-full w-full object-cover object-center"
                width={100}
                height={100}
              />
            </div>
          ))}
        </div>

        {/* Product info */}
        <div className="mx-auto max-w-2xl px-4 pb-16 pt-5 sm:px-6 lg:grid lg:max-w-7xl lg:grid-cols-3 lg:grid-rows-[auto,auto,1fr] lg:gap-x-8 lg:px-8 lg:pb-24 lg:pt-5">
          <div className="lg:col-span-2 lg:border-r lg:border-gray-200 lg:pr-8">
            <h1 className="text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">
              {product.product_name}
            </h1>
          </div>

          {/* Options */}
          <div className="mt-4 lg:row-span-3 lg:mt-0">
            <h2 className="sr-only">Product information</h2>
            <p className="text-3xl tracking-tight text-gray-900">
              &#8358; {product.price}
            </p>

            {/* Reviews */}
            <div className="mt-6">
              <h3 className="sr-only">Available</h3>
              <div className="flex items-center">
                <div className="flex items-center">
                  {[0, 1, 2, 3, 4].map((rating) => (
                    <StarIcon
                      key={rating}
                      aria-hidden="true"
                      className={classNames(
                        reviews.average > rating
                          ? 'text-gray-900'
                          : 'text-gray-200',
                        'h-5 w-5 flex-shrink-0'
                      )}
                    />
                  ))}
                </div>
                <p className="sr-only">{reviews.average} out of 5 stars</p>
                <a
                  href="#"
                  className="ml-3 text-sm font-medium text-indigo-600 hover:text-indigo-500"
                >
                  {product.amount_available} Left
                </a>
              </div>
            </div>

            <input
              className="form-control my-2 p-3"
              type="number"
              name="quantity"
              placeholder="quantity"
              value={quantity}
              onChange={handleQuantityChange}
            />
            <button
              type="button"
              onClick={handleAddToCart}
              className="bg-naw hover:bg-naw mt-3 flex w-full items-center justify-center rounded-md border border-transparent px-8 py-3 text-base font-medium text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              Add to cart
            </button>
          </div>

          <div className="py-5 lg:col-span-2 lg:col-start-1 lg:border-r lg:border-gray-200 lg:pb-16 lg:pr-8 lg:pt-6">
            {/* Description and details */}
            <div>
              <h3 className="sr-only">Description</h3>
              <div className="space-y-6">
                <p className="text-base text-gray-900">
                  {product.product_description}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <hr />
    </div>
  )
}

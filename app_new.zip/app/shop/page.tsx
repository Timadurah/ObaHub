'use client'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import ShopCard from '@/app/components/shopcard'
import BookCard from '@/app/components/bookCard'

export default function Page() {
  //

  return (
    <main>
      <NavBar />
      <ShopCard topic="OBA ELA IFA MARKETPLACE" />
      <BookCard topic="OBA ELA IFA BOOK STORE" />
      <Footer />
    </main>
  )
}

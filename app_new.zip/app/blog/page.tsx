'use client'
import { useEffect, useState } from 'react'
import NavBar from '@/app/NavBar'
import Footer from '@/app/Footer'
import Image from 'next/image'
import TvimageTwo from '@/images/5775921785903105072.jpg'
import TvimageThree from '@/images/5775921785903105073.jpg'
import styles from '@/app/components/LoadingPlaceholders.module.css'
import Cookies from 'js-cookie'

interface BlogData {
  id: number
  topic: string
  content: string
}

interface ProcessedBlogData {
  id: number
  topic: string
  imageUrl: string | null
  description: string
}

function extractImageAndText(content: string) {
  const tempDiv = document.createElement('div')
  tempDiv.innerHTML = content
  const imgTag = tempDiv.querySelector('img')
  const imageUrl = imgTag ? imgTag.src : null
  const description = tempDiv.textContent?.trim().slice(0, 150) + '...' || ''
  return { imageUrl, description }
}

export default function page() {
  const [contentData, setContentData] = useState<ProcessedBlogData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const userId: any = Cookies.get('user_id')
  let isAdmin: boolean = false
  if(userId == 404){
    isAdmin = true
  }

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://orentify.com/oba/blogs.php')
        if (!response.ok) {
          throw new Error('Failed to fetch data')
        }
        const data: BlogData[] = await response.json()
        const firstFourRecords = data.slice(0, 50)
        const processedData: ProcessedBlogData[] = firstFourRecords.map(
          (record) => {
            const { content, topic, id } = record
            const { imageUrl, description } = extractImageAndText(content)
            return { id, topic, imageUrl, description }
          }
        )
        setContentData(processedData)
      } catch (error: any) {
        setError(error.message)
      } finally {
        setIsLoading(false)
      }
    }
    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="col-lg-8 col-11 mx-auto my-5">
        {' '}
        <div className={styles.loadingContainer}>
          <div className={styles.loadingRow}>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
          </div>
          <div className={styles.loadingRow}>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return <p>Error: {error}</p>
  }

  return (
    <>
      <NavBar />
      <section className="evenstbg p-20">
        <div className="col-12 col-lg-5 mb-3 bg-white p-4 shadow">
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            Latest Blogs And Stories
          </p>
          <p className="pb-2 text-left">
            Dont Forget to share if you love the Stories
          </p>
        </div>
      </section>
      <br />
      <div className="d-flex container flex-wrap justify-between bg-white p-20">
        <div className="col-lg-12 col-12 mb-3 flex flex-wrap">
        {contentData.map((item) => (
            <div key={item.id} className="col-lg-4 col-12 mb-3 bg-white">
              {item.imageUrl && (
                <Image
                  src={item.imageUrl}
                  alt={item.topic}
                  className="h-[250px] w-[100%]"
                  width={500}
                  height={250}
                />
              )}
              <h6 className="fw-bold py-3">{item.topic}</h6>
              <p
                style={{ borderLeft: '3px solid gray' }}
                className="text-muted px-1 text-left"
              >
                {item.topic}
              </p>
              <p className="pb-2 text-left">{item.description}</p>
              <a href={`/blog/${item.id}`} className="bg-naw p-3 text-white">
                Read More
              </a>
              {isAdmin && (
                <a href={`/edit/${item.id}`} className="mx-2 bg-naw p-3 text-white">
                  Edit
                </a>
              )}
            </div>
          ))}
        </div>
       
      </div>

      <div className="d-flex container flex-wrap justify-between bg-white p-20">
        <div className="col-lg-3 col-12 mb-3 bg-white">
          <iframe
            src="https://www.youtube.com/embed/ktccff291YA?si=Zt2-GBdpVCLm66Fd"
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            className="h-[250px] w-[100%]"
          ></iframe>

          <h6 className="fw-bold py-3">On Youtube Now</h6>
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            healing Time
          </p>
          <p className="pb-2 text-left">
            TRADO MEDICAL TREATMENT FOR 5 PERSONS WITH HEART/ LIVER/KIDNEY
            DISEASES, DIABETES AND BREAST CANCER
          </p>
          <a
            href="https://www.youtube.com/c/ObaElaIfa"
            className="bg-naw p-3 text-white"
          >
            Watch Us Now!
          </a>
        </div>
        <div className="col-lg-3 col-12 mb-3">
          <div className="col-12 mb-3 bg-white">
            <p
              style={{ borderLeft: '3px solid gray' }}
              className="text-muted px-1 text-left"
            >
              Family Education
            </p>
            <p className="pb-2 text-left">
              Fight between Muslims and isese because of a converted isese
              woman.
            </p>
            <a
              href="https://www.youtube.com/watch?v=CPkdPdxC1MA&t=45s"
              className="bg-naw p-3 text-white"
            >
              Watch Now
            </a>
          </div>
          <div className="col-12 mb-3 bg-white">
            <h6 className="fw-bold py-3">News On Youtube Now</h6>

            <p className="pb-2 text-left">
              AGBOTIFAYO GIFTED HIS WIFE A VENZA CAR!WATCH AND SEE WHAT OBA ELA
              DID TOO.
            </p>
            <a
              href="https://www.youtube.com/watch?v=R5gncah2xq8"
              className="bg-naw p-3 text-white"
            >
              Check Out
            </a>
          </div>

          <div className="col-12 mb-3 bg-white">
            <p
              style={{ borderLeft: '3px solid gray' }}
              className="text-muted px-1 text-left"
            >
              Family Education
            </p>
            <p className="pb-2 text-left">
              AGBOTIFAYO GIFTED HIS WIFE A VENZA CAR!WATCH AND SEE WHAT OBA ELA
              DID TOO.
            </p>
            <a
              href="https://www.youtube.com/watch?v=R5gncah2xq8"
              className="bg-naw p-3 text-white"
            >
              Check Out
            </a>
          </div>
        </div>
        <div className="col-lg-3 col-12 mb-3 bg-white">
          <iframe
            src="https://www.youtube.com/embed/sWEryKPQv5g?si=ewhNgEc94ovmT18r"
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            className="h-[250px] w-[100%]"
          ></iframe>

          <h6 className="fw-bold py-3">On Youtube Now</h6>
          <p
            style={{ borderLeft: '3px solid gray' }}
            className="text-muted px-1 text-left"
          >
            Ifa Through Out The World
          </p>
          <p className="pb-2 text-left">
            OYINBO (WHITE MAN)EXPLAINED WHAT OTURA OGBE SAYS ABOUT ISESE THIS
            YEAR . OYINBO HAVE TAKEN OVER.
          </p>
          <a
            href="https://www.youtube.com/c/ObaElaIfa"
            className="bg-naw p-3 text-white"
          >
            Watch Us Now!
          </a>
        </div>
      </div>

     
      <Footer />
    </>
  )
}

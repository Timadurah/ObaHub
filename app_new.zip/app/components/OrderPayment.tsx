import React, { useState } from 'react';
import Cookies from 'js-cookie'; // To get user_id from cookies
import axios from 'axios'; // Use axios for sending HTTP requests
import { CartItem } from '@/app/types';  // Import the centralized type

interface UserData {
  name: string;
  email: string;
  address: string;
  phone: string;
}

// Define the OrderPayment component with TypeScript
const OrderPayment: React.FC<{
  cartItemsy: CartItem[];  // Corrected prop name
  totalAmount: number;
  userData: UserData;
}> = ({ cartItemsy, totalAmount, userData }) => {
  const [loading, setLoading] = useState(false); // State for loading spinner
  const [message, setMessage] = useState(''); // State for feedback messages

  // Function to send order data to PHP API
  const makeOrder = async () => {
    setLoading(true); // Set loading state to true when process starts
    const user_id = Cookies.get('user_id'); // Get user_id from cookies

    if (!user_id) {
      setMessage('User is not authenticated.');
      setLoading(false);
      return;
    }

    try {
      // Send a POST request to the PHP API
      const response = await axios.post('https://orentify.com/oba/shop/processorder.php', {
        user_id, // Send the user ID
        total_amount: totalAmount, // Total order amount
        items: cartItemsy.map(item => ({
          id: item.id,
          title: item.title,
          product_price: item.product_price,
          quantity: item.quantity,
          image_path: item.image_path,
        })), // Send cart items array as expected by the API
        user_data: {
          name: userData.name,
          email: userData.email,
          address: userData.address,
          phone: userData.phone,
        }, // User data for shipping and contact details
      });

      // Destructure data from response
      const { data } = response;

      // Handle successful order placement
      if (data.status === 'success') {
        alert('Order placed successfully!');
        setMessage('Order placed successfully!');
        // Additional logic like redirecting to order confirmation page can go here
      } else {
        // If there's an error, show the error message returned by the API
        alert('Order failed: ' + data.message);
        setMessage('Order failed: ' + data.message);
      }
    } catch (error) {
      // Handle any other errors that might occur during the request
      alert('An error occurred while placing the order.');
      setMessage('An error occurred while placing the order.');
      console.error('Error placing order:', error);
    }

    setLoading(false); // Set loading to false after the process is complete
  };

  return (
    <div>
      {/* Payment button */}
      <button
        onClick={makeOrder}
        className="btn btn-success mt-4"
        disabled={loading} // Disable the button while processing
      >
        {loading ? 'Processing...' : 'Place Order'} {/* Show spinner or button text */}
      </button>

      {/* Display feedback message if there's any */}
      {message && <p className="mt-3">{message}</p>}
    </div>
  );
};

export default OrderPayment;

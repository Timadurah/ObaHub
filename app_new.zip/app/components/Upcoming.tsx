import React from 'react'

const Upcoming = () => {
  return (
    <section className="evenstbg p-2 p-lg-5">
      <div className="col-12 col-lg-5 mb-3 p-4 bg-white shadow">
        <p
          style={{ borderLeft: '3px solid gray' }}
          className="text-muted px-1 text-left"
        >
          Upcomming events 
        </p>
        <p className="pb-2 text-left">
          Check out our upcoming events, Mark your calendar, Come and join us in exploring of wisdom and understanding of nature and love
        </p>
        <a
          href="/events"
          className="bg-naw p-3 text-white"
        >
          Check Our Upcoming
        </a>
      </div>
    </section>
  )
}

export default Upcoming

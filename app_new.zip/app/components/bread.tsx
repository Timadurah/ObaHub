import React from 'react'

const Bread = (props: {Title :string, Name: any}) => {
  
  const namey = props.Name;
  return (
    
    <div className=" w-100 bg-black px-5 py-3 my-auto vhbread">      
<div className="container d-flex my-auto justify-content-start align-items-center">
    <h4 className="text-white f-light  d-flex justify-content-start px-3 py-2 align-items-center" style={{borderLeft: '20px solid #79fe44'}}>
      {props.Title}  {namey} 
      <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="#79fe44" className="mx-1" viewBox="0 0 16 16">
  <path d="M10.067.87a2.89 2.89 0 0 0-4.134 0l-.622.638-.89-.011a2.89 2.89 0 0 0-2.924 2.924l.01.89-.636.622a2.89 2.89 0 0 0 0 4.134l.637.622-.011.89a2.89 2.89 0 0 0 2.924 2.924l.89-.01.622.636a2.89 2.89 0 0 0 4.134 0l.622-.637.89.011a2.89 2.89 0 0 0 2.924-2.924l-.01-.89.636-.622a2.89 2.89 0 0 0 0-4.134l-.637-.622.011-.89a2.89 2.89 0 0 0-2.924-2.924l-.89.01zm.287 5.984-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.793l2.646-2.647a.5.5 0 0 1 .708.708"/>
</svg>
    </h4>
</div>
    </div>   
  )
}
export default Bread

'use client';
import React, { useEffect, useState } from 'react';
import Cookies from 'js-cookie';

// Define the types for the user data
interface UserData {
  email: string;
  phone: string;
  full_name: string;
}

// Define the types for error handling
interface Error {
  message: string;
}

// Define the FlutterwavePayment component
const FlutterwavePayment: React.FC = () => {
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const [email, setEmail] = useState<string>('');
  const [deliveryPhone, setDeliveryPhone] = useState<string>('');

  useEffect(() => {
    // Ensure FlutterwaveCheckout is available only after the script is loaded
    if (typeof window !== 'undefined') {
      const script = document.createElement('script');
      script.src = 'https://checkout.flutterwave.com/v3.js';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = Cookies.get('user_id'); // Get the user_id from the cookie

        if (!userId) {
          location.href = './login';
          return;
        }

        const response = await fetch('https://orentify.com/oba/user_detail', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ user_id: userId }), // Send user_id in the request body
        });

        if (!response.ok) {
          location.href = './login';
          return;
        }

        const data = await response.json();
        if (data.success) {
          setUserData(data.user);
        } else {
          setError({ message: data.error });
        }
      } catch (err) {
        setError({ message: (err as Error).message });
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const makePayment = () => {
    // Ensure FlutterwaveCheckout exists before calling it
    if (typeof window !== 'undefined' && (window as any).FlutterwaveCheckout) {
      const randoMan = Math.floor(1000 + Math.random() * 9000).toString();
      const user_idd = Cookies.get('user_id');
      const FlutterwaveCheckout = (window as any).FlutterwaveCheckout;
      FlutterwaveCheckout({
        public_key: 'FLWPUBK_TEST-b60f92f4472fef83546cb39bf2b90f27-X',
        tx_ref: 'txref-DI0NzMx13' + user_idd,
        amount: 1000, // Fixed amount
        currency: 'NGN',
        payment_options: 'card, banktransfer, ussd',
        meta: {
          source: 'docs-inline-test',
          consumer_id: user_idd,
          consumer_payment_type: 'sub',
        },
        customer: {
          email: userData?.email || '',
          phone_number: userData?.phone || '',
          name: userData?.full_name || '',
        },
        customizations: {
          title: 'OBA ELA IFA SUBSCRIPTION',
          description: 'OBA ELA IFA definition payment',
          logo: 'https://checkout.flutterwave.com/assets/img/rave-logo.png',
        },
        callback: function (data: any) {
          console.log('Payment callback:', data);
          location.href = ''; // Handle the payment response here
        },
        onclose: function () {
          console.log('Payment cancelled!');
        },
      });
    } else {
      console.error('FlutterwaveCheckout is not available');
    }
  };

  return (
    <>
      <button
        onClick={makePayment}
        className="mt-3 block w-full rounded-md bg-indigo-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
      >
        Get Premium Access
      </button>
    </>
  );
};

export default FlutterwavePayment;

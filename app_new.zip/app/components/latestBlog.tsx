import { useEffect, useState } from 'react'
import Image from 'next/image'
import Line from '@/images/line.png'
import TvimageTwo from '@/images/5775921785903105072.jpg'
import TvimageThree from '@/images/5775921785903105073.jpg'
import styles from '@/app/components/LoadingPlaceholders.module.css'

interface BlogData {
  id: number
  topic: string
  content: string
}

interface ProcessedBlogData {
  id: number
  topic: string
  imageUrl: string | null
  description: string
}

function extractImageAndText(content: string) {
  const tempDiv = document.createElement('div')
  tempDiv.innerHTML = content
  const imgTag = tempDiv.querySelector('img')
  const imageUrl = imgTag ? imgTag.src : null
  const description = tempDiv.textContent?.trim().slice(0, 150) + '...' || ''
  return { imageUrl, description }
}

export default function LatestBlog() {
  const [contentData, setContentData] = useState<ProcessedBlogData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://orentify.com/oba/blogs.php')
        if (!response.ok) {
          throw new Error('Failed to fetch data')
        }
        const data: BlogData[] = await response.json()
        const firstFourRecords = data.slice(0, 4)
        const processedData: ProcessedBlogData[] = firstFourRecords.map(
          (record) => {
            const { content, topic, id } = record
            const { imageUrl, description } = extractImageAndText(content)
            return { id, topic, imageUrl, description }
          }
        )
        setContentData(processedData)
      } catch (error: any) {
        setError(error.message)
      } finally {
        setIsLoading(false)
      }
    }
    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="col-lg-8 col-11 mx-auto my-5">
        {' '}
        <div className={styles.loadingContainer}>
          <div className={styles.loadingRow}>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
          </div>
          <div className={styles.loadingRow}>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
            <div className={styles.loadingPlaceholder}></div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return <p>Error: {error}</p>
  }

  return (
    <>
      <h1 className="fw-bold mx-auto my-3 text-center text-black">
        Latest News & Stories
      </h1>
      <p className="mx-auto text-center text-[#464646]">
        Keep up with the latest OBAELAIFA news & stories!
      </p>
      <Image
        src={Line}
        alt="Obaelaifa tv image"
        className="mx-auto my-3 h-[100px]"
      />
      <br />
      <div className="d-flex container flex-wrap justify-between bg-white p-20">
        <div className="col-lg-6 col-12 mb-3 flex flex-wrap">
          {contentData.map((item) => (
            <div key={item.id} className="col-lg-5 col-12 mb-3 bg-white">
              {item.imageUrl && (
                <Image
                  src={item.imageUrl}
                  alt={item.topic}
                  className="h-[250px] w-[100%]"
                  width={500}
                  height={250}
                />
              )}
              <h6 className="fw-bold py-3">{item.topic}</h6>
              <p
                style={{ borderLeft: '3px solid gray' }}
                className="text-muted px-1 text-left"
              >
                {item.topic}
              </p>
              <p className="pb-2 text-left">{item.description}</p>
              <a href={`/blog/${item.id}`} className="bg-naw p-3 text-white">
                Read More
              </a>
            </div>
          ))}
        </div>
        <div className="col-lg-3 col-12 mb-3">
          <div className="col-12 my-auto mb-3 bg-white text-center">
            <a href="/shop">
              <Image
                src={TvimageTwo}
                alt="Obaelaifa tv image"
                className="w-[100%]"
              />
            </a>
          </div>
          <div className="col-12 my-auto mb-3 bg-white text-center">
            <a href="/shop">
              <Image
                src={TvimageThree}
                alt="Obaelaifa tv image"
                className="w-[100%]"
              />
            </a>
          </div>
        </div>
      </div>
      <div className="col-12 align-center mb-5 flex justify-center">
        <a href="./blog" className="bg-naw p-3 text-white">
          Check more news
        </a>
      </div>
    </>
  )
}

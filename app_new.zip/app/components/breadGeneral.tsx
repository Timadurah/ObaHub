import React from 'react'

const breadGeneral = () => {
  return (
    <div>
      
    </div>
  )
}

export default breadGeneral
